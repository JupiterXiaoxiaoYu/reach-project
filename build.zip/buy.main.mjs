// Automatically generated with Reach 0.1.3
/* eslint-disable */
export const _version = '0.1.3';
export const _backendVersion = 1;


export function getExports(s) {
  const stdlib = s.reachStdlib;
  return {
    };
  };

export function _getViews(s, viewlib) {
  const stdlib = s.reachStdlib;
  const ctc0 = stdlib.T_Address;
  const ctc1 = stdlib.T_UInt;
  
  return {
    infos: {
      "NFT": {
        career1: {
          decode: async (i, svs, args) => {
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 1))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v57;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 2))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v57;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 3))) {
              const [v22, v56, v57, v58] = svs;
              return (await ((async () => {
                
                
                return v57;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 4))) {
              const [v22, v56, v57, v58] = svs;
              return (await ((async () => {
                
                
                return v57;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 5))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 6))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 7))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            
            stdlib.assert(false, 'illegal view')
            },
          ty: ctc1
          },
        career2: {
          decode: async (i, svs, args) => {
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 1))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v84;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 2))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v84;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 3))) {
              const [v22, v56, v57, v58] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 4))) {
              const [v22, v56, v57, v58] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 5))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 6))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 7))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            
            stdlib.assert(false, 'illegal view')
            },
          ty: ctc1
          },
        fortune1: {
          decode: async (i, svs, args) => {
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 1))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v58;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 2))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v58;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 3))) {
              const [v22, v56, v57, v58] = svs;
              return (await ((async () => {
                
                
                return v58;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 4))) {
              const [v22, v56, v57, v58] = svs;
              return (await ((async () => {
                
                
                return v58;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 5))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 6))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 7))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            
            stdlib.assert(false, 'illegal view')
            },
          ty: ctc1
          },
        fortune2: {
          decode: async (i, svs, args) => {
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 1))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v85;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 2))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v85;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 3))) {
              const [v22, v56, v57, v58] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 4))) {
              const [v22, v56, v57, v58] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 5))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 6))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 7))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            
            stdlib.assert(false, 'illegal view')
            },
          ty: ctc1
          },
        love1: {
          decode: async (i, svs, args) => {
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 1))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v56;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 2))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v56;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 3))) {
              const [v22, v56, v57, v58] = svs;
              return (await ((async () => {
                
                
                return v56;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 4))) {
              const [v22, v56, v57, v58] = svs;
              return (await ((async () => {
                
                
                return v56;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 5))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 6))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 7))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            
            stdlib.assert(false, 'illegal view')
            },
          ty: ctc1
          },
        love2: {
          decode: async (i, svs, args) => {
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 1))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v83;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 2))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v83;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 3))) {
              const [v22, v56, v57, v58] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 4))) {
              const [v22, v56, v57, v58] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 5))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 6))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 7))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            
            stdlib.assert(false, 'illegal view')
            },
          ty: ctc1
          },
        owner1: {
          decode: async (i, svs, args) => {
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 1))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v22;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 2))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v22;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 3))) {
              const [v22, v56, v57, v58] = svs;
              return (await ((async () => {
                
                
                return v22;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 4))) {
              const [v22, v56, v57, v58] = svs;
              return (await ((async () => {
                
                
                return v22;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 5))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 6))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 7))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            
            stdlib.assert(false, 'illegal view')
            },
          ty: ctc0
          },
        owner2: {
          decode: async (i, svs, args) => {
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 1))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v31;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 2))) {
              const [v22, v31, v56, v57, v58, v83, v84, v85] = svs;
              return (await ((async () => {
                
                
                return v31;}))(...args));
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 3))) {
              const [v22, v56, v57, v58] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 4))) {
              const [v22, v56, v57, v58] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 5))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 6))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 7))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            
            stdlib.assert(false, 'illegal view')
            },
          ty: ctc0
          }
        }
      },
    views: {
      1: [ctc0, ctc0, ctc1, ctc1, ctc1, ctc1, ctc1, ctc1],
      2: [ctc0, ctc0, ctc1, ctc1, ctc1, ctc1, ctc1, ctc1],
      3: [ctc0, ctc1, ctc1, ctc1],
      4: [ctc0, ctc1, ctc1, ctc1],
      5: [],
      6: [],
      7: []
      }
    };
  
  };

export function _getMaps(s) {
  const stdlib = s.reachStdlib;
  const ctc0 = stdlib.T_Tuple([]);
  return {
    mapDataTy: ctc0
    };
  };

export async function FirBuyer(ctc, interact) {
  if (typeof(ctc) !== 'object' || ctc.sendrecv === undefined) {
    return Promise.reject(new Error(`The backend for FirBuyer expects to receive a contract as its first argument.`));}
  if (typeof(interact) !== 'object') {
    return Promise.reject(new Error(`The backend for FirBuyer expects to receive an interact object as its second argument.`));}
  const stdlib = ctc.stdlib;
  const ctc0 = stdlib.T_Address;
  const ctc1 = stdlib.T_Bytes(stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 32));
  const ctc2 = stdlib.T_UInt;
  const ctc3 = stdlib.T_Null;
  
  
  const v15 = await ctc.creationTime();
  const v16 = await ctc.creationSecs();
  
  const v20 = stdlib.protect(ctc0, await interact.getAcct(), {
    at: './buy.rsh:80:53:application',
    fs: ['at ./buy.rsh:79:16:application call to [unknown function] (defined at: ./buy.rsh:79:20:function exp)'],
    msg: 'getAcct',
    who: 'FirBuyer'
    });
  
  const txn1 = await (ctc.sendrecv({
    args: [v20],
    evt_cnt: 1,
    funcNum: 1,
    onlyIf: true,
    out_tys: [ctc0],
    pay: [stdlib.checkedBigNumberify('./buy.rsh:decimal', stdlib.UInt_max, 0), []],
    sim_p: (async (txn1) => {
      const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
      
      const [v22] = txn1.data;
      const v24 = txn1.time;
      const v25 = txn1.secs;
      const v21 = txn1.from;
      
      sim_r.txns.push({
        amt: stdlib.checkedBigNumberify('./buy.rsh:decimal', stdlib.UInt_max, 0),
        kind: 'to',
        tok: undefined
        });
      sim_r.isHalt = false;
      
      return sim_r;
      }),
    soloSend: true,
    timeoutAt: undefined,
    tys: [ctc0],
    waitIfNotPresent: false
    }));
  const [v22] = txn1.data;
  const v24 = txn1.time;
  const v25 = txn1.secs;
  const v21 = txn1.from;
  ;
  const txn2 = await (ctc.recv({
    evt_cnt: 1,
    funcNum: 2,
    out_tys: [ctc0],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v31] = txn2.data;
  const v33 = txn2.time;
  const v34 = txn2.secs;
  const v30 = txn2.from;
  ;
  const v38 = stdlib.protect(ctc1, await interact.buyNFT(), {
    at: './buy.rsh:96:58:application',
    fs: ['at ./buy.rsh:95:16:application call to [unknown function] (defined at: ./buy.rsh:95:20:function exp)'],
    msg: 'buyNFT',
    who: 'FirBuyer'
    });
  const v39 = stdlib.protect(ctc2, await interact.generat_id(), {
    at: './buy.rsh:97:60:application',
    fs: ['at ./buy.rsh:95:16:application call to [unknown function] (defined at: ./buy.rsh:95:20:function exp)'],
    msg: 'generat_id',
    who: 'FirBuyer'
    });
  stdlib.protect(ctc3, await interact.getTime(v38), {
    at: './buy.rsh:98:21:application',
    fs: ['at ./buy.rsh:95:16:application call to [unknown function] (defined at: ./buy.rsh:95:20:function exp)'],
    msg: 'getTime',
    who: 'FirBuyer'
    });
  
  const txn3 = await (ctc.sendrecv({
    args: [v21, v22, v30, v31, v38, v39],
    evt_cnt: 2,
    funcNum: 3,
    onlyIf: true,
    out_tys: [ctc1, ctc2],
    pay: [stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100), []],
    sim_p: (async (txn3) => {
      const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
      
      const [v41, v42] = txn3.data;
      const v46 = txn3.time;
      const v47 = txn3.secs;
      const v40 = txn3.from;
      
      sim_r.txns.push({
        amt: stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100),
        kind: 'to',
        tok: undefined
        });
      const v45 = stdlib.addressEq(v21, v40);
      stdlib.assert(v45, {
        at: './buy.rsh:103:12:dot',
        fs: [],
        msg: 'sender correct',
        who: 'FirBuyer'
        });
      sim_r.isHalt = false;
      
      return sim_r;
      }),
    soloSend: true,
    timeoutAt: undefined,
    tys: [ctc0, ctc0, ctc0, ctc0, ctc1, ctc2],
    waitIfNotPresent: false
    }));
  const [v41, v42] = txn3.data;
  const v46 = txn3.time;
  const v47 = txn3.secs;
  const v40 = txn3.from;
  ;
  const v45 = stdlib.addressEq(v21, v40);
  stdlib.assert(v45, {
    at: './buy.rsh:103:12:dot',
    fs: [],
    msg: 'sender correct',
    who: 'FirBuyer'
    });
  const txn4 = await (ctc.recv({
    evt_cnt: 4,
    funcNum: 4,
    out_tys: [ctc2, ctc2, ctc2, ctc0],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v56, v57, v58, v59] = txn4.data;
  const v61 = txn4.time;
  const v62 = txn4.secs;
  const v55 = txn4.from;
  ;
  const v114 = stdlib.add(v61, stdlib.checkedBigNumberify('./buy.rsh:134:75:decimal', stdlib.UInt_max, 60));
  const txn5 = await (ctc.recv({
    evt_cnt: 2,
    funcNum: 5,
    out_tys: [ctc1, ctc2],
    timeoutAt: ['time', v114],
    waitIfNotPresent: false
    }));
  if (txn5.didTimeout) {
    const txn6 = await (ctc.sendrecv({
      args: [v21, v22, v30, v31, v55, v56, v57, v58, v114],
      evt_cnt: 0,
      funcNum: 6,
      onlyIf: true,
      out_tys: [],
      pay: [stdlib.checkedBigNumberify('reach standard library:decimal', stdlib.UInt_max, 0), []],
      sim_p: (async (txn6) => {
        const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
        
        const [] = txn6.data;
        const v120 = txn6.time;
        const v121 = txn6.secs;
        const v117 = txn6.from;
        
        sim_r.txns.push({
          amt: stdlib.checkedBigNumberify('reach standard library:decimal', stdlib.UInt_max, 0),
          kind: 'to',
          tok: undefined
          });
        const v119 = stdlib.addressEq(v21, v117);
        stdlib.assert(v119, {
          at: 'reach standard library:209:7:dot',
          fs: ['at ./buy.rsh:134:94:application call to "closeTo" (defined at: reach standard library:207:8:function exp)'],
          msg: 'sender correct',
          who: 'FirBuyer'
          });
        sim_r.txns.push({
          amt: stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100),
          kind: 'from',
          to: v21,
          tok: undefined
          });
        sim_r.txns.push({
          kind: 'halt',
          tok: undefined
          })
        sim_r.isHalt = true;
        
        return sim_r;
        }),
      soloSend: true,
      timeoutAt: undefined,
      tys: [ctc0, ctc0, ctc0, ctc0, ctc0, ctc2, ctc2, ctc2, ctc2],
      waitIfNotPresent: false
      }));
    const [] = txn6.data;
    const v120 = txn6.time;
    const v121 = txn6.secs;
    const v117 = txn6.from;
    ;
    const v119 = stdlib.addressEq(v21, v117);
    stdlib.assert(v119, {
      at: 'reach standard library:209:7:dot',
      fs: ['at ./buy.rsh:134:94:application call to "closeTo" (defined at: reach standard library:207:8:function exp)'],
      msg: 'sender correct',
      who: 'FirBuyer'
      });
    ;
    stdlib.protect(ctc3, await interact.informTimeout(), {
      at: './buy.rsh:74:29:application',
      fs: ['at ./buy.rsh:73:9:application call to [unknown function] (defined at: ./buy.rsh:73:43:function exp)', 'at reach standard library:212:8:application call to "after" (defined at: ./buy.rsh:72:28:function exp)', 'at ./buy.rsh:134:94:application call to "closeTo" (defined at: reach standard library:207:8:function exp)'],
      msg: 'informTimeout',
      who: 'FirBuyer'
      });
    
    return;
    }
  else {
    const [v69, v70] = txn5.data;
    const v74 = txn5.time;
    const v75 = txn5.secs;
    const v68 = txn5.from;
    const v72 = stdlib.add(stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100), stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100));
    ;
    const v73 = stdlib.addressEq(v30, v68);
    stdlib.assert(v73, {
      at: './buy.rsh:134:12:dot',
      fs: [],
      msg: 'sender correct',
      who: 'FirBuyer'
      });
    const txn6 = await (ctc.recv({
      evt_cnt: 3,
      funcNum: 7,
      out_tys: [ctc2, ctc2, ctc2],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [v83, v84, v85] = txn6.data;
    const v88 = txn6.time;
    const v89 = txn6.secs;
    const v82 = txn6.from;
    ;
    const v87 = stdlib.addressEq(v55, v82);
    stdlib.assert(v87, {
      at: './buy.rsh:146:10:dot',
      fs: [],
      msg: 'sender correct',
      who: 'FirBuyer'
      });
    stdlib.protect(ctc3, await interact.showOwner(v22, v42), {
      at: './buy.rsh:157:23:application',
      fs: ['at ./buy.rsh:156:16:application call to [unknown function] (defined at: ./buy.rsh:156:20:function exp)'],
      msg: 'showOwner',
      who: 'FirBuyer'
      });
    
    const txn7 = await (ctc.sendrecv({
      args: [v21, v22, v30, v31, v55, v56, v57, v58, v72, v83, v84, v85],
      evt_cnt: 0,
      funcNum: 8,
      onlyIf: true,
      out_tys: [],
      pay: [stdlib.checkedBigNumberify('./buy.rsh:decimal', stdlib.UInt_max, 0), []],
      sim_p: (async (txn7) => {
        const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
        
        const [] = txn7.data;
        const v96 = txn7.time;
        const v97 = txn7.secs;
        const v93 = txn7.from;
        
        sim_r.txns.push({
          amt: stdlib.checkedBigNumberify('./buy.rsh:decimal', stdlib.UInt_max, 0),
          kind: 'to',
          tok: undefined
          });
        const v95 = stdlib.addressEq(v21, v93);
        stdlib.assert(v95, {
          at: './buy.rsh:159:12:dot',
          fs: [],
          msg: 'sender correct',
          who: 'FirBuyer'
          });
        sim_r.isHalt = false;
        
        return sim_r;
        }),
      soloSend: true,
      timeoutAt: undefined,
      tys: [ctc0, ctc0, ctc0, ctc0, ctc0, ctc2, ctc2, ctc2, ctc2, ctc2, ctc2, ctc2],
      waitIfNotPresent: false
      }));
    const [] = txn7.data;
    const v96 = txn7.time;
    const v97 = txn7.secs;
    const v93 = txn7.from;
    ;
    const v95 = stdlib.addressEq(v21, v93);
    stdlib.assert(v95, {
      at: './buy.rsh:159:12:dot',
      fs: [],
      msg: 'sender correct',
      who: 'FirBuyer'
      });
    const txn8 = await (ctc.recv({
      evt_cnt: 0,
      funcNum: 9,
      out_tys: [],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [] = txn8.data;
    const v104 = txn8.time;
    const v105 = txn8.secs;
    const v101 = txn8.from;
    ;
    const v103 = stdlib.addressEq(v30, v101);
    stdlib.assert(v103, {
      at: './buy.rsh:166:12:dot',
      fs: [],
      msg: 'sender correct',
      who: 'FirBuyer'
      });
    ;
    return;
    
    
    }
  
  
  
  
  
  };
export async function Oracle(ctc, interact) {
  if (typeof(ctc) !== 'object' || ctc.sendrecv === undefined) {
    return Promise.reject(new Error(`The backend for Oracle expects to receive a contract as its first argument.`));}
  if (typeof(interact) !== 'object') {
    return Promise.reject(new Error(`The backend for Oracle expects to receive an interact object as its second argument.`));}
  const stdlib = ctc.stdlib;
  const ctc0 = stdlib.T_Address;
  const ctc1 = stdlib.T_Bytes(stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 32));
  const ctc2 = stdlib.T_UInt;
  const ctc3 = stdlib.T_Null;
  
  
  const v15 = await ctc.creationTime();
  const v16 = await ctc.creationSecs();
  
  const txn1 = await (ctc.recv({
    evt_cnt: 1,
    funcNum: 1,
    out_tys: [ctc0],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v22] = txn1.data;
  const v24 = txn1.time;
  const v25 = txn1.secs;
  const v21 = txn1.from;
  ;
  const txn2 = await (ctc.recv({
    evt_cnt: 1,
    funcNum: 2,
    out_tys: [ctc0],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v31] = txn2.data;
  const v33 = txn2.time;
  const v34 = txn2.secs;
  const v30 = txn2.from;
  ;
  const txn3 = await (ctc.recv({
    evt_cnt: 2,
    funcNum: 3,
    out_tys: [ctc1, ctc2],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v41, v42] = txn3.data;
  const v46 = txn3.time;
  const v47 = txn3.secs;
  const v40 = txn3.from;
  ;
  const v45 = stdlib.addressEq(v21, v40);
  stdlib.assert(v45, {
    at: './buy.rsh:103:12:dot',
    fs: [],
    msg: 'sender correct',
    who: 'Oracle'
    });
  stdlib.protect(ctc3, await interact.getTime(v41), {
    at: './buy.rsh:110:21:application',
    fs: ['at ./buy.rsh:109:14:application call to [unknown function] (defined at: ./buy.rsh:109:18:function exp)'],
    msg: 'getTime',
    who: 'Oracle'
    });
  const v51 = stdlib.protect(ctc2, await interact.get_love(), {
    at: './buy.rsh:111:55:application',
    fs: ['at ./buy.rsh:109:14:application call to [unknown function] (defined at: ./buy.rsh:109:18:function exp)'],
    msg: 'get_love',
    who: 'Oracle'
    });
  const v52 = stdlib.protect(ctc2, await interact.get_career(), {
    at: './buy.rsh:112:59:application',
    fs: ['at ./buy.rsh:109:14:application call to [unknown function] (defined at: ./buy.rsh:109:18:function exp)'],
    msg: 'get_career',
    who: 'Oracle'
    });
  const v53 = stdlib.protect(ctc2, await interact.get_fortune(), {
    at: './buy.rsh:113:61:application',
    fs: ['at ./buy.rsh:109:14:application call to [unknown function] (defined at: ./buy.rsh:109:18:function exp)'],
    msg: 'get_fortune',
    who: 'Oracle'
    });
  const v54 = stdlib.protect(ctc0, await interact.getAcct(), {
    at: './buy.rsh:114:51:application',
    fs: ['at ./buy.rsh:109:14:application call to [unknown function] (defined at: ./buy.rsh:109:18:function exp)'],
    msg: 'getAcct',
    who: 'Oracle'
    });
  
  const txn4 = await (ctc.sendrecv({
    args: [v21, v22, v30, v31, v51, v52, v53, v54],
    evt_cnt: 4,
    funcNum: 4,
    onlyIf: true,
    out_tys: [ctc2, ctc2, ctc2, ctc0],
    pay: [stdlib.checkedBigNumberify('./buy.rsh:decimal', stdlib.UInt_max, 0), []],
    sim_p: (async (txn4) => {
      const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
      
      const [v56, v57, v58, v59] = txn4.data;
      const v61 = txn4.time;
      const v62 = txn4.secs;
      const v55 = txn4.from;
      
      sim_r.txns.push({
        amt: stdlib.checkedBigNumberify('./buy.rsh:decimal', stdlib.UInt_max, 0),
        kind: 'to',
        tok: undefined
        });
      const v114 = stdlib.add(v61, stdlib.checkedBigNumberify('./buy.rsh:134:75:decimal', stdlib.UInt_max, 60));
      sim_r.isHalt = false;
      
      return sim_r;
      }),
    soloSend: true,
    timeoutAt: undefined,
    tys: [ctc0, ctc0, ctc0, ctc0, ctc2, ctc2, ctc2, ctc0],
    waitIfNotPresent: false
    }));
  const [v56, v57, v58, v59] = txn4.data;
  const v61 = txn4.time;
  const v62 = txn4.secs;
  const v55 = txn4.from;
  ;
  const v114 = stdlib.add(v61, stdlib.checkedBigNumberify('./buy.rsh:134:75:decimal', stdlib.UInt_max, 60));
  const txn5 = await (ctc.recv({
    evt_cnt: 2,
    funcNum: 5,
    out_tys: [ctc1, ctc2],
    timeoutAt: ['time', v114],
    waitIfNotPresent: false
    }));
  if (txn5.didTimeout) {
    const txn6 = await (ctc.recv({
      evt_cnt: 0,
      funcNum: 6,
      out_tys: [],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [] = txn6.data;
    const v120 = txn6.time;
    const v121 = txn6.secs;
    const v117 = txn6.from;
    ;
    const v119 = stdlib.addressEq(v21, v117);
    stdlib.assert(v119, {
      at: 'reach standard library:209:7:dot',
      fs: ['at ./buy.rsh:134:94:application call to "closeTo" (defined at: reach standard library:207:8:function exp)'],
      msg: 'sender correct',
      who: 'Oracle'
      });
    ;
    stdlib.protect(ctc3, await interact.informTimeout(), {
      at: './buy.rsh:74:29:application',
      fs: ['at ./buy.rsh:73:9:application call to [unknown function] (defined at: ./buy.rsh:73:43:function exp)', 'at reach standard library:212:8:application call to "after" (defined at: ./buy.rsh:72:28:function exp)', 'at ./buy.rsh:134:94:application call to "closeTo" (defined at: reach standard library:207:8:function exp)'],
      msg: 'informTimeout',
      who: 'Oracle'
      });
    
    return;
    }
  else {
    const [v69, v70] = txn5.data;
    const v74 = txn5.time;
    const v75 = txn5.secs;
    const v68 = txn5.from;
    const v72 = stdlib.add(stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100), stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100));
    ;
    const v73 = stdlib.addressEq(v30, v68);
    stdlib.assert(v73, {
      at: './buy.rsh:134:12:dot',
      fs: [],
      msg: 'sender correct',
      who: 'Oracle'
      });
    stdlib.protect(ctc3, await interact.getTime(v41), {
      at: './buy.rsh:139:21:application',
      fs: ['at ./buy.rsh:138:14:application call to [unknown function] (defined at: ./buy.rsh:138:18:function exp)'],
      msg: 'getTime',
      who: 'Oracle'
      });
    const v79 = stdlib.protect(ctc2, await interact.get_love(), {
      at: './buy.rsh:140:55:application',
      fs: ['at ./buy.rsh:138:14:application call to [unknown function] (defined at: ./buy.rsh:138:18:function exp)'],
      msg: 'get_love',
      who: 'Oracle'
      });
    const v80 = stdlib.protect(ctc2, await interact.get_career(), {
      at: './buy.rsh:141:59:application',
      fs: ['at ./buy.rsh:138:14:application call to [unknown function] (defined at: ./buy.rsh:138:18:function exp)'],
      msg: 'get_career',
      who: 'Oracle'
      });
    const v81 = stdlib.protect(ctc2, await interact.get_fortune(), {
      at: './buy.rsh:142:61:application',
      fs: ['at ./buy.rsh:138:14:application call to [unknown function] (defined at: ./buy.rsh:138:18:function exp)'],
      msg: 'get_fortune',
      who: 'Oracle'
      });
    
    const txn6 = await (ctc.sendrecv({
      args: [v21, v22, v30, v31, v55, v56, v57, v58, v72, v79, v80, v81],
      evt_cnt: 3,
      funcNum: 7,
      onlyIf: true,
      out_tys: [ctc2, ctc2, ctc2],
      pay: [stdlib.checkedBigNumberify('./buy.rsh:decimal', stdlib.UInt_max, 0), []],
      sim_p: (async (txn6) => {
        const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
        
        const [v83, v84, v85] = txn6.data;
        const v88 = txn6.time;
        const v89 = txn6.secs;
        const v82 = txn6.from;
        
        sim_r.txns.push({
          amt: stdlib.checkedBigNumberify('./buy.rsh:decimal', stdlib.UInt_max, 0),
          kind: 'to',
          tok: undefined
          });
        const v87 = stdlib.addressEq(v55, v82);
        stdlib.assert(v87, {
          at: './buy.rsh:146:10:dot',
          fs: [],
          msg: 'sender correct',
          who: 'Oracle'
          });
        sim_r.isHalt = false;
        
        return sim_r;
        }),
      soloSend: true,
      timeoutAt: undefined,
      tys: [ctc0, ctc0, ctc0, ctc0, ctc0, ctc2, ctc2, ctc2, ctc2, ctc2, ctc2, ctc2],
      waitIfNotPresent: false
      }));
    const [v83, v84, v85] = txn6.data;
    const v88 = txn6.time;
    const v89 = txn6.secs;
    const v82 = txn6.from;
    ;
    const v87 = stdlib.addressEq(v55, v82);
    stdlib.assert(v87, {
      at: './buy.rsh:146:10:dot',
      fs: [],
      msg: 'sender correct',
      who: 'Oracle'
      });
    const txn7 = await (ctc.recv({
      evt_cnt: 0,
      funcNum: 8,
      out_tys: [],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [] = txn7.data;
    const v96 = txn7.time;
    const v97 = txn7.secs;
    const v93 = txn7.from;
    ;
    const v95 = stdlib.addressEq(v21, v93);
    stdlib.assert(v95, {
      at: './buy.rsh:159:12:dot',
      fs: [],
      msg: 'sender correct',
      who: 'Oracle'
      });
    const txn8 = await (ctc.recv({
      evt_cnt: 0,
      funcNum: 9,
      out_tys: [],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [] = txn8.data;
    const v104 = txn8.time;
    const v105 = txn8.secs;
    const v101 = txn8.from;
    ;
    const v103 = stdlib.addressEq(v30, v101);
    stdlib.assert(v103, {
      at: './buy.rsh:166:12:dot',
      fs: [],
      msg: 'sender correct',
      who: 'Oracle'
      });
    ;
    return;
    
    
    }
  
  
  
  
  
  };
export async function SecBuyer(ctc, interact) {
  if (typeof(ctc) !== 'object' || ctc.sendrecv === undefined) {
    return Promise.reject(new Error(`The backend for SecBuyer expects to receive a contract as its first argument.`));}
  if (typeof(interact) !== 'object') {
    return Promise.reject(new Error(`The backend for SecBuyer expects to receive an interact object as its second argument.`));}
  const stdlib = ctc.stdlib;
  const ctc0 = stdlib.T_Address;
  const ctc1 = stdlib.T_Bytes(stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 32));
  const ctc2 = stdlib.T_UInt;
  const ctc3 = stdlib.T_Null;
  
  
  const v15 = await ctc.creationTime();
  const v16 = await ctc.creationSecs();
  
  const txn1 = await (ctc.recv({
    evt_cnt: 1,
    funcNum: 1,
    out_tys: [ctc0],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v22] = txn1.data;
  const v24 = txn1.time;
  const v25 = txn1.secs;
  const v21 = txn1.from;
  ;
  const v29 = stdlib.protect(ctc0, await interact.getAcct(), {
    at: './buy.rsh:87:53:application',
    fs: ['at ./buy.rsh:86:16:application call to [unknown function] (defined at: ./buy.rsh:86:20:function exp)'],
    msg: 'getAcct',
    who: 'SecBuyer'
    });
  
  const txn2 = await (ctc.sendrecv({
    args: [v21, v22, v29],
    evt_cnt: 1,
    funcNum: 2,
    onlyIf: true,
    out_tys: [ctc0],
    pay: [stdlib.checkedBigNumberify('./buy.rsh:decimal', stdlib.UInt_max, 0), []],
    sim_p: (async (txn2) => {
      const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
      
      const [v31] = txn2.data;
      const v33 = txn2.time;
      const v34 = txn2.secs;
      const v30 = txn2.from;
      
      sim_r.txns.push({
        amt: stdlib.checkedBigNumberify('./buy.rsh:decimal', stdlib.UInt_max, 0),
        kind: 'to',
        tok: undefined
        });
      sim_r.isHalt = false;
      
      return sim_r;
      }),
    soloSend: true,
    timeoutAt: undefined,
    tys: [ctc0, ctc0, ctc0],
    waitIfNotPresent: false
    }));
  const [v31] = txn2.data;
  const v33 = txn2.time;
  const v34 = txn2.secs;
  const v30 = txn2.from;
  ;
  const txn3 = await (ctc.recv({
    evt_cnt: 2,
    funcNum: 3,
    out_tys: [ctc1, ctc2],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v41, v42] = txn3.data;
  const v46 = txn3.time;
  const v47 = txn3.secs;
  const v40 = txn3.from;
  ;
  const v45 = stdlib.addressEq(v21, v40);
  stdlib.assert(v45, {
    at: './buy.rsh:103:12:dot',
    fs: [],
    msg: 'sender correct',
    who: 'SecBuyer'
    });
  const txn4 = await (ctc.recv({
    evt_cnt: 4,
    funcNum: 4,
    out_tys: [ctc2, ctc2, ctc2, ctc0],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v56, v57, v58, v59] = txn4.data;
  const v61 = txn4.time;
  const v62 = txn4.secs;
  const v55 = txn4.from;
  ;
  const v114 = stdlib.add(v61, stdlib.checkedBigNumberify('./buy.rsh:134:75:decimal', stdlib.UInt_max, 60));
  const v66 = stdlib.protect(ctc1, await interact.buyNFT(), {
    at: './buy.rsh:129:58:application',
    fs: ['at ./buy.rsh:128:16:application call to [unknown function] (defined at: ./buy.rsh:128:20:function exp)'],
    msg: 'buyNFT',
    who: 'SecBuyer'
    });
  const v67 = stdlib.protect(ctc2, await interact.generat_id(), {
    at: './buy.rsh:130:60:application',
    fs: ['at ./buy.rsh:128:16:application call to [unknown function] (defined at: ./buy.rsh:128:20:function exp)'],
    msg: 'generat_id',
    who: 'SecBuyer'
    });
  stdlib.protect(ctc3, await interact.getTime(v66), {
    at: './buy.rsh:131:21:application',
    fs: ['at ./buy.rsh:128:16:application call to [unknown function] (defined at: ./buy.rsh:128:20:function exp)'],
    msg: 'getTime',
    who: 'SecBuyer'
    });
  
  const txn5 = await (ctc.sendrecv({
    args: [v21, v22, v30, v31, v55, v56, v57, v58, v114, v66, v67],
    evt_cnt: 2,
    funcNum: 5,
    onlyIf: true,
    out_tys: [ctc1, ctc2],
    pay: [stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100), []],
    sim_p: (async (txn5) => {
      const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
      
      const [v69, v70] = txn5.data;
      const v74 = txn5.time;
      const v75 = txn5.secs;
      const v68 = txn5.from;
      
      const v72 = stdlib.add(stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100), stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100));
      sim_r.txns.push({
        amt: stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100),
        kind: 'to',
        tok: undefined
        });
      const v73 = stdlib.addressEq(v30, v68);
      stdlib.assert(v73, {
        at: './buy.rsh:134:12:dot',
        fs: [],
        msg: 'sender correct',
        who: 'SecBuyer'
        });
      sim_r.isHalt = false;
      
      return sim_r;
      }),
    soloSend: true,
    timeoutAt: ['time', v114],
    tys: [ctc0, ctc0, ctc0, ctc0, ctc0, ctc2, ctc2, ctc2, ctc2, ctc1, ctc2],
    waitIfNotPresent: false
    }));
  if (txn5.didTimeout) {
    const txn6 = await (ctc.recv({
      evt_cnt: 0,
      funcNum: 6,
      out_tys: [],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [] = txn6.data;
    const v120 = txn6.time;
    const v121 = txn6.secs;
    const v117 = txn6.from;
    ;
    const v119 = stdlib.addressEq(v21, v117);
    stdlib.assert(v119, {
      at: 'reach standard library:209:7:dot',
      fs: ['at ./buy.rsh:134:94:application call to "closeTo" (defined at: reach standard library:207:8:function exp)'],
      msg: 'sender correct',
      who: 'SecBuyer'
      });
    ;
    stdlib.protect(ctc3, await interact.informTimeout(), {
      at: './buy.rsh:74:29:application',
      fs: ['at ./buy.rsh:73:9:application call to [unknown function] (defined at: ./buy.rsh:73:43:function exp)', 'at reach standard library:212:8:application call to "after" (defined at: ./buy.rsh:72:28:function exp)', 'at ./buy.rsh:134:94:application call to "closeTo" (defined at: reach standard library:207:8:function exp)'],
      msg: 'informTimeout',
      who: 'SecBuyer'
      });
    
    return;
    }
  else {
    const [v69, v70] = txn5.data;
    const v74 = txn5.time;
    const v75 = txn5.secs;
    const v68 = txn5.from;
    const v72 = stdlib.add(stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100), stdlib.checkedBigNumberify('./buy.rsh:101:15:decimal', stdlib.UInt_max, 100));
    ;
    const v73 = stdlib.addressEq(v30, v68);
    stdlib.assert(v73, {
      at: './buy.rsh:134:12:dot',
      fs: [],
      msg: 'sender correct',
      who: 'SecBuyer'
      });
    const txn6 = await (ctc.recv({
      evt_cnt: 3,
      funcNum: 7,
      out_tys: [ctc2, ctc2, ctc2],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [v83, v84, v85] = txn6.data;
    const v88 = txn6.time;
    const v89 = txn6.secs;
    const v82 = txn6.from;
    ;
    const v87 = stdlib.addressEq(v55, v82);
    stdlib.assert(v87, {
      at: './buy.rsh:146:10:dot',
      fs: [],
      msg: 'sender correct',
      who: 'SecBuyer'
      });
    const txn7 = await (ctc.recv({
      evt_cnt: 0,
      funcNum: 8,
      out_tys: [],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [] = txn7.data;
    const v96 = txn7.time;
    const v97 = txn7.secs;
    const v93 = txn7.from;
    ;
    const v95 = stdlib.addressEq(v21, v93);
    stdlib.assert(v95, {
      at: './buy.rsh:159:12:dot',
      fs: [],
      msg: 'sender correct',
      who: 'SecBuyer'
      });
    stdlib.protect(ctc3, await interact.showOwner(v31, v70), {
      at: './buy.rsh:164:23:application',
      fs: ['at ./buy.rsh:163:16:application call to [unknown function] (defined at: ./buy.rsh:163:20:function exp)'],
      msg: 'showOwner',
      who: 'SecBuyer'
      });
    
    const txn8 = await (ctc.sendrecv({
      args: [v30, v55, v72],
      evt_cnt: 0,
      funcNum: 9,
      onlyIf: true,
      out_tys: [],
      pay: [stdlib.checkedBigNumberify('./buy.rsh:decimal', stdlib.UInt_max, 0), []],
      sim_p: (async (txn8) => {
        const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
        
        const [] = txn8.data;
        const v104 = txn8.time;
        const v105 = txn8.secs;
        const v101 = txn8.from;
        
        sim_r.txns.push({
          amt: stdlib.checkedBigNumberify('./buy.rsh:decimal', stdlib.UInt_max, 0),
          kind: 'to',
          tok: undefined
          });
        const v103 = stdlib.addressEq(v30, v101);
        stdlib.assert(v103, {
          at: './buy.rsh:166:12:dot',
          fs: [],
          msg: 'sender correct',
          who: 'SecBuyer'
          });
        sim_r.txns.push({
          amt: v72,
          kind: 'from',
          to: v55,
          tok: undefined
          });
        sim_r.txns.push({
          kind: 'halt',
          tok: undefined
          })
        sim_r.isHalt = true;
        
        return sim_r;
        }),
      soloSend: true,
      timeoutAt: undefined,
      tys: [ctc0, ctc0, ctc2],
      waitIfNotPresent: false
      }));
    const [] = txn8.data;
    const v104 = txn8.time;
    const v105 = txn8.secs;
    const v101 = txn8.from;
    ;
    const v103 = stdlib.addressEq(v30, v101);
    stdlib.assert(v103, {
      at: './buy.rsh:166:12:dot',
      fs: [],
      msg: 'sender correct',
      who: 'SecBuyer'
      });
    ;
    return;
    
    
    }
  
  
  
  
  
  };

const _ALGO = {
  appApproval: `#pragma version 4
txn RekeyTo
global ZeroAddress
==
assert
txn Lease
global ZeroAddress
==
assert
int 0
store 0
txn ApplicationID
bz alloc
byte base64()
app_global_get
dup
substring 0 32
store 1
substring 32 64
store 2
txn NumAppArgs
int 3
==
assert
txna ApplicationArgs 0
btoi
dup
bz ctor
// Handler 1
dup
int 1
==
bz l0
pop
txna ApplicationArgs 1
dup
len
int 0
==
assert
pop
txna ApplicationArgs 2
dup
len
int 32
==
assert
dup
store 255
pop
// compute state in HM_Check 0
int 8
bzero
sha256
load 1
==
assert
// "CheckPay"
// "./buy.rsh:83:12:dot"
// "[]"
byte base64(AAAAAAAAAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA)
int 1
bzero
dig 1
substring 0 120
app_global_put
pop
// compute state in HM_Set 1
byte base64(AAAAAAAAAAE=)
txn Sender
concat
load 255
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l0:
// Handler 2
dup
int 2
==
bz l1
pop
txna ApplicationArgs 1
dup
len
int 64
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
pop
txna ApplicationArgs 2
dup
len
int 32
==
assert
dup
store 253
pop
// compute state in HM_Check 1
byte base64(AAAAAAAAAAE=)
load 255
concat
load 254
concat
sha256
load 1
==
assert
// "CheckPay"
// "./buy.rsh:90:12:dot"
// "[]"
byte base64(AAAAAAAAAAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA)
int 1
bzero
dig 1
substring 0 120
app_global_put
pop
// compute state in HM_Set 2
byte base64(AAAAAAAAAAI=)
load 255
concat
load 254
concat
txn Sender
concat
load 253
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l1:
// Handler 3
dup
int 3
==
bz l2
pop
txna ApplicationArgs 1
dup
len
int 128
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
pop
txna ApplicationArgs 2
dup
len
int 40
==
assert
dup
substring 0 32
store 251
dup
substring 32 40
btoi
store 250
pop
// compute state in HM_Check 2
byte base64(AAAAAAAAAAI=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
sha256
load 1
==
assert
// "CheckPay"
// "./buy.rsh:103:12:dot"
// "[]"
int 100
dup
bz l3
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Receiver
==
assert
l3:
pop
// Just "sender correct"
// "./buy.rsh:103:12:dot"
// "[]"
load 255
txn Sender
==
assert
byte base64(AAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA)
int 1
bzero
dig 1
substring 0 120
app_global_put
pop
// compute state in HM_Set 3
byte base64(AAAAAAAAAAM=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l2:
// Handler 4
dup
int 4
==
bz l4
pop
txna ApplicationArgs 1
dup
len
int 128
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
pop
txna ApplicationArgs 2
dup
len
int 56
==
assert
dup
substring 0 8
btoi
store 251
dup
substring 8 16
btoi
store 250
dup
substring 16 24
btoi
store 249
dup
substring 24 56
store 248
pop
// compute state in HM_Check 3
byte base64(AAAAAAAAAAM=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
sha256
load 1
==
assert
// "CheckPay"
// "./buy.rsh:118:10:dot"
// "[]"
global Round
int 60
+
store 247
byte base64(AAAAAAAAAAQ=)
load 254
concat
load 251
itob
concat
load 250
itob
concat
load 249
itob
concat
int 56
bzero
concat
int 1
bzero
dig 1
substring 0 120
app_global_put
pop
// compute state in HM_Set 4
byte base64(AAAAAAAAAAQ=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
txn Sender
concat
load 251
itob
concat
load 250
itob
concat
load 249
itob
concat
load 247
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l4:
// Handler 5
dup
int 5
==
bz l5
pop
txna ApplicationArgs 1
dup
len
int 192
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
dup
substring 128 160
store 251
dup
substring 160 168
btoi
store 250
dup
substring 168 176
btoi
store 249
dup
substring 176 184
btoi
store 248
dup
substring 184 192
btoi
store 247
pop
txna ApplicationArgs 2
dup
len
int 40
==
assert
dup
substring 0 32
store 246
dup
substring 32 40
btoi
store 245
pop
// compute state in HM_Check 4
byte base64(AAAAAAAAAAQ=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
concat
load 250
itob
concat
load 249
itob
concat
load 248
itob
concat
load 247
itob
concat
sha256
load 1
==
assert
global Round
load 247
<
assert
int 100
int 100
+
store 244
// "CheckPay"
// "./buy.rsh:134:12:dot"
// "[]"
int 100
dup
bz l6
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Receiver
==
assert
l6:
pop
// Just "sender correct"
// "./buy.rsh:134:12:dot"
// "[]"
load 253
txn Sender
==
assert
byte base64(AAAAAAAAAAM=)
load 254
concat
load 250
itob
concat
load 249
itob
concat
load 248
itob
concat
int 56
bzero
concat
int 1
bzero
dig 1
substring 0 120
app_global_put
pop
// compute state in HM_Set 6
byte base64(AAAAAAAAAAY=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
concat
load 250
itob
concat
load 249
itob
concat
load 248
itob
concat
load 244
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l5:
// Handler 6
dup
int 6
==
bz l7
pop
txna ApplicationArgs 1
dup
len
int 192
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
dup
substring 128 160
store 251
dup
substring 160 168
btoi
store 250
dup
substring 168 176
btoi
store 249
dup
substring 176 184
btoi
store 248
dup
substring 184 192
btoi
store 247
pop
txna ApplicationArgs 2
dup
len
int 0
==
assert
pop
// compute state in HM_Check 4
byte base64(AAAAAAAAAAQ=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
concat
load 250
itob
concat
load 249
itob
concat
load 248
itob
concat
load 247
itob
concat
sha256
load 1
==
assert
global Round
load 247
>=
assert
// "CheckPay"
// "reach standard library:209:7:dot"
// "[at ./buy.rsh:134:94:application call to \"closeTo\" (defined at: reach standard library:207:8:function exp)]"
// Just "sender correct"
// "reach standard library:209:7:dot"
// "[at ./buy.rsh:134:94:application call to \"closeTo\" (defined at: reach standard library:207:8:function exp)]"
load 255
txn Sender
==
assert
int 100
dup
bz l8
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
load 255
dig 1
gtxns Receiver
==
assert
l8:
pop
int 0
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
global CreatorAddress
dig 1
gtxns CloseRemainderTo
==
assert
l9:
pop
global ZeroAddress
store 1
txn OnCompletion
int DeleteApplication
==
assert
b updateState
l7:
// Handler 7
dup
int 7
==
bz l10
pop
txna ApplicationArgs 1
dup
len
int 192
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
dup
substring 128 160
store 251
dup
substring 160 168
btoi
store 250
dup
substring 168 176
btoi
store 249
dup
substring 176 184
btoi
store 248
dup
substring 184 192
btoi
store 247
pop
txna ApplicationArgs 2
dup
len
int 24
==
assert
dup
substring 0 8
btoi
store 246
dup
substring 8 16
btoi
store 245
dup
substring 16 24
btoi
store 244
pop
// compute state in HM_Check 6
byte base64(AAAAAAAAAAY=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
concat
load 250
itob
concat
load 249
itob
concat
load 248
itob
concat
load 247
itob
concat
sha256
load 1
==
assert
// "CheckPay"
// "./buy.rsh:146:10:dot"
// "[]"
// Just "sender correct"
// "./buy.rsh:146:10:dot"
// "[]"
load 251
txn Sender
==
assert
byte base64(AAAAAAAAAAI=)
load 254
concat
load 252
concat
load 250
itob
concat
load 249
itob
concat
load 248
itob
concat
load 246
itob
concat
load 245
itob
concat
load 244
itob
concat
int 1
bzero
dig 1
substring 0 120
app_global_put
pop
// compute state in HM_Set 7
byte base64(AAAAAAAAAAc=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
concat
load 250
itob
concat
load 249
itob
concat
load 248
itob
concat
load 247
itob
concat
load 246
itob
concat
load 245
itob
concat
load 244
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l10:
// Handler 8
dup
int 8
==
bz l11
pop
txna ApplicationArgs 1
dup
len
int 216
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
dup
substring 128 160
store 251
dup
substring 160 168
btoi
store 250
dup
substring 168 176
btoi
store 249
dup
substring 176 184
btoi
store 248
dup
substring 184 192
btoi
store 247
dup
substring 192 200
btoi
store 246
dup
substring 200 208
btoi
store 245
dup
substring 208 216
btoi
store 244
pop
txna ApplicationArgs 2
dup
len
int 0
==
assert
pop
// compute state in HM_Check 7
byte base64(AAAAAAAAAAc=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
concat
load 250
itob
concat
load 249
itob
concat
load 248
itob
concat
load 247
itob
concat
load 246
itob
concat
load 245
itob
concat
load 244
itob
concat
sha256
load 1
==
assert
// "CheckPay"
// "./buy.rsh:159:12:dot"
// "[]"
// Just "sender correct"
// "./buy.rsh:159:12:dot"
// "[]"
load 255
txn Sender
==
assert
byte base64(AAAAAAAAAAE=)
load 254
concat
load 252
concat
load 250
itob
concat
load 249
itob
concat
load 248
itob
concat
load 246
itob
concat
load 245
itob
concat
load 244
itob
concat
int 1
bzero
dig 1
substring 0 120
app_global_put
pop
// compute state in HM_Set 8
byte base64(AAAAAAAAAAg=)
load 253
concat
load 251
concat
load 247
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l11:
// Handler 9
dup
int 9
==
bz l12
pop
txna ApplicationArgs 1
dup
len
int 72
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 72
btoi
store 253
pop
txna ApplicationArgs 2
dup
len
int 0
==
assert
pop
// compute state in HM_Check 8
byte base64(AAAAAAAAAAg=)
load 255
concat
load 254
concat
load 253
itob
concat
sha256
load 1
==
assert
// "CheckPay"
// "./buy.rsh:166:12:dot"
// "[]"
// Just "sender correct"
// "./buy.rsh:166:12:dot"
// "[]"
load 255
txn Sender
==
assert
load 253
dup
bz l13
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
load 254
dig 1
gtxns Receiver
==
assert
l13:
pop
int 0
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
global CreatorAddress
dig 1
gtxns CloseRemainderTo
==
assert
l14:
pop
global ZeroAddress
store 1
txn OnCompletion
int DeleteApplication
==
assert
b updateState
l12:
int 0
assert
updateState:
byte base64()
load 1
load 2
concat
app_global_put
checkSize:
load 0
dup
dup
int 1
+
global GroupSize
==
assert
txn GroupIndex
==
assert
int 1000
*
txn Fee
<=
assert
done:
int 1
return
alloc:
txn OnCompletion
int NoOp
==
assert
byte base64()
int 64
bzero
app_global_put
b checkSize
ctor:
txn Sender
global CreatorAddress
==
assert
txna ApplicationArgs 1
store 2
int 120
bzero
int 1
bzero
dig 1
substring 0 120
app_global_put
pop
// compute state in HM_Set 0
int 8
bzero
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
`,
  appClear: `#pragma version 4
int 0
`,
  escrow: `#pragma version 4
global GroupSize
int 1
-
dup
gtxns TypeEnum
int appl
==
assert
gtxns ApplicationID
int {{ApplicationID}}
==
assert
done:
int 1
`,
  mapDataKeys: 0,
  mapDataSize: 0,
  unsupported: [],
  version: 2,
  viewKeys: 1,
  viewSize: 120
  };
const _ETH = {
  ABI: `[
  {
    "inputs": [],
    "stateMutability": "payable",
    "type": "constructor"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "msg",
        "type": "uint256"
      }
    ],
    "name": "ReachError",
    "type": "error"
  },
  {
    "anonymous": false,
    "inputs": [],
    "name": "e0",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "internalType": "bool",
            "name": "svs",
            "type": "bool"
          },
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              }
            ],
            "internalType": "struct T4",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T5",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e1",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              }
            ],
            "internalType": "struct T3",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              }
            ],
            "internalType": "struct T7",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T8",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e2",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              }
            ],
            "internalType": "struct T6",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint8[32]",
                "name": "v41",
                "type": "uint8[32]"
              },
              {
                "internalType": "uint256",
                "name": "v42",
                "type": "uint256"
              }
            ],
            "internalType": "struct T9",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T10",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e3",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              }
            ],
            "internalType": "struct T6",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint256",
                "name": "v56",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v57",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v58",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v59",
                "type": "address"
              }
            ],
            "internalType": "struct T12",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T13",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e4",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v55",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v56",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v57",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v58",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v114",
                "type": "uint256"
              }
            ],
            "internalType": "struct T11",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint8[32]",
                "name": "v69",
                "type": "uint8[32]"
              },
              {
                "internalType": "uint256",
                "name": "v70",
                "type": "uint256"
              }
            ],
            "internalType": "struct T15",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T16",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e5",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v55",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v56",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v57",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v58",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v114",
                "type": "uint256"
              }
            ],
            "internalType": "struct T11",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "indexed": false,
        "internalType": "struct T17",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e6",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v55",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v56",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v57",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v58",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v72",
                "type": "uint256"
              }
            ],
            "internalType": "struct T14",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint256",
                "name": "v83",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v84",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v85",
                "type": "uint256"
              }
            ],
            "internalType": "struct T19",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T20",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e7",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v55",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v56",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v57",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v58",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v72",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v83",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v84",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v85",
                "type": "uint256"
              }
            ],
            "internalType": "struct T18",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "indexed": false,
        "internalType": "struct T22",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e8",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v55",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v72",
                "type": "uint256"
              }
            ],
            "internalType": "struct T21",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "indexed": false,
        "internalType": "struct T23",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e9",
    "type": "event"
  },
  {
    "inputs": [],
    "name": "NFT_career1",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "NFT_career2",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "NFT_fortune1",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "NFT_fortune2",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "NFT_love1",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "NFT_love2",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "NFT_owner1",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "NFT_owner2",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "internalType": "bool",
            "name": "svs",
            "type": "bool"
          },
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              }
            ],
            "internalType": "struct T4",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T5",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m1",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              }
            ],
            "internalType": "struct T3",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              }
            ],
            "internalType": "struct T7",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T8",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m2",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              }
            ],
            "internalType": "struct T6",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint8[32]",
                "name": "v41",
                "type": "uint8[32]"
              },
              {
                "internalType": "uint256",
                "name": "v42",
                "type": "uint256"
              }
            ],
            "internalType": "struct T9",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T10",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m3",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              }
            ],
            "internalType": "struct T6",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint256",
                "name": "v56",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v57",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v58",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v59",
                "type": "address"
              }
            ],
            "internalType": "struct T12",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T13",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m4",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v55",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v56",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v57",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v58",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v114",
                "type": "uint256"
              }
            ],
            "internalType": "struct T11",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint8[32]",
                "name": "v69",
                "type": "uint8[32]"
              },
              {
                "internalType": "uint256",
                "name": "v70",
                "type": "uint256"
              }
            ],
            "internalType": "struct T15",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T16",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m5",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v55",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v56",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v57",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v58",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v114",
                "type": "uint256"
              }
            ],
            "internalType": "struct T11",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "internalType": "struct T17",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m6",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v55",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v56",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v57",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v58",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v72",
                "type": "uint256"
              }
            ],
            "internalType": "struct T14",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint256",
                "name": "v83",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v84",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v85",
                "type": "uint256"
              }
            ],
            "internalType": "struct T19",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T20",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m7",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v21",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v22",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v55",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v56",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v57",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v58",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v72",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v83",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v84",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v85",
                "type": "uint256"
              }
            ],
            "internalType": "struct T18",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "internalType": "struct T22",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m8",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v30",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v55",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v72",
                "type": "uint256"
              }
            ],
            "internalType": "struct T21",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "internalType": "struct T23",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m9",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "stateMutability": "payable",
    "type": "receive"
  }
]`,
  Bytecode: `0x608060408190527f49ff028a829527a47ec6839c7147b484eccf5a2a94853eddac09cef44d9d4e9e90600090a160408051808201825243815242602080830191909152600060018190558351918201819052919201604051602081830303815290604052600290805190602001906200007a929190620000b6565b506040805160006020820181905291810182905260600160408051601f1981840301815291905280516020909101206000555062000199915050565b828054620000c4906200015c565b90600052602060002090601f016020900481019282620000e8576000855562000133565b82601f106200010357805160ff191683800117855562000133565b8280016001018555821562000133579182015b828111156200013357825182559160200191906001019062000116565b506200014192915062000145565b5090565b5b8082111562000141576000815560010162000146565b600181811c908216806200017157607f821691505b602082108114156200019357634e487b7160e01b600052602260045260246000fd5b50919050565b613f0980620001a96000396000f3fe6080604052600436106101025760003560e01c80636c6330e311610095578063aff2708311610064578063aff270831461022f578063c9c2845a14610242578063ce3c28a714610255578063dbb2198714610268578063fbfca82d1461027b57600080fd5b80636c6330e3146101dd57806385b1b6aa146101f257806394206fa714610207578063a343c7161461021a57600080fd5b80632b9d4ce6116100d15780632b9d4ce61461017357806346f8ed2a1461018857806355f40150146101b5578063594a0b36146101ca57600080fd5b80630775e07b1461010e5780630d8a11ca1461013657806319011ec61461014b57806326e99cb41461015e57600080fd5b3661010957005b600080fd5b34801561011a57600080fd5b5061012361028e565b6040519081526020015b60405180910390f35b6101496101443660046136d1565b61066d565b005b61014961015936600461386f565b610937565b34801561016a57600080fd5b50610123610aa8565b34801561017f57600080fd5b50610123610f2b565b34801561019457600080fd5b5061019d6113ae565b6040516001600160a01b03909116815260200161012d565b3480156101c157600080fd5b5061019d61177d565b6101496101d83660046136e4565b611c00565b3480156101e957600080fd5b50610123611d13565b3480156101fe57600080fd5b50610123612196565b6101496102153660046136a5565b612568565b34801561022657600080fd5b506101236126f1565b61014961023d36600461385d565b612ab9565b6101496102503660046137bb565b612bed565b6101496102633660046137a8565b612deb565b6101496102763660046136be565b61319d565b6101496102893660046137ce565b6133e5565b6000600180541415610344576000600280546102a990613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546102d590613e7b565b80156103225780601f106102f757610100808354040283529160200191610322565b820191906000526020600020905b81548152906001019060200180831161030557829003601f168201915b505050505080602001905181019061033a91906136f7565b6080015192915050565b6002600154141561035e576000600280546102a990613e7b565b600360015414156104135760006002805461037890613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546103a490613e7b565b80156103f15780601f106103c6576101008083540402835291602001916103f1565b820191906000526020600020905b8154815290600101906020018083116103d457829003601f168201915b505050505080602001905181019061040991906137e0565b6060015192915050565b6004600154141561042d5760006002805461037890613e7b565b600560015414156104e85760006002805461044790613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461047390613e7b565b80156104c05780601f10610495576101008083540402835291602001916104c0565b820191906000526020600020905b8154815290600101906020018083116104a357829003601f168201915b50505050508060200190518101906104d89190613688565b90506104e6600060096134d6565b505b600660015414156105a35760006002805461050290613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461052e90613e7b565b801561057b5780601f106105505761010080835404028352916020019161057b565b820191906000526020600020905b81548152906001019060200180831161055e57829003601f168201915b50505050508060200190518101906105939190613688565b90506105a1600060096134d6565b505b6007600154141561065e576000600280546105bd90613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546105e990613e7b565b80156106365780601f1061060b57610100808354040283529160200191610636565b820191906000526020600020905b81548152906001019060200180831161061957829003601f168201915b505050505080602001905181019061064e9190613688565b905061065c600060096134d6565b505b61066a600060096134d6565b90565b6040516106a990610685906004908490602001613d30565b6040516020818303038152906040528051906020012060001c60005414601a6134d6565b600080805560408051602081019091529081526106ce6101008301354310601b6134d6565b7fd505867eab41454710361ad9c3adf4329f7510d9455ab4997f1d1be98f43ec70826040516106fd9190613b8a565b60405180910390a1610710606480613e55565b81526107203460641460186134d6565b610745336107346060850160408601613647565b6001600160a01b03161460196134d6565b610779604051806080016040528060006001600160a01b031681526020016000815260200160008152602001600081525090565b6107896040840160208501613647565b6001600160a01b031680825260a084810135602080850191825260c0870135604080870191825260e089013560608089019182526003600155825194850197909752935190830152519381019390935251608083015201604051602081830303815290604052600290805190602001906108049291906134ff565b50604080516101208101825260008082526020808301829052928201819052606082018190526080820181905260a0820181905260c0820181905260e082018190526101008201529061085990850185613647565b6001600160a01b031681526108746040850160208601613647565b6001600160a01b031660208201526108926060850160408601613647565b6001600160a01b031660408201526108b06080850160608601613647565b6001600160a01b031660608201526108ce60a0850160808601613647565b6001600160a01b0316608082015260a0808501359082015260c0808501359082015260e080850135908201528251610100820152604051610916906006908390602001613d45565b60408051601f19818403018152919052805160209091012060005550505050565b6040516109739061094f906001908490602001613de8565b6040516020818303038152906040528051906020012060001c6000541460126134d6565b600080556040517f4ddeafe2e741572a5fd34f51f4f327462eb72eda75cbfa14d053b0c8cd89c967906109a7908390613cfc565b60405180910390a16109bb341560116134d6565b6006600155604080516000602082018190529101604051602081830303815290604052600290805190602001906109f39291906134ff565b506040805160808101825260008082526020808301829052928201819052606082015290610a2390840184613647565b6001600160a01b03168152610a3e6040840160208501613647565b6001600160a01b0316602082015233604080830191909152610a669060608501908501613647565b6001600160a01b03166060820152604051610a88906002908390602001613e10565b60408051601f198184030181529190528051602090910120600055505050565b6000600180541415610b5e57600060028054610ac390613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054610aef90613e7b565b8015610b3c5780601f10610b1157610100808354040283529160200191610b3c565b820191906000526020600020905b815481529060010190602001808311610b1f57829003601f168201915b5050505050806020019051810190610b5491906136f7565b60c0015192915050565b60026001541415610b7857600060028054610ac390613e7b565b60036001541415610c3357600060028054610b9290613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054610bbe90613e7b565b8015610c0b5780601f10610be057610100808354040283529160200191610c0b565b820191906000526020600020905b815481529060010190602001808311610bee57829003601f168201915b5050505050806020019051810190610c2391906137e0565b9050610c31600060086134d6565b505b60046001541415610cee57600060028054610c4d90613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054610c7990613e7b565b8015610cc65780601f10610c9b57610100808354040283529160200191610cc6565b820191906000526020600020905b815481529060010190602001808311610ca957829003601f168201915b5050505050806020019051810190610cde91906137e0565b9050610cec600060086134d6565b505b60056001541415610da957600060028054610d0890613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054610d3490613e7b565b8015610d815780601f10610d5657610100808354040283529160200191610d81565b820191906000526020600020905b815481529060010190602001808311610d6457829003601f168201915b5050505050806020019051810190610d999190613688565b9050610da7600060086134d6565b505b60066001541415610e6457600060028054610dc390613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054610def90613e7b565b8015610e3c5780601f10610e1157610100808354040283529160200191610e3c565b820191906000526020600020905b815481529060010190602001808311610e1f57829003601f168201915b5050505050806020019051810190610e549190613688565b9050610e62600060086134d6565b505b60076001541415610f1f57600060028054610e7e90613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054610eaa90613e7b565b8015610ef75780601f10610ecc57610100808354040283529160200191610ef7565b820191906000526020600020905b815481529060010190602001808311610eda57829003601f168201915b5050505050806020019051810190610f0f9190613688565b9050610f1d600060086134d6565b505b61066a600060086134d6565b6000600180541415610fe157600060028054610f4690613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054610f7290613e7b565b8015610fbf5780601f10610f9457610100808354040283529160200191610fbf565b820191906000526020600020905b815481529060010190602001808311610fa257829003601f168201915b5050505050806020019051810190610fd791906136f7565b60a0015192915050565b60026001541415610ffb57600060028054610f4690613e7b565b600360015414156110b65760006002805461101590613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461104190613e7b565b801561108e5780601f106110635761010080835404028352916020019161108e565b820191906000526020600020905b81548152906001019060200180831161107157829003601f168201915b50505050508060200190518101906110a691906137e0565b90506110b46000600c6134d6565b505b60046001541415611171576000600280546110d090613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546110fc90613e7b565b80156111495780601f1061111e57610100808354040283529160200191611149565b820191906000526020600020905b81548152906001019060200180831161112c57829003601f168201915b505050505080602001905181019061116191906137e0565b905061116f6000600c6134d6565b505b6005600154141561122c5760006002805461118b90613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546111b790613e7b565b80156112045780601f106111d957610100808354040283529160200191611204565b820191906000526020600020905b8154815290600101906020018083116111e757829003601f168201915b505050505080602001905181019061121c9190613688565b905061122a6000600c6134d6565b505b600660015414156112e75760006002805461124690613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461127290613e7b565b80156112bf5780601f10611294576101008083540402835291602001916112bf565b820191906000526020600020905b8154815290600101906020018083116112a257829003601f168201915b50505050508060200190518101906112d79190613688565b90506112e56000600c6134d6565b505b600760015414156113a25760006002805461130190613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461132d90613e7b565b801561137a5780601f1061134f5761010080835404028352916020019161137a565b820191906000526020600020905b81548152906001019060200180831161135d57829003601f168201915b50505050508060200190518101906113929190613688565b90506113a06000600c6134d6565b505b61066a6000600c6134d6565b6000600180541415611461576000600280546113c990613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546113f590613e7b565b80156114425780601f1061141757610100808354040283529160200191611442565b820191906000526020600020905b81548152906001019060200180831161142557829003601f168201915b505050505080602001905181019061145a91906136f7565b5192915050565b6002600154141561147b576000600280546113c990613e7b565b600360015414156115265760006002805461149590613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546114c190613e7b565b801561150e5780601f106114e35761010080835404028352916020019161150e565b820191906000526020600020905b8154815290600101906020018083116114f157829003601f168201915b505050505080602001905181019061145a91906137e0565b600460015414156115405760006002805461149590613e7b565b600560015414156115fb5760006002805461155a90613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461158690613e7b565b80156115d35780601f106115a8576101008083540402835291602001916115d3565b820191906000526020600020905b8154815290600101906020018083116115b657829003601f168201915b50505050508060200190518101906115eb9190613688565b90506115f96000600d6134d6565b505b600660015414156116b65760006002805461161590613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461164190613e7b565b801561168e5780601f106116635761010080835404028352916020019161168e565b820191906000526020600020905b81548152906001019060200180831161167157829003601f168201915b50505050508060200190518101906116a69190613688565b90506116b46000600d6134d6565b505b60076001541415611771576000600280546116d090613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546116fc90613e7b565b80156117495780601f1061171e57610100808354040283529160200191611749565b820191906000526020600020905b81548152906001019060200180831161172c57829003601f168201915b50505050508060200190518101906117619190613688565b905061176f6000600d6134d6565b505b61066a6000600d6134d6565b60006001805414156118335760006002805461179890613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546117c490613e7b565b80156118115780601f106117e657610100808354040283529160200191611811565b820191906000526020600020905b8154815290600101906020018083116117f457829003601f168201915b505050505080602001905181019061182991906136f7565b6020015192915050565b6002600154141561184d5760006002805461179890613e7b565b600360015414156119085760006002805461186790613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461189390613e7b565b80156118e05780601f106118b5576101008083540402835291602001916118e0565b820191906000526020600020905b8154815290600101906020018083116118c357829003601f168201915b50505050508060200190518101906118f891906137e0565b90506119066000600e6134d6565b505b600460015414156119c35760006002805461192290613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461194e90613e7b565b801561199b5780601f106119705761010080835404028352916020019161199b565b820191906000526020600020905b81548152906001019060200180831161197e57829003601f168201915b50505050508060200190518101906119b391906137e0565b90506119c16000600e6134d6565b505b60056001541415611a7e576000600280546119dd90613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054611a0990613e7b565b8015611a565780601f10611a2b57610100808354040283529160200191611a56565b820191906000526020600020905b815481529060010190602001808311611a3957829003601f168201915b5050505050806020019051810190611a6e9190613688565b9050611a7c6000600e6134d6565b505b60066001541415611b3957600060028054611a9890613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054611ac490613e7b565b8015611b115780601f10611ae657610100808354040283529160200191611b11565b820191906000526020600020905b815481529060010190602001808311611af457829003601f168201915b5050505050806020019051810190611b299190613688565b9050611b376000600e6134d6565b505b60076001541415611bf457600060028054611b5390613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054611b7f90613e7b565b8015611bcc5780601f10611ba157610100808354040283529160200191611bcc565b820191906000526020600020905b815481529060010190602001808311611baf57829003601f168201915b5050505050806020019051810190611be49190613688565b9050611bf26000600e6134d6565b505b61066a6000600e6134d6565b604051611c3c90611c18906004908490602001613d30565b6040516020818303038152906040528051906020012060001c60005414601e6134d6565b60008055611c53610100820135431015601f6134d6565b7fe0ceb28914565a8b65e0d15b94462987fd52b6a87b79ddcd41898016f509777a81604051611c829190613bb1565b60405180910390a1611c963415601c6134d6565b611cb833611ca76020840184613647565b6001600160a01b031614601d6134d6565b611cc56020820182613647565b6040516001600160a01b03919091169060009060649082818181858883f19350505050158015611cf9573d6000803e3d6000fd5b5060008080556001819055611d1090600290613583565b33ff5b6000600180541415611dc957600060028054611d2e90613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054611d5a90613e7b565b8015611da75780601f10611d7c57610100808354040283529160200191611da7565b820191906000526020600020905b815481529060010190602001808311611d8a57829003601f168201915b5050505050806020019051810190611dbf91906136f7565b60e0015192915050565b60026001541415611de357600060028054611d2e90613e7b565b60036001541415611e9e57600060028054611dfd90613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054611e2990613e7b565b8015611e765780601f10611e4b57610100808354040283529160200191611e76565b820191906000526020600020905b815481529060010190602001808311611e5957829003601f168201915b5050505050806020019051810190611e8e91906137e0565b9050611e9c6000600a6134d6565b505b60046001541415611f5957600060028054611eb890613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054611ee490613e7b565b8015611f315780601f10611f0657610100808354040283529160200191611f31565b820191906000526020600020905b815481529060010190602001808311611f1457829003601f168201915b5050505050806020019051810190611f4991906137e0565b9050611f576000600a6134d6565b505b6005600154141561201457600060028054611f7390613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054611f9f90613e7b565b8015611fec5780601f10611fc157610100808354040283529160200191611fec565b820191906000526020600020905b815481529060010190602001808311611fcf57829003601f168201915b50505050508060200190518101906120049190613688565b90506120126000600a6134d6565b505b600660015414156120cf5760006002805461202e90613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461205a90613e7b565b80156120a75780601f1061207c576101008083540402835291602001916120a7565b820191906000526020600020905b81548152906001019060200180831161208a57829003601f168201915b50505050508060200190518101906120bf9190613688565b90506120cd6000600a6134d6565b505b6007600154141561218a576000600280546120e990613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461211590613e7b565b80156121625780601f1061213757610100808354040283529160200191612162565b820191906000526020600020905b81548152906001019060200180831161214557829003601f168201915b505050505080602001905181019061217a9190613688565b90506121886000600a6134d6565b505b61066a6000600a6134d6565b6000600180541415612242576000600280546121b190613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546121dd90613e7b565b801561222a5780601f106121ff5761010080835404028352916020019161222a565b820191906000526020600020905b81548152906001019060200180831161220d57829003601f168201915b505050505080602001905181019061040991906136f7565b6002600154141561225c576000600280546121b190613e7b565b600360015414156123115760006002805461227690613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546122a290613e7b565b80156122ef5780601f106122c4576101008083540402835291602001916122ef565b820191906000526020600020905b8154815290600101906020018083116122d257829003601f168201915b505050505080602001905181019061230791906137e0565b6040015192915050565b6004600154141561232b5760006002805461227690613e7b565b600560015414156123e65760006002805461234590613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461237190613e7b565b80156123be5780601f10612393576101008083540402835291602001916123be565b820191906000526020600020905b8154815290600101906020018083116123a157829003601f168201915b50505050508060200190518101906123d69190613688565b90506123e4600060076134d6565b505b600660015414156124a15760006002805461240090613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461242c90613e7b565b80156124795780601f1061244e57610100808354040283529160200191612479565b820191906000526020600020905b81548152906001019060200180831161245c57829003601f168201915b50505050508060200190518101906124919190613688565b905061249f600060076134d6565b505b6007600154141561255c576000600280546124bb90613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546124e790613e7b565b80156125345780601f1061250957610100808354040283529160200191612534565b820191906000526020600020905b81548152906001019060200180831161251757829003601f168201915b505050505080602001905181019061254c9190613688565b905061255a600060076134d6565b505b61066a600060076134d6565b6040516125a490612580906002908490602001613dfc565b6040516020818303038152906040528051906020012060001c6000541460156134d6565b600080556040517f581dee4250bac14004e528c23773903d69be59497f2b327b4c3262a24e7af12d906125d8908390613b12565b60405180910390a16125ee6064341460136134d6565b612610336125ff6020840184613647565b6001600160a01b03161460146134d6565b6005600155604080516000602082018190529101604051602081830303815290604052600290805190602001906126489291906134ff565b50604080516080810182526000808252602080830182905292820181905260608201529061267890840184613647565b6001600160a01b031681526126936040840160208501613647565b6001600160a01b031660208201526126b16060840160408501613647565b6001600160a01b031660408201526126cf6080840160608501613647565b6001600160a01b03166060820152604051610a88906003908390602001613e10565b600060018054141561279d5760006002805461270c90613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461273890613e7b565b80156127855780601f1061275a57610100808354040283529160200191612785565b820191906000526020600020905b81548152906001019060200180831161276857829003601f168201915b505050505080602001905181019061230791906136f7565b600260015414156127b75760006002805461270c90613e7b565b60036001541415612862576000600280546127d190613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546127fd90613e7b565b801561284a5780601f1061281f5761010080835404028352916020019161284a565b820191906000526020600020905b81548152906001019060200180831161282d57829003601f168201915b505050505080602001905181019061182991906137e0565b6004600154141561287c576000600280546127d190613e7b565b600560015414156129375760006002805461289690613e7b565b80601f01602080910402602001604051908101604052809291908181526020018280546128c290613e7b565b801561290f5780601f106128e45761010080835404028352916020019161290f565b820191906000526020600020905b8154815290600101906020018083116128f257829003601f168201915b50505050508060200190518101906129279190613688565b90506129356000600b6134d6565b505b600660015414156129f25760006002805461295190613e7b565b80601f016020809104026020016040519081016040528092919081815260200182805461297d90613e7b565b80156129ca5780601f1061299f576101008083540402835291602001916129ca565b820191906000526020600020905b8154815290600101906020018083116129ad57829003601f168201915b50505050508060200190518101906129e29190613688565b90506129f06000600b6134d6565b505b60076001541415612aad57600060028054612a0c90613e7b565b80601f0160208091040260200160405190810160405280929190818152602001828054612a3890613e7b565b8015612a855780601f10612a5a57610100808354040283529160200191612a85565b820191906000526020600020905b815481529060010190602001808311612a6857829003601f168201915b5050505050806020019051810190612a9d9190613688565b9050612aab6000600b6134d6565b505b61066a6000600b6134d6565b612b0b6000612acb602084018461366b565b604051602001612ae79291909182521515602082015260400190565b6040516020818303038152906040528051906020012060001c6000541460106134d6565b600080556040517f85bb531a30c8f53ebe38970bddf3256f1712c0551a2c5f5f1a0e1f633b14141890612b3f908390613cc3565b60405180910390a1612b533415600f6134d6565b600760015560408051600060208201819052910160405160208183030381529060405260029080519060200190612b8b9291906134ff565b506040805180820190915260008082526020820152338152612bb36040840160208501613647565b6001600160a01b03908116602083810191825260408051600192810192909252845184169082015290519091166060820152608001610a88565b604051612c2990612c05906007908490602001613dbf565b6040516020818303038152906040528051906020012060001c6000541460256134d6565b600080556040517fd6ad5b0f2947a7911feb29107ac75b6c8d010d9f659393dd255ac1629bebaf3390612c5d908390613c79565b60405180910390a1612c71341560236134d6565b612c9333612c826020840184613647565b6001600160a01b03161460246134d6565b612c9b6135c0565b612cab6040830160208401613647565b6001600160a01b03168152612cc66080830160608401613647565b6001600160a01b031660208083019190915260a08084013560408085019190915260c080860135606086015260e08087013560808701526101208701359386019390935261014086013590850152610160850135918401919091526001805551612d3291839101613bdd565b60405160208183030381529060405260029080519060200190612d569291906134ff565b506040805160608101825260008082526020820181905291810191909152612d846060840160408501613647565b6001600160a01b03168152612d9f60a0840160808501613647565b6001600160a01b0390811660208381019182526101008601356040808601918252805160089381019390935285518516908301529151909216606083015251608082015260a001610a88565b604051612e2790612e03906006908490602001613d30565b6040516020818303038152906040528051906020012060001c6000541460226134d6565b600080556040517fbd7a6b606aecefbb46f25b3e7e73d697aaebac0dde773712918f1bfe5f797a2e90612e5b908390613c42565b60405180910390a1612e6f341560206134d6565b612e9433612e8360a0840160808501613647565b6001600160a01b03161460216134d6565b612e9c6135c0565b612eac6040830160208401613647565b6001600160a01b03168152612ec76080830160608401613647565b6001600160a01b031660208083019190915260a08084013560408085019190915260c080860135606086015260e0808701356080870152610120870135938601939093526101408601359085015261016085013591840191909152600260015551612f3491839101613bdd565b60405160208183030381529060405260029080519060200190612f589291906134ff565b50612fea60405180610180016040528060006001600160a01b0316815260200160006001600160a01b0316815260200160006001600160a01b0316815260200160006001600160a01b0316815260200160006001600160a01b03168152602001600081526020016000815260200160008152602001600081526020016000815260200160008152602001600081525090565b612ff76020840184613647565b6001600160a01b031681526130126040840160208501613647565b6001600160a01b031660208201526130306060840160408501613647565b6001600160a01b0316604082015261304e6080840160608501613647565b6001600160a01b0316606082015261306c60a0840160808501613647565b6001600160a01b0316608082015260a0808401359082015260c0808401359082015260e080840135908201526101008084013590820152610120808401359082015261014080840135908201526101608084013590820152604051610a8890600790839060200182815281516001600160a01b031660208201526101a0810160208301516001600160a01b03811660408401525060408301516001600160a01b03811660608401525060608301516001600160a01b03811660808401525060808301516001600160a01b03811660a08401525060a083015160c08381019190915283015160e080840191909152830151610100808401919091528301516101208084019190915283015161014080840191909152830151610160808401919091529092015161018090910152919050565b6040516131d9906131b5906003908490602001613dfc565b6040516020818303038152906040528051906020012060001c6000541460176134d6565b600080805560408051602081018252918252517fc034fa8dbf8c670d6e29ce885a55faad707a2330e075aabf7b8d8e957e1aa7f390613219908490613b37565b60405180910390a161322d341560166134d6565b613238603c43613e55565b815260408051608081018252600080825260208201819052918101829052606081019190915261326e6040840160208501613647565b6001600160a01b0316808252608084810135602080850191825260a080880135604080880191825260c08a01356060808a01918252600460015582518087019990995295518883015291519487019490945251858501528251808603909401845293909301905280516132e59260029201906134ff565b50604080516101208101825260008082526020808301829052928201819052606082018190526080820181905260a0820181905260c0820181905260e082018190526101008201529061333a90850185613647565b6001600160a01b031681526133556040850160208601613647565b6001600160a01b031660208201526133736060850160408601613647565b6001600160a01b031660408201526133916080850160608601613647565b6001600160a01b031660608201523360808083019190915284013560a08083019190915284013560c08083019190915284013560e08201528251610100820152604051610916906004908390602001613d45565b604051613421906133fd906008908490602001613dd4565b6040516020818303038152906040528051906020012060001c6000541460286134d6565b600080556040517f61b1b93c7e3febc2ef06525888ad11e30fea14c49b387826f5bb65a23cde3dd390613455908390613c98565b60405180910390a1613469341560266134d6565b61348b3361347a6020840184613647565b6001600160a01b03161460276134d6565b61349b6040820160208301613647565b604080516001600160a01b0392909216919083013580156108fc02916000818181858888f19350505050158015611cf9573d6000803e3d6000fd5b816134fb5760405163100960cb60e01b81526004810182905260240160405180910390fd5b5050565b82805461350b90613e7b565b90600052602060002090601f01602090048101928261352d5760008555613573565b82601f1061354657805160ff1916838001178555613573565b82800160010185558215613573579182015b82811115613573578251825591602001919060010190613558565b5061357f929150613617565b5090565b50805461358f90613e7b565b6000825580601f1061359f575050565b601f0160209004906000526020600020908101906135bd9190613617565b50565b60405180610100016040528060006001600160a01b0316815260200160006001600160a01b031681526020016000815260200160008152602001600081526020016000815260200160008152602001600081525090565b5b8082111561357f5760008155600101613618565b803561363781613eb0565b919050565b805161363781613eb0565b60006020828403121561365957600080fd5b813561366481613eb0565b9392505050565b60006020828403121561367d57600080fd5b813561366481613ec5565b60006020828403121561369a57600080fd5b815161366481613ec5565b60006104a082840312156136b857600080fd5b50919050565b600061010082840312156136b857600080fd5b600061054082840312156136b857600080fd5b600061014082840312156136b857600080fd5b600061010080838503121561370b57600080fd5b6040519081019067ffffffffffffffff8211818310171561373c57634e487b7160e01b600052604160045260246000fd5b816040528351915061374d82613eb0565b81815261375c6020850161363c565b602082015260408401516040820152606084015160608201526080840151608082015260a084015160a082015260c084015160c082015260e084015160e0820152809250505092915050565b600061018082840312156136b857600080fd5b60006101a082840312156136b857600080fd5b6000608082840312156136b857600080fd5b6000608082840312156137f257600080fd5b6040516080810181811067ffffffffffffffff8211171561382357634e487b7160e01b600052604160045260246000fd5b604052825161383181613eb0565b808252506020830151602082015260408301516040820152606083015160608201528091505092915050565b6000604082840312156136b857600080fd5b6000606082840312156136b857600080fd5b803561388c81613eb0565b6001600160a01b0316825260208101356138a581613eb0565b6001600160a01b031660208301526138bf6040820161362c565b6001600160a01b031660408301526138d96060820161362c565b6001600160a01b031660608301526138f36080820161362c565b6001600160a01b0316608083015260a0818101359083015260c0808201359083015260e0808201359083015261010090810135910152565b81816000805b60208082106139405750613965565b833560ff8116808214613951578485fd5b865250938401939290920191600101613931565b5050505061040090810135910152565b61398f826139828361362c565b6001600160a01b03169052565b61399b6020820161362c565b6001600160a01b031660208301526139b56040820161362c565b6001600160a01b031660408301526139cf6060820161362c565b6001600160a01b031660608301526139e96080820161362c565b6001600160a01b0316608083015260a0818101359083015260c0808201359083015260e0808201359083015261010080820135908301526101208082013590830152610140808201359083015261016090810135910152565b8035613a4d81613eb0565b6001600160a01b039081168352602082013590613a6982613eb0565b166020830152604090810135910152565b8035613a8581613eb0565b6001600160a01b039081168352602082013590613aa182613eb0565b808216602085015250505050565b8035613aba81613eb0565b6001600160a01b039081168352602082013590613ad682613eb0565b9081166020840152604082013590613aed82613eb0565b9081166040840152606082013590613b0482613eb0565b808216606085015250505050565b6104a08101613b218284613aaf565b613b31608083016080850161392b565b92915050565b6101008101613b468284613aaf565b6080830135608083015260a083013560a083015260c083013560c083015260e0830135613b7281613eb0565b6001600160a01b031660e09290920191909152919050565b6105408101613b998284613881565b610120613baa81840182860161392b565b5092915050565b6101408101613bc08284613881565b61012080840135613bd081613ec5565b1515920191909152919050565b60006101008201905060018060a01b038084511683528060208501511660208401525060408301516040830152606083015160608301526080830151608083015260a083015160a083015260c083015160c083015260e083015160e083015292915050565b6101808101613c518284613881565b6101208381013590830152610140808401359083015261016092830135929091019190915290565b6101a08101613c888284613975565b61018080840135613bd081613ec5565b60808101613ca68284613a42565b6060830135613cb481613ec5565b80151560608401525092915050565b604081018235613cd281613ec5565b151582526020830135613ce481613eb0565b6001600160a01b031660209290920191909152919050565b60608101613d0a8284613a7a565b6040830135613d1881613eb0565b6001600160a01b031660409290920191909152919050565b82815261014081016136646020830184613881565b8281526101408101613664602083018480516001600160a01b0390811683526020808301518216908401526040808301518216908401526060808301518216908401526080808301519091169083015260a0808201519083015260c0808201519083015260e0808201519083015261010090810151910152565b8281526101a081016136646020830184613975565b828152608081016136646020830184613a42565b828152606081016136646020830184613a7a565b82815260a081016136646020830184613aaf565b91825280516001600160a01b03908116602080850191909152820151811660408085019190915282015181166060808501919091529091015116608082015260a00190565b60008219821115613e7657634e487b7160e01b600052601160045260246000fd5b500190565b600181811c90821680613e8f57607f821691505b602082108114156136b857634e487b7160e01b600052602260045260246000fd5b6001600160a01b03811681146135bd57600080fd5b80151581146135bd57600080fdfea2646970667358221220488612ef0dc16b69b3ff867cb6af80ba604023423b45a90275266c94298d956e64736f6c63430008050033`,
  BytecodeLen: 16562,
  Which: `oD`,
  deployMode: `DM_constructor`,
  version: 1,
  views: {
    NFT: {
      career1: `NFT_career1`,
      career2: `NFT_career2`,
      fortune1: `NFT_fortune1`,
      fortune2: `NFT_fortune2`,
      love1: `NFT_love1`,
      love2: `NFT_love2`,
      owner1: `NFT_owner1`,
      owner2: `NFT_owner2`
      }
    }
  };

export const _Connectors = {
  ALGO: _ALGO,
  ETH: _ETH
  };

