// Automatically generated with Reach 0.1.3
/* eslint-disable */
export const _version = '0.1.3';
export const _backendVersion = 1;


export function getExports(s) {
  const stdlib = s.reachStdlib;
  return {
    };
  };

export function _getViews(s, viewlib) {
  const stdlib = s.reachStdlib;
  
  return {
    infos: {
      },
    views: {
      }
    };
  
  };

export function _getMaps(s) {
  const stdlib = s.reachStdlib;
  const ctc0 = stdlib.T_Tuple([]);
  return {
    mapDataTy: ctc0
    };
  };

export async function FirBuyer(ctc, interact) {
  if (typeof(ctc) !== 'object' || ctc.sendrecv === undefined) {
    return Promise.reject(new Error(`The backend for FirBuyer expects to receive a contract as its first argument.`));}
  if (typeof(interact) !== 'object') {
    return Promise.reject(new Error(`The backend for FirBuyer expects to receive an interact object as its second argument.`));}
  const stdlib = ctc.stdlib;
  const ctc0 = stdlib.T_Address;
  const ctc1 = stdlib.T_UInt;
  const ctc2 = stdlib.T_Tuple([ctc1, ctc1]);
  const ctc3 = stdlib.T_Digest;
  const ctc4 = stdlib.T_Bytes(stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 32));
  const ctc5 = stdlib.T_Null;
  
  
  const v15 = await ctc.creationTime();
  const v16 = await ctc.creationSecs();
  
  const txn1 = await (ctc.recv({
    evt_cnt: 0,
    funcNum: 1,
    out_tys: [],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [] = txn1.data;
  const v20 = txn1.time;
  const v21 = txn1.secs;
  const v17 = txn1.from;
  ;
  const v25 = stdlib.protect(ctc0, await interact.getAcct(), {
    at: './rate.rsh:51:53:application',
    fs: ['at ./rate.rsh:50:14:application call to [unknown function] (defined at: ./rate.rsh:50:18:function exp)'],
    msg: 'getAcct',
    who: 'FirBuyer'
    });
  const v26 = stdlib.protect(ctc1, await interact.getScore(), {
    at: './rate.rsh:52:41:application',
    fs: ['at ./rate.rsh:50:14:application call to [unknown function] (defined at: ./rate.rsh:50:18:function exp)'],
    msg: 'getScore',
    who: 'FirBuyer'
    });
  const v28 = stdlib.protect(ctc1, await interact.random(), {
    at: 'reach standard library:60:31:application',
    fs: ['at ./rate.rsh:53:56:application call to "makeCommitment" (defined at: reach standard library:59:8:function exp)', 'at ./rate.rsh:50:14:application call to [unknown function] (defined at: ./rate.rsh:50:18:function exp)'],
    msg: 'random',
    who: 'FirBuyer'
    });
  const v29 = stdlib.digest(ctc2, [v28, v26]);
  
  const txn2 = await (ctc.sendrecv({
    args: [v17, v29, v25],
    evt_cnt: 2,
    funcNum: 2,
    onlyIf: true,
    out_tys: [ctc3, ctc0],
    pay: [stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0), []],
    sim_p: (async (txn2) => {
      const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
      
      const [v32, v33] = txn2.data;
      const v35 = txn2.time;
      const v36 = txn2.secs;
      const v31 = txn2.from;
      
      sim_r.txns.push({
        amt: stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0),
        kind: 'to',
        tok: undefined
        });
      sim_r.isHalt = false;
      
      return sim_r;
      }),
    soloSend: true,
    timeoutAt: undefined,
    tys: [ctc0, ctc3, ctc0],
    waitIfNotPresent: false
    }));
  const [v32, v33] = txn2.data;
  const v35 = txn2.time;
  const v36 = txn2.secs;
  const v31 = txn2.from;
  ;
  const txn3 = await (ctc.recv({
    evt_cnt: 2,
    funcNum: 3,
    out_tys: [ctc1, ctc0],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v43, v44] = txn3.data;
  const v46 = txn3.time;
  const v47 = txn3.secs;
  const v42 = txn3.from;
  ;
  const txn4 = await (ctc.sendrecv({
    args: [v17, v31, v32, v33, v42, v43, v44, v28, v26],
    evt_cnt: 2,
    funcNum: 4,
    onlyIf: true,
    out_tys: [ctc1, ctc1],
    pay: [stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0), []],
    sim_p: (async (txn4) => {
      const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
      
      const [v52, v53] = txn4.data;
      const v56 = txn4.time;
      const v57 = txn4.secs;
      const v51 = txn4.from;
      
      sim_r.txns.push({
        amt: stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0),
        kind: 'to',
        tok: undefined
        });
      const v55 = stdlib.addressEq(v31, v51);
      stdlib.assert(v55, {
        at: './rate.rsh:72:12:dot',
        fs: [],
        msg: 'sender correct',
        who: 'FirBuyer'
        });
      const v59 = stdlib.digest(ctc2, [v52, v53]);
      const v60 = stdlib.digestEq(v32, v59);
      stdlib.assert(v60, {
        at: 'reach standard library:65:17:application',
        fs: ['at ./rate.rsh:73:18:application call to "checkCommitment" (defined at: reach standard library:64:8:function exp)'],
        msg: null,
        who: 'FirBuyer'
        });
      const v61 = stdlib.ge(v53, stdlib.checkedBigNumberify('./rate.rsh:76:20:decimal', stdlib.UInt_max, 8));
      const v62 = stdlib.ge(v43, stdlib.checkedBigNumberify('./rate.rsh:76:38:decimal', stdlib.UInt_max, 8));
      const v63 = v61 ? v62 : false;
      if (v63) {
        sim_r.isHalt = false;
        }
      else {
        const v92 = stdlib.le(v53, stdlib.checkedBigNumberify('./rate.rsh:98:20:decimal', stdlib.UInt_max, 10));
        const v93 = stdlib.le(v43, stdlib.checkedBigNumberify('./rate.rsh:98:39:decimal', stdlib.UInt_max, 10));
        const v94 = v92 ? v93 : false;
        const v96 = stdlib.ge(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), stdlib.checkedBigNumberify('./rate.rsh:98:58:decimal', stdlib.UInt_max, 20));
        const v97 = v94 ? v96 : false;
        if (v97) {
          sim_r.isHalt = false;
          }
        else {
          sim_r.txns.push({
            amt: stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200),
            kind: 'from',
            to: v17,
            tok: undefined
            });
          sim_r.txns.push({
            kind: 'halt',
            tok: undefined
            })
          sim_r.isHalt = true;
          }}
      return sim_r;
      }),
    soloSend: true,
    timeoutAt: undefined,
    tys: [ctc0, ctc0, ctc3, ctc0, ctc0, ctc1, ctc0, ctc1, ctc1],
    waitIfNotPresent: false
    }));
  const [v52, v53] = txn4.data;
  const v56 = txn4.time;
  const v57 = txn4.secs;
  const v51 = txn4.from;
  ;
  const v55 = stdlib.addressEq(v31, v51);
  stdlib.assert(v55, {
    at: './rate.rsh:72:12:dot',
    fs: [],
    msg: 'sender correct',
    who: 'FirBuyer'
    });
  const v59 = stdlib.digest(ctc2, [v52, v53]);
  const v60 = stdlib.digestEq(v32, v59);
  stdlib.assert(v60, {
    at: 'reach standard library:65:17:application',
    fs: ['at ./rate.rsh:73:18:application call to "checkCommitment" (defined at: reach standard library:64:8:function exp)'],
    msg: null,
    who: 'FirBuyer'
    });
  const v61 = stdlib.ge(v53, stdlib.checkedBigNumberify('./rate.rsh:76:20:decimal', stdlib.UInt_max, 8));
  const v62 = stdlib.ge(v43, stdlib.checkedBigNumberify('./rate.rsh:76:38:decimal', stdlib.UInt_max, 8));
  const v63 = v61 ? v62 : false;
  if (v63) {
    const v67 = stdlib.protect(ctc4, await interact.getChatInfo(), {
      at: './rate.rsh:79:59:application',
      fs: ['at ./rate.rsh:78:18:application call to [unknown function] (defined at: ./rate.rsh:78:22:function exp)'],
      msg: 'getChatInfo',
      who: 'FirBuyer'
      });
    
    const txn5 = await (ctc.sendrecv({
      args: [v17, v31, v33, v42, v43, v44, v53, v67],
      evt_cnt: 1,
      funcNum: 5,
      onlyIf: true,
      out_tys: [ctc4],
      pay: [stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0), []],
      sim_p: (async (txn5) => {
        const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
        
        const [v69] = txn5.data;
        const v72 = txn5.time;
        const v73 = txn5.secs;
        const v68 = txn5.from;
        
        sim_r.txns.push({
          amt: stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0),
          kind: 'to',
          tok: undefined
          });
        const v71 = stdlib.addressEq(v31, v68);
        stdlib.assert(v71, {
          at: './rate.rsh:81:14:dot',
          fs: [],
          msg: 'sender correct',
          who: 'FirBuyer'
          });
        sim_r.isHalt = false;
        
        return sim_r;
        }),
      soloSend: true,
      timeoutAt: undefined,
      tys: [ctc0, ctc0, ctc0, ctc0, ctc1, ctc0, ctc1, ctc4],
      waitIfNotPresent: false
      }));
    const [v69] = txn5.data;
    const v72 = txn5.time;
    const v73 = txn5.secs;
    const v68 = txn5.from;
    ;
    const v71 = stdlib.addressEq(v31, v68);
    stdlib.assert(v71, {
      at: './rate.rsh:81:14:dot',
      fs: [],
      msg: 'sender correct',
      who: 'FirBuyer'
      });
    const txn6 = await (ctc.recv({
      evt_cnt: 1,
      funcNum: 6,
      out_tys: [ctc4],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [v79] = txn6.data;
    const v82 = txn6.time;
    const v83 = txn6.secs;
    const v78 = txn6.from;
    ;
    const v81 = stdlib.addressEq(v42, v78);
    stdlib.assert(v81, {
      at: './rate.rsh:88:14:dot',
      fs: [],
      msg: 'sender correct',
      who: 'FirBuyer'
      });
    stdlib.protect(ctc5, await interact.showChatInfo(v79), {
      at: './rate.rsh:92:28:application',
      fs: ['at ./rate.rsh:91:18:application call to [unknown function] (defined at: ./rate.rsh:91:22:function exp)'],
      msg: 'showChatInfo',
      who: 'FirBuyer'
      });
    
    const txn7 = await (ctc.sendrecv({
      args: [v17, v31, v33, v42, v43, v44, v53],
      evt_cnt: 0,
      funcNum: 7,
      onlyIf: true,
      out_tys: [],
      pay: [stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0), []],
      sim_p: (async (txn7) => {
        const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
        
        const [] = txn7.data;
        const v90 = txn7.time;
        const v91 = txn7.secs;
        const v87 = txn7.from;
        
        sim_r.txns.push({
          amt: stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0),
          kind: 'to',
          tok: undefined
          });
        const v89 = stdlib.addressEq(v31, v87);
        stdlib.assert(v89, {
          at: './rate.rsh:94:14:dot',
          fs: [],
          msg: 'sender correct',
          who: 'FirBuyer'
          });
        const v92 = stdlib.le(v53, stdlib.checkedBigNumberify('./rate.rsh:98:20:decimal', stdlib.UInt_max, 10));
        const v93 = stdlib.le(v43, stdlib.checkedBigNumberify('./rate.rsh:98:39:decimal', stdlib.UInt_max, 10));
        const v94 = v92 ? v93 : false;
        const v96 = stdlib.ge(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), stdlib.checkedBigNumberify('./rate.rsh:98:58:decimal', stdlib.UInt_max, 20));
        const v97 = v94 ? v96 : false;
        if (v97) {
          sim_r.isHalt = false;
          }
        else {
          sim_r.txns.push({
            amt: stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200),
            kind: 'from',
            to: v17,
            tok: undefined
            });
          sim_r.txns.push({
            kind: 'halt',
            tok: undefined
            })
          sim_r.isHalt = true;
          }
        return sim_r;
        }),
      soloSend: true,
      timeoutAt: undefined,
      tys: [ctc0, ctc0, ctc0, ctc0, ctc1, ctc0, ctc1],
      waitIfNotPresent: false
      }));
    const [] = txn7.data;
    const v90 = txn7.time;
    const v91 = txn7.secs;
    const v87 = txn7.from;
    ;
    const v89 = stdlib.addressEq(v31, v87);
    stdlib.assert(v89, {
      at: './rate.rsh:94:14:dot',
      fs: [],
      msg: 'sender correct',
      who: 'FirBuyer'
      });
    const v92 = stdlib.le(v53, stdlib.checkedBigNumberify('./rate.rsh:98:20:decimal', stdlib.UInt_max, 10));
    const v93 = stdlib.le(v43, stdlib.checkedBigNumberify('./rate.rsh:98:39:decimal', stdlib.UInt_max, 10));
    const v94 = v92 ? v93 : false;
    const v96 = stdlib.ge(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), stdlib.checkedBigNumberify('./rate.rsh:98:58:decimal', stdlib.UInt_max, 20));
    const v97 = v94 ? v96 : false;
    if (v97) {
      const txn8 = await (ctc.recv({
        evt_cnt: 0,
        funcNum: 8,
        out_tys: [],
        timeoutAt: undefined,
        waitIfNotPresent: false
        }));
      const [] = txn8.data;
      const v104 = txn8.time;
      const v105 = txn8.secs;
      const v101 = txn8.from;
      ;
      const v103 = stdlib.addressEq(v42, v101);
      stdlib.assert(v103, {
        at: './rate.rsh:104:14:dot',
        fs: [],
        msg: 'sender correct',
        who: 'FirBuyer'
        });
      stdlib.protect(ctc5, await interact.showScore(v43), {
        at: './rate.rsh:108:25:application',
        fs: ['at ./rate.rsh:107:18:application call to [unknown function] (defined at: ./rate.rsh:107:22:function exp)'],
        msg: 'showScore',
        who: 'FirBuyer'
        });
      
      const txn9 = await (ctc.sendrecv({
        args: [v17, v31, v33, v43, v44, v53],
        evt_cnt: 0,
        funcNum: 9,
        onlyIf: true,
        out_tys: [],
        pay: [stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0), []],
        sim_p: (async (txn9) => {
          const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
          
          const [] = txn9.data;
          const v112 = txn9.time;
          const v113 = txn9.secs;
          const v109 = txn9.from;
          
          sim_r.txns.push({
            amt: stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0),
            kind: 'to',
            tok: undefined
            });
          const v111 = stdlib.addressEq(v31, v109);
          stdlib.assert(v111, {
            at: './rate.rsh:110:14:dot',
            fs: [],
            msg: 'sender correct',
            who: 'FirBuyer'
            });
          const v117 = stdlib.sub(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), v53);
          sim_r.txns.push({
            amt: v53,
            kind: 'from',
            to: v44,
            tok: undefined
            });
          const v121 = stdlib.sub(v117, v43);
          sim_r.txns.push({
            amt: v43,
            kind: 'from',
            to: v33,
            tok: undefined
            });
          sim_r.txns.push({
            amt: v121,
            kind: 'from',
            to: v17,
            tok: undefined
            });
          sim_r.txns.push({
            kind: 'halt',
            tok: undefined
            })
          sim_r.isHalt = true;
          
          return sim_r;
          }),
        soloSend: true,
        timeoutAt: undefined,
        tys: [ctc0, ctc0, ctc0, ctc1, ctc0, ctc1],
        waitIfNotPresent: false
        }));
      const [] = txn9.data;
      const v112 = txn9.time;
      const v113 = txn9.secs;
      const v109 = txn9.from;
      ;
      const v111 = stdlib.addressEq(v31, v109);
      stdlib.assert(v111, {
        at: './rate.rsh:110:14:dot',
        fs: [],
        msg: 'sender correct',
        who: 'FirBuyer'
        });
      const v117 = stdlib.sub(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), v53);
      ;
      const v121 = stdlib.sub(v117, v43);
      ;
      ;
      return;
      
      }
    else {
      ;
      return;}
    
    
    }
  else {
    const v92 = stdlib.le(v53, stdlib.checkedBigNumberify('./rate.rsh:98:20:decimal', stdlib.UInt_max, 10));
    const v93 = stdlib.le(v43, stdlib.checkedBigNumberify('./rate.rsh:98:39:decimal', stdlib.UInt_max, 10));
    const v94 = v92 ? v93 : false;
    const v96 = stdlib.ge(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), stdlib.checkedBigNumberify('./rate.rsh:98:58:decimal', stdlib.UInt_max, 20));
    const v97 = v94 ? v96 : false;
    if (v97) {
      const txn5 = await (ctc.recv({
        evt_cnt: 0,
        funcNum: 10,
        out_tys: [],
        timeoutAt: undefined,
        waitIfNotPresent: false
        }));
      const [] = txn5.data;
      const v104 = txn5.time;
      const v105 = txn5.secs;
      const v101 = txn5.from;
      ;
      const v103 = stdlib.addressEq(v42, v101);
      stdlib.assert(v103, {
        at: './rate.rsh:104:14:dot',
        fs: [],
        msg: 'sender correct',
        who: 'FirBuyer'
        });
      stdlib.protect(ctc5, await interact.showScore(v43), {
        at: './rate.rsh:108:25:application',
        fs: ['at ./rate.rsh:107:18:application call to [unknown function] (defined at: ./rate.rsh:107:22:function exp)'],
        msg: 'showScore',
        who: 'FirBuyer'
        });
      
      const txn6 = await (ctc.sendrecv({
        args: [v17, v31, v33, v43, v44, v53],
        evt_cnt: 0,
        funcNum: 11,
        onlyIf: true,
        out_tys: [],
        pay: [stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0), []],
        sim_p: (async (txn6) => {
          const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
          
          const [] = txn6.data;
          const v112 = txn6.time;
          const v113 = txn6.secs;
          const v109 = txn6.from;
          
          sim_r.txns.push({
            amt: stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0),
            kind: 'to',
            tok: undefined
            });
          const v111 = stdlib.addressEq(v31, v109);
          stdlib.assert(v111, {
            at: './rate.rsh:110:14:dot',
            fs: [],
            msg: 'sender correct',
            who: 'FirBuyer'
            });
          const v117 = stdlib.sub(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), v53);
          sim_r.txns.push({
            amt: v53,
            kind: 'from',
            to: v44,
            tok: undefined
            });
          const v121 = stdlib.sub(v117, v43);
          sim_r.txns.push({
            amt: v43,
            kind: 'from',
            to: v33,
            tok: undefined
            });
          sim_r.txns.push({
            amt: v121,
            kind: 'from',
            to: v17,
            tok: undefined
            });
          sim_r.txns.push({
            kind: 'halt',
            tok: undefined
            })
          sim_r.isHalt = true;
          
          return sim_r;
          }),
        soloSend: true,
        timeoutAt: undefined,
        tys: [ctc0, ctc0, ctc0, ctc1, ctc0, ctc1],
        waitIfNotPresent: false
        }));
      const [] = txn6.data;
      const v112 = txn6.time;
      const v113 = txn6.secs;
      const v109 = txn6.from;
      ;
      const v111 = stdlib.addressEq(v31, v109);
      stdlib.assert(v111, {
        at: './rate.rsh:110:14:dot',
        fs: [],
        msg: 'sender correct',
        who: 'FirBuyer'
        });
      const v117 = stdlib.sub(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), v53);
      ;
      const v121 = stdlib.sub(v117, v43);
      ;
      ;
      return;
      
      }
    else {
      ;
      return;}}
  
  
  
  
  };
export async function Oracle(ctc, interact) {
  if (typeof(ctc) !== 'object' || ctc.sendrecv === undefined) {
    return Promise.reject(new Error(`The backend for Oracle expects to receive a contract as its first argument.`));}
  if (typeof(interact) !== 'object') {
    return Promise.reject(new Error(`The backend for Oracle expects to receive an interact object as its second argument.`));}
  const stdlib = ctc.stdlib;
  const ctc0 = stdlib.T_Digest;
  const ctc1 = stdlib.T_Address;
  const ctc2 = stdlib.T_UInt;
  const ctc3 = stdlib.T_Tuple([ctc2, ctc2]);
  const ctc4 = stdlib.T_Bytes(stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 32));
  
  
  const v15 = await ctc.creationTime();
  const v16 = await ctc.creationSecs();
  
  const txn1 = await (ctc.sendrecv({
    args: [],
    evt_cnt: 0,
    funcNum: 1,
    onlyIf: true,
    out_tys: [],
    pay: [stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), []],
    sim_p: (async (txn1) => {
      const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
      
      const [] = txn1.data;
      const v20 = txn1.time;
      const v21 = txn1.secs;
      const v17 = txn1.from;
      
      sim_r.txns.push({
        amt: stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200),
        kind: 'to',
        tok: undefined
        });
      sim_r.isHalt = false;
      
      return sim_r;
      }),
    soloSend: true,
    timeoutAt: undefined,
    tys: [],
    waitIfNotPresent: false
    }));
  const [] = txn1.data;
  const v20 = txn1.time;
  const v21 = txn1.secs;
  const v17 = txn1.from;
  ;
  const txn2 = await (ctc.recv({
    evt_cnt: 2,
    funcNum: 2,
    out_tys: [ctc0, ctc1],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v32, v33] = txn2.data;
  const v35 = txn2.time;
  const v36 = txn2.secs;
  const v31 = txn2.from;
  ;
  const txn3 = await (ctc.recv({
    evt_cnt: 2,
    funcNum: 3,
    out_tys: [ctc2, ctc1],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v43, v44] = txn3.data;
  const v46 = txn3.time;
  const v47 = txn3.secs;
  const v42 = txn3.from;
  ;
  const txn4 = await (ctc.recv({
    evt_cnt: 2,
    funcNum: 4,
    out_tys: [ctc2, ctc2],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v52, v53] = txn4.data;
  const v56 = txn4.time;
  const v57 = txn4.secs;
  const v51 = txn4.from;
  ;
  const v55 = stdlib.addressEq(v31, v51);
  stdlib.assert(v55, {
    at: './rate.rsh:72:12:dot',
    fs: [],
    msg: 'sender correct',
    who: 'Oracle'
    });
  const v59 = stdlib.digest(ctc3, [v52, v53]);
  const v60 = stdlib.digestEq(v32, v59);
  stdlib.assert(v60, {
    at: 'reach standard library:65:17:application',
    fs: ['at ./rate.rsh:73:18:application call to "checkCommitment" (defined at: reach standard library:64:8:function exp)'],
    msg: null,
    who: 'Oracle'
    });
  const v61 = stdlib.ge(v53, stdlib.checkedBigNumberify('./rate.rsh:76:20:decimal', stdlib.UInt_max, 8));
  const v62 = stdlib.ge(v43, stdlib.checkedBigNumberify('./rate.rsh:76:38:decimal', stdlib.UInt_max, 8));
  const v63 = v61 ? v62 : false;
  if (v63) {
    const txn5 = await (ctc.recv({
      evt_cnt: 1,
      funcNum: 5,
      out_tys: [ctc4],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [v69] = txn5.data;
    const v72 = txn5.time;
    const v73 = txn5.secs;
    const v68 = txn5.from;
    ;
    const v71 = stdlib.addressEq(v31, v68);
    stdlib.assert(v71, {
      at: './rate.rsh:81:14:dot',
      fs: [],
      msg: 'sender correct',
      who: 'Oracle'
      });
    const txn6 = await (ctc.recv({
      evt_cnt: 1,
      funcNum: 6,
      out_tys: [ctc4],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [v79] = txn6.data;
    const v82 = txn6.time;
    const v83 = txn6.secs;
    const v78 = txn6.from;
    ;
    const v81 = stdlib.addressEq(v42, v78);
    stdlib.assert(v81, {
      at: './rate.rsh:88:14:dot',
      fs: [],
      msg: 'sender correct',
      who: 'Oracle'
      });
    const txn7 = await (ctc.recv({
      evt_cnt: 0,
      funcNum: 7,
      out_tys: [],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [] = txn7.data;
    const v90 = txn7.time;
    const v91 = txn7.secs;
    const v87 = txn7.from;
    ;
    const v89 = stdlib.addressEq(v31, v87);
    stdlib.assert(v89, {
      at: './rate.rsh:94:14:dot',
      fs: [],
      msg: 'sender correct',
      who: 'Oracle'
      });
    const v92 = stdlib.le(v53, stdlib.checkedBigNumberify('./rate.rsh:98:20:decimal', stdlib.UInt_max, 10));
    const v93 = stdlib.le(v43, stdlib.checkedBigNumberify('./rate.rsh:98:39:decimal', stdlib.UInt_max, 10));
    const v94 = v92 ? v93 : false;
    const v96 = stdlib.ge(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), stdlib.checkedBigNumberify('./rate.rsh:98:58:decimal', stdlib.UInt_max, 20));
    const v97 = v94 ? v96 : false;
    if (v97) {
      const txn8 = await (ctc.recv({
        evt_cnt: 0,
        funcNum: 8,
        out_tys: [],
        timeoutAt: undefined,
        waitIfNotPresent: false
        }));
      const [] = txn8.data;
      const v104 = txn8.time;
      const v105 = txn8.secs;
      const v101 = txn8.from;
      ;
      const v103 = stdlib.addressEq(v42, v101);
      stdlib.assert(v103, {
        at: './rate.rsh:104:14:dot',
        fs: [],
        msg: 'sender correct',
        who: 'Oracle'
        });
      const txn9 = await (ctc.recv({
        evt_cnt: 0,
        funcNum: 9,
        out_tys: [],
        timeoutAt: undefined,
        waitIfNotPresent: false
        }));
      const [] = txn9.data;
      const v112 = txn9.time;
      const v113 = txn9.secs;
      const v109 = txn9.from;
      ;
      const v111 = stdlib.addressEq(v31, v109);
      stdlib.assert(v111, {
        at: './rate.rsh:110:14:dot',
        fs: [],
        msg: 'sender correct',
        who: 'Oracle'
        });
      const v117 = stdlib.sub(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), v53);
      ;
      const v121 = stdlib.sub(v117, v43);
      ;
      ;
      return;
      
      }
    else {
      ;
      return;}
    
    
    }
  else {
    const v92 = stdlib.le(v53, stdlib.checkedBigNumberify('./rate.rsh:98:20:decimal', stdlib.UInt_max, 10));
    const v93 = stdlib.le(v43, stdlib.checkedBigNumberify('./rate.rsh:98:39:decimal', stdlib.UInt_max, 10));
    const v94 = v92 ? v93 : false;
    const v96 = stdlib.ge(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), stdlib.checkedBigNumberify('./rate.rsh:98:58:decimal', stdlib.UInt_max, 20));
    const v97 = v94 ? v96 : false;
    if (v97) {
      const txn5 = await (ctc.recv({
        evt_cnt: 0,
        funcNum: 10,
        out_tys: [],
        timeoutAt: undefined,
        waitIfNotPresent: false
        }));
      const [] = txn5.data;
      const v104 = txn5.time;
      const v105 = txn5.secs;
      const v101 = txn5.from;
      ;
      const v103 = stdlib.addressEq(v42, v101);
      stdlib.assert(v103, {
        at: './rate.rsh:104:14:dot',
        fs: [],
        msg: 'sender correct',
        who: 'Oracle'
        });
      const txn6 = await (ctc.recv({
        evt_cnt: 0,
        funcNum: 11,
        out_tys: [],
        timeoutAt: undefined,
        waitIfNotPresent: false
        }));
      const [] = txn6.data;
      const v112 = txn6.time;
      const v113 = txn6.secs;
      const v109 = txn6.from;
      ;
      const v111 = stdlib.addressEq(v31, v109);
      stdlib.assert(v111, {
        at: './rate.rsh:110:14:dot',
        fs: [],
        msg: 'sender correct',
        who: 'Oracle'
        });
      const v117 = stdlib.sub(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), v53);
      ;
      const v121 = stdlib.sub(v117, v43);
      ;
      ;
      return;
      
      }
    else {
      ;
      return;}}
  
  
  
  
  };
export async function SecBuyer(ctc, interact) {
  if (typeof(ctc) !== 'object' || ctc.sendrecv === undefined) {
    return Promise.reject(new Error(`The backend for SecBuyer expects to receive a contract as its first argument.`));}
  if (typeof(interact) !== 'object') {
    return Promise.reject(new Error(`The backend for SecBuyer expects to receive an interact object as its second argument.`));}
  const stdlib = ctc.stdlib;
  const ctc0 = stdlib.T_Digest;
  const ctc1 = stdlib.T_Address;
  const ctc2 = stdlib.T_UInt;
  const ctc3 = stdlib.T_Tuple([ctc2, ctc2]);
  const ctc4 = stdlib.T_Bytes(stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 32));
  const ctc5 = stdlib.T_Null;
  
  
  const v15 = await ctc.creationTime();
  const v16 = await ctc.creationSecs();
  
  const txn1 = await (ctc.recv({
    evt_cnt: 0,
    funcNum: 1,
    out_tys: [],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [] = txn1.data;
  const v20 = txn1.time;
  const v21 = txn1.secs;
  const v17 = txn1.from;
  ;
  const txn2 = await (ctc.recv({
    evt_cnt: 2,
    funcNum: 2,
    out_tys: [ctc0, ctc1],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v32, v33] = txn2.data;
  const v35 = txn2.time;
  const v36 = txn2.secs;
  const v31 = txn2.from;
  ;
  const v40 = stdlib.protect(ctc1, await interact.getAcct(), {
    at: './rate.rsh:63:53:application',
    fs: ['at ./rate.rsh:62:16:application call to [unknown function] (defined at: ./rate.rsh:62:20:function exp)'],
    msg: 'getAcct',
    who: 'SecBuyer'
    });
  const v41 = stdlib.protect(ctc2, await interact.getScore(), {
    at: './rate.rsh:64:51:application',
    fs: ['at ./rate.rsh:62:16:application call to [unknown function] (defined at: ./rate.rsh:62:20:function exp)'],
    msg: 'getScore',
    who: 'SecBuyer'
    });
  
  const txn3 = await (ctc.sendrecv({
    args: [v17, v31, v32, v33, v41, v40],
    evt_cnt: 2,
    funcNum: 3,
    onlyIf: true,
    out_tys: [ctc2, ctc1],
    pay: [stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0), []],
    sim_p: (async (txn3) => {
      const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
      
      const [v43, v44] = txn3.data;
      const v46 = txn3.time;
      const v47 = txn3.secs;
      const v42 = txn3.from;
      
      sim_r.txns.push({
        amt: stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0),
        kind: 'to',
        tok: undefined
        });
      sim_r.isHalt = false;
      
      return sim_r;
      }),
    soloSend: true,
    timeoutAt: undefined,
    tys: [ctc1, ctc1, ctc0, ctc1, ctc2, ctc1],
    waitIfNotPresent: false
    }));
  const [v43, v44] = txn3.data;
  const v46 = txn3.time;
  const v47 = txn3.secs;
  const v42 = txn3.from;
  ;
  const txn4 = await (ctc.recv({
    evt_cnt: 2,
    funcNum: 4,
    out_tys: [ctc2, ctc2],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v52, v53] = txn4.data;
  const v56 = txn4.time;
  const v57 = txn4.secs;
  const v51 = txn4.from;
  ;
  const v55 = stdlib.addressEq(v31, v51);
  stdlib.assert(v55, {
    at: './rate.rsh:72:12:dot',
    fs: [],
    msg: 'sender correct',
    who: 'SecBuyer'
    });
  const v59 = stdlib.digest(ctc3, [v52, v53]);
  const v60 = stdlib.digestEq(v32, v59);
  stdlib.assert(v60, {
    at: 'reach standard library:65:17:application',
    fs: ['at ./rate.rsh:73:18:application call to "checkCommitment" (defined at: reach standard library:64:8:function exp)'],
    msg: null,
    who: 'SecBuyer'
    });
  const v61 = stdlib.ge(v53, stdlib.checkedBigNumberify('./rate.rsh:76:20:decimal', stdlib.UInt_max, 8));
  const v62 = stdlib.ge(v43, stdlib.checkedBigNumberify('./rate.rsh:76:38:decimal', stdlib.UInt_max, 8));
  const v63 = v61 ? v62 : false;
  if (v63) {
    const txn5 = await (ctc.recv({
      evt_cnt: 1,
      funcNum: 5,
      out_tys: [ctc4],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [v69] = txn5.data;
    const v72 = txn5.time;
    const v73 = txn5.secs;
    const v68 = txn5.from;
    ;
    const v71 = stdlib.addressEq(v31, v68);
    stdlib.assert(v71, {
      at: './rate.rsh:81:14:dot',
      fs: [],
      msg: 'sender correct',
      who: 'SecBuyer'
      });
    const v77 = stdlib.protect(ctc4, await interact.getChatInfo(), {
      at: './rate.rsh:85:59:application',
      fs: ['at ./rate.rsh:84:18:application call to [unknown function] (defined at: ./rate.rsh:84:22:function exp)'],
      msg: 'getChatInfo',
      who: 'SecBuyer'
      });
    stdlib.protect(ctc5, await interact.showChatInfo(v69), {
      at: './rate.rsh:86:28:application',
      fs: ['at ./rate.rsh:84:18:application call to [unknown function] (defined at: ./rate.rsh:84:22:function exp)'],
      msg: 'showChatInfo',
      who: 'SecBuyer'
      });
    
    const txn6 = await (ctc.sendrecv({
      args: [v17, v31, v33, v42, v43, v44, v53, v77],
      evt_cnt: 1,
      funcNum: 6,
      onlyIf: true,
      out_tys: [ctc4],
      pay: [stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0), []],
      sim_p: (async (txn6) => {
        const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
        
        const [v79] = txn6.data;
        const v82 = txn6.time;
        const v83 = txn6.secs;
        const v78 = txn6.from;
        
        sim_r.txns.push({
          amt: stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0),
          kind: 'to',
          tok: undefined
          });
        const v81 = stdlib.addressEq(v42, v78);
        stdlib.assert(v81, {
          at: './rate.rsh:88:14:dot',
          fs: [],
          msg: 'sender correct',
          who: 'SecBuyer'
          });
        sim_r.isHalt = false;
        
        return sim_r;
        }),
      soloSend: true,
      timeoutAt: undefined,
      tys: [ctc1, ctc1, ctc1, ctc1, ctc2, ctc1, ctc2, ctc4],
      waitIfNotPresent: false
      }));
    const [v79] = txn6.data;
    const v82 = txn6.time;
    const v83 = txn6.secs;
    const v78 = txn6.from;
    ;
    const v81 = stdlib.addressEq(v42, v78);
    stdlib.assert(v81, {
      at: './rate.rsh:88:14:dot',
      fs: [],
      msg: 'sender correct',
      who: 'SecBuyer'
      });
    const txn7 = await (ctc.recv({
      evt_cnt: 0,
      funcNum: 7,
      out_tys: [],
      timeoutAt: undefined,
      waitIfNotPresent: false
      }));
    const [] = txn7.data;
    const v90 = txn7.time;
    const v91 = txn7.secs;
    const v87 = txn7.from;
    ;
    const v89 = stdlib.addressEq(v31, v87);
    stdlib.assert(v89, {
      at: './rate.rsh:94:14:dot',
      fs: [],
      msg: 'sender correct',
      who: 'SecBuyer'
      });
    const v92 = stdlib.le(v53, stdlib.checkedBigNumberify('./rate.rsh:98:20:decimal', stdlib.UInt_max, 10));
    const v93 = stdlib.le(v43, stdlib.checkedBigNumberify('./rate.rsh:98:39:decimal', stdlib.UInt_max, 10));
    const v94 = v92 ? v93 : false;
    const v96 = stdlib.ge(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), stdlib.checkedBigNumberify('./rate.rsh:98:58:decimal', stdlib.UInt_max, 20));
    const v97 = v94 ? v96 : false;
    if (v97) {
      stdlib.protect(ctc5, await interact.showScore(v53), {
        at: './rate.rsh:102:25:application',
        fs: ['at ./rate.rsh:101:18:application call to [unknown function] (defined at: ./rate.rsh:101:22:function exp)'],
        msg: 'showScore',
        who: 'SecBuyer'
        });
      
      const txn8 = await (ctc.sendrecv({
        args: [v17, v31, v33, v42, v43, v44, v53],
        evt_cnt: 0,
        funcNum: 8,
        onlyIf: true,
        out_tys: [],
        pay: [stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0), []],
        sim_p: (async (txn8) => {
          const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
          
          const [] = txn8.data;
          const v104 = txn8.time;
          const v105 = txn8.secs;
          const v101 = txn8.from;
          
          sim_r.txns.push({
            amt: stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0),
            kind: 'to',
            tok: undefined
            });
          const v103 = stdlib.addressEq(v42, v101);
          stdlib.assert(v103, {
            at: './rate.rsh:104:14:dot',
            fs: [],
            msg: 'sender correct',
            who: 'SecBuyer'
            });
          sim_r.isHalt = false;
          
          return sim_r;
          }),
        soloSend: true,
        timeoutAt: undefined,
        tys: [ctc1, ctc1, ctc1, ctc1, ctc2, ctc1, ctc2],
        waitIfNotPresent: false
        }));
      const [] = txn8.data;
      const v104 = txn8.time;
      const v105 = txn8.secs;
      const v101 = txn8.from;
      ;
      const v103 = stdlib.addressEq(v42, v101);
      stdlib.assert(v103, {
        at: './rate.rsh:104:14:dot',
        fs: [],
        msg: 'sender correct',
        who: 'SecBuyer'
        });
      const txn9 = await (ctc.recv({
        evt_cnt: 0,
        funcNum: 9,
        out_tys: [],
        timeoutAt: undefined,
        waitIfNotPresent: false
        }));
      const [] = txn9.data;
      const v112 = txn9.time;
      const v113 = txn9.secs;
      const v109 = txn9.from;
      ;
      const v111 = stdlib.addressEq(v31, v109);
      stdlib.assert(v111, {
        at: './rate.rsh:110:14:dot',
        fs: [],
        msg: 'sender correct',
        who: 'SecBuyer'
        });
      const v117 = stdlib.sub(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), v53);
      ;
      const v121 = stdlib.sub(v117, v43);
      ;
      ;
      return;
      
      }
    else {
      ;
      return;}
    
    
    }
  else {
    const v92 = stdlib.le(v53, stdlib.checkedBigNumberify('./rate.rsh:98:20:decimal', stdlib.UInt_max, 10));
    const v93 = stdlib.le(v43, stdlib.checkedBigNumberify('./rate.rsh:98:39:decimal', stdlib.UInt_max, 10));
    const v94 = v92 ? v93 : false;
    const v96 = stdlib.ge(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), stdlib.checkedBigNumberify('./rate.rsh:98:58:decimal', stdlib.UInt_max, 20));
    const v97 = v94 ? v96 : false;
    if (v97) {
      stdlib.protect(ctc5, await interact.showScore(v53), {
        at: './rate.rsh:102:25:application',
        fs: ['at ./rate.rsh:101:18:application call to [unknown function] (defined at: ./rate.rsh:101:22:function exp)'],
        msg: 'showScore',
        who: 'SecBuyer'
        });
      
      const txn5 = await (ctc.sendrecv({
        args: [v17, v31, v33, v42, v43, v44, v53],
        evt_cnt: 0,
        funcNum: 10,
        onlyIf: true,
        out_tys: [],
        pay: [stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0), []],
        sim_p: (async (txn5) => {
          const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
          
          const [] = txn5.data;
          const v104 = txn5.time;
          const v105 = txn5.secs;
          const v101 = txn5.from;
          
          sim_r.txns.push({
            amt: stdlib.checkedBigNumberify('./rate.rsh:decimal', stdlib.UInt_max, 0),
            kind: 'to',
            tok: undefined
            });
          const v103 = stdlib.addressEq(v42, v101);
          stdlib.assert(v103, {
            at: './rate.rsh:104:14:dot',
            fs: [],
            msg: 'sender correct',
            who: 'SecBuyer'
            });
          sim_r.isHalt = false;
          
          return sim_r;
          }),
        soloSend: true,
        timeoutAt: undefined,
        tys: [ctc1, ctc1, ctc1, ctc1, ctc2, ctc1, ctc2],
        waitIfNotPresent: false
        }));
      const [] = txn5.data;
      const v104 = txn5.time;
      const v105 = txn5.secs;
      const v101 = txn5.from;
      ;
      const v103 = stdlib.addressEq(v42, v101);
      stdlib.assert(v103, {
        at: './rate.rsh:104:14:dot',
        fs: [],
        msg: 'sender correct',
        who: 'SecBuyer'
        });
      const txn6 = await (ctc.recv({
        evt_cnt: 0,
        funcNum: 11,
        out_tys: [],
        timeoutAt: undefined,
        waitIfNotPresent: false
        }));
      const [] = txn6.data;
      const v112 = txn6.time;
      const v113 = txn6.secs;
      const v109 = txn6.from;
      ;
      const v111 = stdlib.addressEq(v31, v109);
      stdlib.assert(v111, {
        at: './rate.rsh:110:14:dot',
        fs: [],
        msg: 'sender correct',
        who: 'SecBuyer'
        });
      const v117 = stdlib.sub(stdlib.checkedBigNumberify('./rate.rsh:47:15:application', stdlib.UInt_max, 200), v53);
      ;
      const v121 = stdlib.sub(v117, v43);
      ;
      ;
      return;
      
      }
    else {
      ;
      return;}}
  
  
  
  
  };

const _ALGO = {
  appApproval: `#pragma version 4
txn RekeyTo
global ZeroAddress
==
assert
txn Lease
global ZeroAddress
==
assert
int 0
store 0
txn ApplicationID
bz alloc
byte base64()
app_global_get
dup
substring 0 32
store 1
substring 32 64
store 2
txn NumAppArgs
int 3
==
assert
txna ApplicationArgs 0
btoi
dup
bz ctor
// Handler 1
dup
int 1
==
bz l0
pop
txna ApplicationArgs 1
dup
len
int 0
==
assert
pop
txna ApplicationArgs 2
dup
len
int 0
==
assert
pop
// compute state in HM_Check 0
int 8
bzero
sha256
load 1
==
assert
// "CheckPay"
// "./rate.rsh:47:8:dot"
// "[]"
int 200
dup
bz l1
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Receiver
==
assert
l1:
pop
// compute state in HM_Set 1
byte base64(AAAAAAAAAAE=)
txn Sender
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l0:
// Handler 2
dup
int 2
==
bz l2
pop
txna ApplicationArgs 1
dup
len
int 32
==
assert
dup
store 255
pop
txna ApplicationArgs 2
dup
len
int 64
==
assert
dup
substring 0 32
store 254
dup
substring 32 64
store 253
pop
// compute state in HM_Check 1
byte base64(AAAAAAAAAAE=)
load 255
concat
sha256
load 1
==
assert
// "CheckPay"
// "./rate.rsh:56:12:dot"
// "[]"
// compute state in HM_Set 2
byte base64(AAAAAAAAAAI=)
load 255
concat
txn Sender
concat
load 254
concat
load 253
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l2:
// Handler 3
dup
int 3
==
bz l3
pop
txna ApplicationArgs 1
dup
len
int 128
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
pop
txna ApplicationArgs 2
dup
len
int 40
==
assert
dup
substring 0 8
btoi
store 251
dup
substring 8 40
store 250
pop
// compute state in HM_Check 2
byte base64(AAAAAAAAAAI=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
sha256
load 1
==
assert
// "CheckPay"
// "./rate.rsh:66:12:dot"
// "[]"
// compute state in HM_Set 3
byte base64(AAAAAAAAAAM=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
txn Sender
concat
load 251
itob
concat
load 250
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l3:
// Handler 4
dup
int 4
==
bz l4
pop
txna ApplicationArgs 1
dup
len
int 200
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
dup
substring 128 160
store 251
dup
substring 160 168
btoi
store 250
dup
substring 168 200
store 249
pop
txna ApplicationArgs 2
dup
len
int 16
==
assert
dup
substring 0 8
btoi
store 248
dup
substring 8 16
btoi
store 247
pop
// compute state in HM_Check 3
byte base64(AAAAAAAAAAM=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
concat
load 250
itob
concat
load 249
concat
sha256
load 1
==
assert
// "CheckPay"
// "./rate.rsh:72:12:dot"
// "[]"
// Just "sender correct"
// "./rate.rsh:72:12:dot"
// "[]"
load 254
txn Sender
==
assert
// Nothing
// "reach standard library:65:17:application"
// "[at ./rate.rsh:73:18:application call to \"checkCommitment\" (defined at: reach standard library:64:8:function exp)]"
load 253
load 248
itob
load 247
itob
concat
sha256
==
assert
load 247
int 8
>=
load 250
int 8
>=
&&
bz l5
// compute state in HM_Set 4
byte base64(AAAAAAAAAAQ=)
load 255
concat
load 254
concat
load 252
concat
load 251
concat
load 250
itob
concat
load 249
concat
load 247
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l5:
load 247
int 10
<=
load 250
int 10
<=
&&
int 200
int 20
>=
&&
bz l6
// compute state in HM_Set 11
byte base64(AAAAAAAAAAs=)
load 255
concat
load 254
concat
load 252
concat
load 251
concat
load 250
itob
concat
load 249
concat
load 247
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l6:
int 200
dup
bz l7
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
load 255
dig 1
gtxns Receiver
==
assert
l7:
pop
int 0
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
global CreatorAddress
dig 1
gtxns CloseRemainderTo
==
assert
l8:
pop
global ZeroAddress
store 1
txn OnCompletion
int DeleteApplication
==
assert
b updateState
l4:
// Handler 5
dup
int 5
==
bz l9
pop
txna ApplicationArgs 1
dup
len
int 176
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
dup
substring 128 136
btoi
store 251
dup
substring 136 168
store 250
dup
substring 168 176
btoi
store 249
pop
txna ApplicationArgs 2
dup
len
int 32
==
assert
dup
store 248
pop
// compute state in HM_Check 4
byte base64(AAAAAAAAAAQ=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
itob
concat
load 250
concat
load 249
itob
concat
sha256
load 1
==
assert
// "CheckPay"
// "./rate.rsh:81:14:dot"
// "[]"
// Just "sender correct"
// "./rate.rsh:81:14:dot"
// "[]"
load 254
txn Sender
==
assert
// compute state in HM_Set 5
byte base64(AAAAAAAAAAU=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
itob
concat
load 250
concat
load 249
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l9:
// Handler 6
dup
int 6
==
bz l10
pop
txna ApplicationArgs 1
dup
len
int 176
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
dup
substring 128 136
btoi
store 251
dup
substring 136 168
store 250
dup
substring 168 176
btoi
store 249
pop
txna ApplicationArgs 2
dup
len
int 32
==
assert
dup
store 248
pop
// compute state in HM_Check 5
byte base64(AAAAAAAAAAU=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
itob
concat
load 250
concat
load 249
itob
concat
sha256
load 1
==
assert
// "CheckPay"
// "./rate.rsh:88:14:dot"
// "[]"
// Just "sender correct"
// "./rate.rsh:88:14:dot"
// "[]"
load 252
txn Sender
==
assert
// compute state in HM_Set 6
byte base64(AAAAAAAAAAY=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
itob
concat
load 250
concat
load 249
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l10:
// Handler 7
dup
int 7
==
bz l11
pop
txna ApplicationArgs 1
dup
len
int 176
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
dup
substring 128 136
btoi
store 251
dup
substring 136 168
store 250
dup
substring 168 176
btoi
store 249
pop
txna ApplicationArgs 2
dup
len
int 0
==
assert
pop
// compute state in HM_Check 6
byte base64(AAAAAAAAAAY=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
itob
concat
load 250
concat
load 249
itob
concat
sha256
load 1
==
assert
// "CheckPay"
// "./rate.rsh:94:14:dot"
// "[]"
// Just "sender correct"
// "./rate.rsh:94:14:dot"
// "[]"
load 254
txn Sender
==
assert
load 249
int 10
<=
load 251
int 10
<=
&&
int 200
int 20
>=
&&
bz l12
// compute state in HM_Set 7
byte base64(AAAAAAAAAAc=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
itob
concat
load 250
concat
load 249
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l12:
int 200
dup
bz l13
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
load 255
dig 1
gtxns Receiver
==
assert
l13:
pop
int 0
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
global CreatorAddress
dig 1
gtxns CloseRemainderTo
==
assert
l14:
pop
global ZeroAddress
store 1
txn OnCompletion
int DeleteApplication
==
assert
b updateState
l11:
// Handler 8
dup
int 8
==
bz l15
pop
txna ApplicationArgs 1
dup
len
int 176
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
dup
substring 128 136
btoi
store 251
dup
substring 136 168
store 250
dup
substring 168 176
btoi
store 249
pop
txna ApplicationArgs 2
dup
len
int 0
==
assert
pop
// compute state in HM_Check 7
byte base64(AAAAAAAAAAc=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
itob
concat
load 250
concat
load 249
itob
concat
sha256
load 1
==
assert
// "CheckPay"
// "./rate.rsh:104:14:dot"
// "[]"
// Just "sender correct"
// "./rate.rsh:104:14:dot"
// "[]"
load 252
txn Sender
==
assert
// compute state in HM_Set 8
byte base64(AAAAAAAAAAg=)
load 255
concat
load 254
concat
load 253
concat
load 251
itob
concat
load 250
concat
load 249
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l15:
// Handler 9
dup
int 9
==
bz l16
pop
txna ApplicationArgs 1
dup
len
int 144
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 104
btoi
store 252
dup
substring 104 136
store 251
dup
substring 136 144
btoi
store 250
pop
txna ApplicationArgs 2
dup
len
int 0
==
assert
pop
// compute state in HM_Check 8
byte base64(AAAAAAAAAAg=)
load 255
concat
load 254
concat
load 253
concat
load 252
itob
concat
load 251
concat
load 250
itob
concat
sha256
load 1
==
assert
// "CheckPay"
// "./rate.rsh:110:14:dot"
// "[]"
// Just "sender correct"
// "./rate.rsh:110:14:dot"
// "[]"
load 254
txn Sender
==
assert
load 250
dup
bz l17
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
load 251
dig 1
gtxns Receiver
==
assert
l17:
pop
load 252
dup
bz l18
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
load 253
dig 1
gtxns Receiver
==
assert
l18:
pop
int 200
load 250
-
load 252
-
dup
bz l19
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
load 255
dig 1
gtxns Receiver
==
assert
l19:
pop
int 0
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
global CreatorAddress
dig 1
gtxns CloseRemainderTo
==
assert
l20:
pop
global ZeroAddress
store 1
txn OnCompletion
int DeleteApplication
==
assert
b updateState
l16:
// Handler 10
dup
int 10
==
bz l21
pop
txna ApplicationArgs 1
dup
len
int 176
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 128
store 252
dup
substring 128 136
btoi
store 251
dup
substring 136 168
store 250
dup
substring 168 176
btoi
store 249
pop
txna ApplicationArgs 2
dup
len
int 0
==
assert
pop
// compute state in HM_Check 11
byte base64(AAAAAAAAAAs=)
load 255
concat
load 254
concat
load 253
concat
load 252
concat
load 251
itob
concat
load 250
concat
load 249
itob
concat
sha256
load 1
==
assert
// "CheckPay"
// "./rate.rsh:104:14:dot"
// "[]"
// Just "sender correct"
// "./rate.rsh:104:14:dot"
// "[]"
load 252
txn Sender
==
assert
// compute state in HM_Set 12
byte base64(AAAAAAAAAAw=)
load 255
concat
load 254
concat
load 253
concat
load 251
itob
concat
load 250
concat
load 249
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l21:
// Handler 11
dup
int 11
==
bz l22
pop
txna ApplicationArgs 1
dup
len
int 144
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
dup
substring 96 104
btoi
store 252
dup
substring 104 136
store 251
dup
substring 136 144
btoi
store 250
pop
txna ApplicationArgs 2
dup
len
int 0
==
assert
pop
// compute state in HM_Check 12
byte base64(AAAAAAAAAAw=)
load 255
concat
load 254
concat
load 253
concat
load 252
itob
concat
load 251
concat
load 250
itob
concat
sha256
load 1
==
assert
// "CheckPay"
// "./rate.rsh:110:14:dot"
// "[]"
// Just "sender correct"
// "./rate.rsh:110:14:dot"
// "[]"
load 254
txn Sender
==
assert
load 250
dup
bz l23
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
load 251
dig 1
gtxns Receiver
==
assert
l23:
pop
load 252
dup
bz l24
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
load 253
dig 1
gtxns Receiver
==
assert
l24:
pop
int 200
load 250
-
load 252
-
dup
bz l25
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
load 255
dig 1
gtxns Receiver
==
assert
l25:
pop
int 0
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
global CreatorAddress
dig 1
gtxns CloseRemainderTo
==
assert
l26:
pop
global ZeroAddress
store 1
txn OnCompletion
int DeleteApplication
==
assert
b updateState
l22:
int 0
assert
updateState:
byte base64()
load 1
load 2
concat
app_global_put
checkSize:
load 0
dup
dup
int 1
+
global GroupSize
==
assert
txn GroupIndex
==
assert
int 1000
*
txn Fee
<=
assert
done:
int 1
return
alloc:
txn OnCompletion
int NoOp
==
assert
byte base64()
int 64
bzero
app_global_put
b checkSize
ctor:
txn Sender
global CreatorAddress
==
assert
txna ApplicationArgs 1
store 2
// compute state in HM_Set 0
int 8
bzero
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
`,
  appClear: `#pragma version 4
int 0
`,
  escrow: `#pragma version 4
global GroupSize
int 1
-
dup
gtxns TypeEnum
int appl
==
assert
gtxns ApplicationID
int {{ApplicationID}}
==
assert
done:
int 1
`,
  mapDataKeys: 0,
  mapDataSize: 0,
  unsupported: [],
  version: 2,
  viewKeys: 0,
  viewSize: 0
  };
const _ETH = {
  ABI: `[
  {
    "inputs": [],
    "stateMutability": "payable",
    "type": "constructor"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "msg",
        "type": "uint256"
      }
    ],
    "name": "ReachError",
    "type": "error"
  },
  {
    "anonymous": false,
    "inputs": [],
    "name": "e0",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "internalType": "bool",
            "name": "svs",
            "type": "bool"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "indexed": false,
        "internalType": "struct T2",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e1",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v42",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T9",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "indexed": false,
        "internalType": "struct T16",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e10",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T17",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "indexed": false,
        "internalType": "struct T18",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e11",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              }
            ],
            "internalType": "struct T1",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint256",
                "name": "v32",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              }
            ],
            "internalType": "struct T4",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T5",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e2",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v32",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              }
            ],
            "internalType": "struct T3",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              }
            ],
            "internalType": "struct T7",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T8",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e3",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v32",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v42",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              }
            ],
            "internalType": "struct T6",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint256",
                "name": "v52",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T10",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T11",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e4",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v42",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T9",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint8[32]",
                "name": "v69",
                "type": "uint8[32]"
              }
            ],
            "internalType": "struct T12",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T13",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e5",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v42",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T9",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint8[32]",
                "name": "v79",
                "type": "uint8[32]"
              }
            ],
            "internalType": "struct T14",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T15",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e6",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v42",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T9",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "indexed": false,
        "internalType": "struct T16",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e7",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v42",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T9",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "indexed": false,
        "internalType": "struct T16",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e8",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T17",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "indexed": false,
        "internalType": "struct T18",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e9",
    "type": "event"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "internalType": "bool",
            "name": "svs",
            "type": "bool"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "internalType": "struct T2",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m1",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v42",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T9",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "internalType": "struct T16",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m10",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T17",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "internalType": "struct T18",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m11",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              }
            ],
            "internalType": "struct T1",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint256",
                "name": "v32",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              }
            ],
            "internalType": "struct T4",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T5",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m2",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v32",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              }
            ],
            "internalType": "struct T3",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              }
            ],
            "internalType": "struct T7",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T8",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m3",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v32",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v42",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              }
            ],
            "internalType": "struct T6",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint256",
                "name": "v52",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T10",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T11",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m4",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v42",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T9",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint8[32]",
                "name": "v69",
                "type": "uint8[32]"
              }
            ],
            "internalType": "struct T12",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T13",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m5",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v42",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T9",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint8[32]",
                "name": "v79",
                "type": "uint8[32]"
              }
            ],
            "internalType": "struct T14",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T15",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m6",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v42",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T9",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "internalType": "struct T16",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m7",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v42",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T9",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "internalType": "struct T16",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m8",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v17",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v31",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v33",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v43",
                "type": "uint256"
              },
              {
                "internalType": "address payable",
                "name": "v44",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v53",
                "type": "uint256"
              }
            ],
            "internalType": "struct T17",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "internalType": "struct T18",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m9",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "stateMutability": "payable",
    "type": "receive"
  }
]`,
  Bytecode: `0x608060408190527f49ff028a829527a47ec6839c7147b484eccf5a2a94853eddac09cef44d9d4e9e90600090a16040805180820182524381524260209182015281516000818301819052818401819052835180830385018152606090920190935280519101209055611827806100766000396000f3fe6080604052600436106100a05760003560e01c8063ae7a021211610064578063ae7a02121461010d578063b119da7f14610120578063bb1dec5214610133578063c521745214610146578063e13a3b3214610159578063ec4a86b61461016c57600080fd5b806304942939146100ac57806311dc32d7146100c15780631affa56e146100d457806325b43af6146100e757806363be6953146100fa57600080fd5b366100a757005b600080fd5b6100bf6100ba366004611308565b61017f565b005b6100bf6100cf366004611325565b610307565b6100bf6100e2366004611338565b61047a565b6100bf6100f5366004611338565b610622565b6100bf61010836600461136e565b6106cb565b6100bf61011b366004611325565b61088f565b6100bf61012e366004611325565b610a6a565b6100bf6101413660046112f5565b610bdd565b6100bf61015436600461135c565b610e9e565b6100bf610167366004611308565b610fd2565b6100bf61017a36600461134a565b61113b565b6040516101bb9061019790600590849060200161174f565b6040516020818303038152906040528051906020012060001c60005414601661120e565b600080556040517fe30905c6aebbbdbbfc08a3d89dd9f24a2b60c37c4c2af31dcc75e5c8fcea02ca906101ef9083906115be565b60405180910390a16102033415601461120e565b6102283361021760808401606085016112b8565b6001600160a01b031614601561120e565b610230611237565b61023d60208301836112b8565b6001600160a01b0316815261025860408301602084016112b8565b6001600160a01b0316602082015261027660608301604084016112b8565b6001600160a01b0316604082015261029460808301606084016112b8565b6001600160a01b03166060820152608080830135908201526102bc60c0830160a084016112b8565b6001600160a01b031660a082015260c080830135908201526040516102e8906006908390602001611764565b60408051601f1981840301815291905280516020909101206000555050565b6040516103439061031f90600b90849060200161174f565b6040516020818303038152906040528051906020012060001c60005414602261120e565b600080556040517f2bc6944c142828d99506b5e85038207c15977c2618cb132c383ba1ed6b34d840906103779083906115d3565b60405180910390a161038b3415602061120e565b6103b03361039f60808401606085016112b8565b6001600160a01b031614602161120e565b6040805160c08101825260008082526020808301829052928201819052606082018190526080820181905260a0820152906103ed908301836112b8565b6001600160a01b0316815261040860408301602084016112b8565b6001600160a01b0316602082015261042660608301604084016112b8565b6001600160a01b031660408201526080820135606082015261044e60c0830160a084016112b8565b6001600160a01b0316608082015260c082013560a08201526040516102e890600c9083906020016116a6565b6040516104b690610492906008908490602001611692565b6040516020818303038152906040528051906020012060001c60005414601f61120e565b600080556040517f2dc49a409e2ffc448aa7c4593f5ef81d045b172bb41d7b9a8fb60f475f060c5e906104ea9083906115fb565b60405180910390a16104fe3415601d61120e565b6105233361051260408401602085016112b8565b6001600160a01b031614601e61120e565b61053360a08201608083016112b8565b6040516001600160a01b03919091169060a083013580156108fc02916000818181858888f1935050505015801561056e573d6000803e3d6000fd5b5061057f60608201604083016112b8565b6040516001600160a01b039190911690606083013580156108fc02916000818181858888f193505050501580156105ba573d6000803e3d6000fd5b506105c860208201826112b8565b6001600160a01b03166108fc60608301356105e860a085013560c86117cc565b6105f291906117cc565b6040518115909202916000818181858888f1935050505015801561061a573d6000803e3d6000fd5b506000805533ff5b60405161065e9061063a90600c908490602001611692565b6040516020818303038152906040528051906020012060001c60005414602561120e565b600080556040517fdc57dcd62bc769e89611ee0736d811d7456cad47932b7a950b2354cb9a4511c6906106929083906115fb565b60405180910390a16106a63415602361120e565b610523336106ba60408401602085016112b8565b6001600160a01b031614602461120e565b604051610707906106e3906002908490602001611726565b6040516020818303038152906040528051906020012060001c60005414600c61120e565b600080556040517fffbd81903665fd119082dd6e1d90994cebe9bf22b0001191b0d53884c05b15419061073b908390611674565b60405180910390a161074f3415600b61120e565b6040805160e08101825260008082526020808301829052928201819052606082018190526080820181905260a0820181905260c082015290610793908301836112b8565b6001600160a01b031681526107ae60408301602084016112b8565b6001600160a01b03166020820152604080830135908201526107d660808301606084016112b8565b6001600160a01b031660608201523360808083019190915282013560a08083019190915261080a9060c084019084016112b8565b6001600160a01b031660c08201526040516102e890600390839060200160006101008201905083825260018060a01b03808451166020840152806020850151166040840152604084015160608401528060608501511660808401528060808501511660a084015260a084015160c08401528060c08501511660e0840152509392505050565b6040516108cb906108a790600690849060200161174f565b6040516020818303038152906040528051906020012060001c60005414601961120e565b600080556040517fd7abbab34db0b2465d932970aa322b08b83f21334873398426bffb5e73a90ab1906108ff9083906115d3565b60405180910390a16109133415601761120e565b6109383361092760408401602085016112b8565b6001600160a01b031614601861120e565b600a60c0820135111561094c576000610956565b600a608082013511155b610961576000610964565b60015b15610a2957610971611237565b61097e60208301836112b8565b6001600160a01b0316815261099960408301602084016112b8565b6001600160a01b031660208201526109b760608301604084016112b8565b6001600160a01b031660408201526109d560808301606084016112b8565b6001600160a01b03166060820152608080830135908201526109fd60c0830160a084016112b8565b6001600160a01b031660a082015260c080830135908201526040516102e8906007908390602001611764565b610a3660208201826112b8565b6040516001600160a01b03919091169060009060c89082818181858883f1935050505015801561061a573d6000803e3d6000fd5b604051610aa690610a8290600790849060200161174f565b6040516020818303038152906040528051906020012060001c60005414601c61120e565b600080556040517f6852b8f7982ab37bd51e73f5b23301c41a4228266a0b7d3b4347981b8e97c5ae90610ada9083906115d3565b60405180910390a1610aee3415601a61120e565b610b1333610b0260808401606085016112b8565b6001600160a01b031614601b61120e565b6040805160c08101825260008082526020808301829052928201819052606082018190526080820181905260a082015290610b50908301836112b8565b6001600160a01b03168152610b6b60408301602084016112b8565b6001600160a01b03166020820152610b8960608301604084016112b8565b6001600160a01b0316604082015260808201356060820152610bb160c0830160a084016112b8565b6001600160a01b0316608082015260c082013560a08201526040516102e89060089083906020016116a6565b604051610c1990610bf590600390849060200161173a565b6040516020818303038152906040528051906020012060001c60005414601061120e565b600080556040517f88f9cd25a213f2d1afd478a65f490499ca55e6a39f003cfadc5850196edee2e290610c4d908390611593565b60405180910390a1610c613415600d61120e565b610c8633610c7560408401602085016112b8565b6001600160a01b031614600e61120e565b6040805160e083013560208083019190915261010084013582840152825180830384018152606090920183528151910120610cc69183013514600f61120e565b60086101008201351015610cdb576000610ce5565b600860a082013510155b15610dab57610cf2611237565b610cff60208301836112b8565b6001600160a01b03168152610d1a60408301602084016112b8565b6001600160a01b03166020820152610d3860808301606084016112b8565b6001600160a01b03166040820152610d5660a08301608084016112b8565b6001600160a01b0316606082015260a08201356080820152610d7e60e0830160c084016112b8565b6001600160a01b031660a082015261010082013560c08201526040516102e8906004908390602001611764565b600a6101008201351115610dc0576000610dca565b600a60a082013511155b610dd5576000610dd8565b60015b15610a2957610de5611237565b610df260208301836112b8565b6001600160a01b03168152610e0d60408301602084016112b8565b6001600160a01b03166020820152610e2b60808301606084016112b8565b6001600160a01b03166040820152610e4960a08301608084016112b8565b6001600160a01b0316606082015260a08201356080820152610e7160e0830160c084016112b8565b6001600160a01b031660a082015261010082013560c08201526040516102e890600b908390602001611764565b604051610eda90610eb6906001908490602001611701565b6040516020818303038152906040528051906020012060001c60005414600a61120e565b600080556040517f4357fea14d50df246300cc74dcbf0ebebad00614ee0e6006e37d2ca616e5540890610f0e90839061164c565b60405180910390a1610f223415600961120e565b6040805160808101825260008082526020808301829052928201819052606082015290610f51908301836112b8565b6001600160a01b0316815233602080830191909152820135604080830191909152610f8290606084019084016112b8565b6001600160a01b03908116606083810191825260408051600260208083019190915286518616828401528601518516928101929092528401516080820152905190911660a082015260c0016102e8565b60405161100e90610fea90600490849060200161174f565b6040516020818303038152906040528051906020012060001c60005414601361120e565b600080556040517f8766ee030c7e6c29d14bc721ce20827a23e29a7754e460957c5c1634075a485b906110429083906115be565b60405180910390a16110563415601161120e565b61107b3361106a60408401602085016112b8565b6001600160a01b031614601261120e565b611083611237565b61109060208301836112b8565b6001600160a01b031681526110ab60408301602084016112b8565b6001600160a01b031660208201526110c960608301604084016112b8565b6001600160a01b031660408201526110e760808301606084016112b8565b6001600160a01b031660608201526080808301359082015261110f60c0830160a084016112b8565b6001600160a01b031660a082015260c080830135908201526040516102e8906005908390602001611764565b61118d600061114d60208401846112da565b6040516020016111699291909182521515602082015260400190565b6040516020818303038152906040528051906020012060001c60005414600861120e565b600080556040517f5e47fb10d935e98c9d164e80e2ec67992cd9431bcb564d8c410f734df4b0c8f4906111c1908390611622565b60405180910390a16111d760c83414600761120e565b604080516020810190915260008152338152604080516001602082015282516001600160a01b0316918101919091526060016102e8565b816112335760405163100960cb60e01b81526004810182905260240160405180910390fd5b5050565b6040805160e081018252600080825260208201819052918101829052606081018290526080810182905260a0810182905260c081019190915290565b80356001600160a01b038116811461128a57600080fd5b919050565b8035801515811461128a57600080fd5b60006104e082840312156112b257600080fd5b50919050565b6000602082840312156112ca57600080fd5b6112d382611273565b9392505050565b6000602082840312156112ec57600080fd5b6112d38261128f565b600061012082840312156112b257600080fd5b60006104e0828403121561131b57600080fd5b6112d3838361129f565b600061010082840312156112b257600080fd5b600060e082840312156112b257600080fd5b6000604082840312156112b257600080fd5b6000606082840312156112b257600080fd5b600060c082840312156112b257600080fd5b61138a828261151c565b60e0820160e082016000805b60208082106113a557506113ca565b833560ff81168082146113b6578485fd5b865250938401939290920191600101611396565b505050505050565b6001600160a01b03806113e483611273565b168352806113f460208401611273565b1660208401528061140760408401611273565b166040840152606082013560608401528061142460808401611273565b1660808401525060a090810135910152565b6001600160a01b038061144883611273565b1683528061145860208401611273565b166020840152604082013560408401528061147560608401611273565b166060840152505050565b803582526001600160a01b0361149860208301611273565b1660208301525050565b6001600160a01b03806114b483611273565b168352806114c460208401611273565b16602084015260408201356040840152806114e160608401611273565b166060840152806114f460808401611273565b16608084015260a082013560a08401528061151160c08401611273565b1660c0840152505050565b6001600160a01b038061152e83611273565b1683528061153e60208401611273565b1660208401528061155160408401611273565b1660408401528061156460608401611273565b166060840152608082013560808401528061158160a08401611273565b1660a08401525060c090810135910152565b61012081016115a282846114a2565b60e083013560e083015261010080840135818401525092915050565b6104e081016115cd8284611380565b92915050565b61010081016115e2828461151c565b6115ee60e0840161128f565b151560e083015292915050565b60e0810161160982846113d2565b61161560c0840161128f565b151560c083015292915050565b6040810161162f8361128f565b1515825261163f6020840161128f565b1515602083015292915050565b606081016001600160a01b0361166184611273565b1682526115cd6020830160208501611480565b60c081016116828284611436565b6115cd6080830160808501611480565b82815260e081016112d360208301846113d2565b600060e08201905083825260018060a01b03808451166020840152806020850151166040840152806040850151166060840152606084015160808401528060808501511660a08401525060a083015160c08301529392505050565b828152604081016001600160a01b0361171984611273565b1660208301529392505050565b82815260a081016112d36020830184611436565b82815261010081016112d360208301846114a2565b82815261010081016112d3602083018461151c565b60006101008201905083825260018060a01b03808451166020840152806020850151166040840152806040850151166060840152806060850151166080840152608084015160a08401528060a08501511660c08401525060c083015160e08301529392505050565b6000828210156117ec57634e487b7160e01b600052601160045260246000fd5b50039056fea264697066735822122016e07bef980063d56df2b5803a986f2730404ab47fcc0ce20e4947315bae779d64736f6c63430008050033`,
  BytecodeLen: 6301,
  Which: `oD`,
  deployMode: `DM_constructor`,
  version: 1,
  views: {
    }
  };

export const _Connectors = {
  ALGO: _ALGO,
  ETH: _ETH
  };

