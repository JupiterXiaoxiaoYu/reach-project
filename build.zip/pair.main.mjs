// Automatically generated with Reach 0.1.3
/* eslint-disable */
export const _version = '0.1.3';
export const _backendVersion = 1;


export function getExports(s) {
  const stdlib = s.reachStdlib;
  return {
    };
  };

export function _getViews(s, viewlib) {
  const stdlib = s.reachStdlib;
  const ctc0 = stdlib.T_Address;
  
  return {
    infos: {
      "NFT": {
        owner1: {
          decode: async (i, svs, args) => {
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 1))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 2))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            
            stdlib.assert(false, 'illegal view')
            },
          ty: ctc0
          },
        owner2: {
          decode: async (i, svs, args) => {
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 1))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            if (stdlib.eq(i, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 2))) {
              const [] = svs;
              stdlib.assert(false, 'illegal view')
              }
            
            stdlib.assert(false, 'illegal view')
            },
          ty: ctc0
          }
        }
      },
    views: {
      1: [],
      2: []
      }
    };
  
  };

export function _getMaps(s) {
  const stdlib = s.reachStdlib;
  const ctc0 = stdlib.T_Tuple([]);
  return {
    mapDataTy: ctc0
    };
  };

export async function FirBuyer(ctc, interact) {
  if (typeof(ctc) !== 'object' || ctc.sendrecv === undefined) {
    return Promise.reject(new Error(`The backend for FirBuyer expects to receive a contract as its first argument.`));}
  if (typeof(interact) !== 'object') {
    return Promise.reject(new Error(`The backend for FirBuyer expects to receive an interact object as its second argument.`));}
  const stdlib = ctc.stdlib;
  const ctc0 = stdlib.T_Address;
  const ctc1 = stdlib.T_Bytes(stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 32));
  const ctc2 = stdlib.T_Null;
  const ctc3 = stdlib.T_Data({
    FirBuyer: ctc1,
    SecBuyer: ctc1
    });
  const ctc4 = stdlib.T_UInt;
  const ctc5 = stdlib.T_Array(ctc1, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 32));
  
  
  const v15 = await ctc.creationTime();
  const v16 = await ctc.creationSecs();
  
  const v20 = stdlib.protect(ctc0, await interact.getAcct(), {
    at: './pair.rsh:56:53:application',
    fs: ['at ./pair.rsh:55:14:application call to [unknown function] (defined at: ./pair.rsh:55:18:function exp)'],
    msg: 'getAcct',
    who: 'FirBuyer'
    });
  const v21 = stdlib.protect(ctc1, await interact.getPersonalInfo(), {
    at: './pair.rsh:57:66:application',
    fs: ['at ./pair.rsh:55:14:application call to [unknown function] (defined at: ./pair.rsh:55:18:function exp)'],
    msg: 'getPersonalInfo',
    who: 'FirBuyer'
    });
  const v22 = stdlib.protect(ctc0, await interact.getInfo(), {
    at: './pair.rsh:58:49:application',
    fs: ['at ./pair.rsh:55:14:application call to [unknown function] (defined at: ./pair.rsh:55:18:function exp)'],
    msg: 'getInfo',
    who: 'FirBuyer'
    });
  
  const txn1 = await (ctc.sendrecv({
    args: [v21, v22, v20],
    evt_cnt: 3,
    funcNum: 1,
    onlyIf: true,
    out_tys: [ctc1, ctc0, ctc0],
    pay: [stdlib.checkedBigNumberify('./pair.rsh:decimal', stdlib.UInt_max, 0), []],
    sim_p: (async (txn1) => {
      const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
      
      const [v24, v25, v26] = txn1.data;
      const v28 = txn1.time;
      const v29 = txn1.secs;
      const v23 = txn1.from;
      
      sim_r.txns.push({
        amt: stdlib.checkedBigNumberify('./pair.rsh:decimal', stdlib.UInt_max, 0),
        kind: 'to',
        tok: undefined
        });
      sim_r.isHalt = false;
      
      return sim_r;
      }),
    soloSend: true,
    timeoutAt: undefined,
    tys: [ctc1, ctc0, ctc0],
    waitIfNotPresent: false
    }));
  const [v24, v25, v26] = txn1.data;
  const v28 = txn1.time;
  const v29 = txn1.secs;
  const v23 = txn1.from;
  ;
  const txn2 = await (ctc.recv({
    evt_cnt: 3,
    funcNum: 2,
    out_tys: [ctc1, ctc0, ctc0],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v37, v38, v39] = txn2.data;
  const v41 = txn2.time;
  const v42 = txn2.secs;
  const v36 = txn2.from;
  ;
  const v45 = stdlib.add(v28, stdlib.checkedBigNumberify('./pair.rsh:74:59:decimal', stdlib.UInt_max, 30));
  const v83 = ['                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                '];
  let v84 = v83;
  let v85 = stdlib.checkedBigNumberify('./pair.rsh:76:45:decimal', stdlib.UInt_max, 0);
  let v183 = v41;
  let v184 = v28;
  
  while ((() => {
    const v93 = stdlib.gt(v45, v184);
    const v94 = stdlib.lt(v85, stdlib.checkedBigNumberify('./pair.rsh:78:39:decimal', stdlib.UInt_max, 32));
    const v95 = v93 ? v94 : false;
    
    return v95;})()) {
    const v166 = stdlib.sub(v45, v184);
    const v170 = stdlib.add(v183, v166);
    stdlib.protect(ctc2, await interact.showDialog(v84), {
      at: './pair.rsh:81:30:application',
      fs: ['at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:80:13:function exp)', 'at ./pair.rsh:76:19:application call to "runFirBuyer0" (defined at: ./pair.rsh:76:19:function exp)', 'at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:76:19:function exp)'],
      msg: 'showDialog',
      who: 'FirBuyer'
      });
    const v112 = stdlib.protect(ctc1, await interact.getWords(), {
      at: './pair.rsh:82:53:application',
      fs: ['at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:80:13:function exp)', 'at ./pair.rsh:76:19:application call to "runFirBuyer0" (defined at: ./pair.rsh:76:19:function exp)', 'at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:76:19:function exp)'],
      msg: 'getWords',
      who: 'FirBuyer'
      });
    
    const v123 = ['FirBuyer', v112];
    
    const txn3 = await (ctc.sendrecv({
      args: [v23, v36, v45, v84, v85, v170, v183, v123],
      evt_cnt: 1,
      funcNum: 5,
      onlyIf: true,
      out_tys: [ctc3],
      pay: [stdlib.checkedBigNumberify('./pair.rsh:79:12:decimal', stdlib.UInt_max, 0), []],
      sim_p: (async (txn3) => {
        const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
        
        const [v130] = txn3.data;
        const v141 = txn3.time;
        const v142 = txn3.secs;
        const v129 = txn3.from;
        
        let v131;
        switch (v130[0]) {
          case 'FirBuyer': {
            const v132 = v130[1];
            v131 = stdlib.checkedBigNumberify('./pair.rsh:79:12:decimal', stdlib.UInt_max, 0);
            
            break;
            }
          case 'SecBuyer': {
            const v134 = v130[1];
            v131 = stdlib.checkedBigNumberify('./pair.rsh:91:12:decimal', stdlib.UInt_max, 0);
            
            break;
            }
          }
        sim_r.txns.push({
          amt: v131,
          kind: 'to',
          tok: undefined
          });
        const v138 = stdlib.addressEq(v23, v129);
        const v139 = stdlib.addressEq(v36, v129);
        const v140 = v138 ? true : v139;
        stdlib.assert(v140, {
          at: './pair.rsh:76:19:dot',
          fs: [],
          msg: 'sender correct',
          who: 'FirBuyer'
          });
        let v143;
        switch (v130[0]) {
          case 'FirBuyer': {
            const v144 = v130[1];
            const v146 = stdlib.addressEq(v129, v23);
            v143 = v146;
            
            break;
            }
          case 'SecBuyer': {
            const v147 = v130[1];
            const v149 = stdlib.addressEq(v129, v36);
            v143 = v149;
            
            break;
            }
          }
        stdlib.assert(v143, {
          at: './pair.rsh:76:19:application',
          fs: [],
          msg: null,
          who: 'FirBuyer'
          });
        switch (v130[0]) {
          case 'FirBuyer': {
            const v150 = v130[1];
            const v154 = stdlib.Array_set(v84, v85, v150);
            const v155 = stdlib.add(v85, stdlib.checkedBigNumberify('./pair.rsh:88:49:decimal', stdlib.UInt_max, 1));
            const cv84 = v154;
            const cv85 = v155;
            const cv183 = v141;
            const cv184 = v183;
            
            (() => {
              const v84 = cv84;
              const v85 = cv85;
              const v183 = cv183;
              const v184 = cv184;
              
              if ((() => {
                const v93 = stdlib.gt(v45, v184);
                const v94 = stdlib.lt(v85, stdlib.checkedBigNumberify('./pair.rsh:78:39:decimal', stdlib.UInt_max, 32));
                const v95 = v93 ? v94 : false;
                
                return v95;})()) {
                const v166 = stdlib.sub(v45, v184);
                const v170 = stdlib.add(v183, v166);
                sim_r.isHalt = false;
                }
              else {
                sim_r.txns.push({
                  kind: 'halt',
                  tok: undefined
                  })
                sim_r.isHalt = true;
                }})();
            break;
            }
          case 'SecBuyer': {
            const v157 = v130[1];
            const v161 = stdlib.Array_set(v84, v85, v157);
            const v162 = stdlib.add(v85, stdlib.checkedBigNumberify('./pair.rsh:101:49:decimal', stdlib.UInt_max, 1));
            const cv84 = v161;
            const cv85 = v162;
            const cv183 = v141;
            const cv184 = v183;
            
            (() => {
              const v84 = cv84;
              const v85 = cv85;
              const v183 = cv183;
              const v184 = cv184;
              
              if ((() => {
                const v93 = stdlib.gt(v45, v184);
                const v94 = stdlib.lt(v85, stdlib.checkedBigNumberify('./pair.rsh:78:39:decimal', stdlib.UInt_max, 32));
                const v95 = v93 ? v94 : false;
                
                return v95;})()) {
                const v166 = stdlib.sub(v45, v184);
                const v170 = stdlib.add(v183, v166);
                sim_r.isHalt = false;
                }
              else {
                sim_r.txns.push({
                  kind: 'halt',
                  tok: undefined
                  })
                sim_r.isHalt = true;
                }})();
            break;
            }
          }
        return sim_r;
        }),
      soloSend: false,
      timeoutAt: ['time', v170],
      tys: [ctc0, ctc0, ctc4, ctc5, ctc4, ctc4, ctc4, ctc3],
      waitIfNotPresent: false
      }));
    if (txn3.didTimeout) {
      const txn4 = await (ctc.sendrecv({
        args: [v23, v36, v45, v84, v85, v170, v183],
        evt_cnt: 0,
        funcNum: 6,
        onlyIf: true,
        out_tys: [],
        pay: [stdlib.checkedBigNumberify('./pair.rsh:decimal', stdlib.UInt_max, 0), []],
        sim_p: (async (txn4) => {
          const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
          
          const [] = txn4.data;
          const v178 = txn4.time;
          const v179 = txn4.secs;
          const v173 = txn4.from;
          
          sim_r.txns.push({
            amt: stdlib.checkedBigNumberify('./pair.rsh:decimal', stdlib.UInt_max, 0),
            kind: 'to',
            tok: undefined
            });
          const v175 = stdlib.addressEq(v23, v173);
          const v176 = stdlib.addressEq(v36, v173);
          const v177 = v175 ? true : v176;
          stdlib.assert(v177, {
            at: './pair.rsh:104:69:dot',
            fs: ['at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:76:19:function exp)'],
            msg: 'sender correct',
            who: 'FirBuyer'
            });
          const cv84 = v84;
          const cv85 = v85;
          const cv183 = v178;
          const cv184 = v183;
          
          (() => {
            const v84 = cv84;
            const v85 = cv85;
            const v183 = cv183;
            const v184 = cv184;
            
            if ((() => {
              const v93 = stdlib.gt(v45, v184);
              const v94 = stdlib.lt(v85, stdlib.checkedBigNumberify('./pair.rsh:78:39:decimal', stdlib.UInt_max, 32));
              const v95 = v93 ? v94 : false;
              
              return v95;})()) {
              const v166 = stdlib.sub(v45, v184);
              const v170 = stdlib.add(v183, v166);
              sim_r.isHalt = false;
              }
            else {
              sim_r.txns.push({
                kind: 'halt',
                tok: undefined
                })
              sim_r.isHalt = true;
              }})();
          return sim_r;
          }),
        soloSend: false,
        timeoutAt: undefined,
        tys: [ctc0, ctc0, ctc4, ctc5, ctc4, ctc4, ctc4],
        waitIfNotPresent: false
        }));
      const [] = txn4.data;
      const v178 = txn4.time;
      const v179 = txn4.secs;
      const v173 = txn4.from;
      ;
      const v175 = stdlib.addressEq(v23, v173);
      const v176 = stdlib.addressEq(v36, v173);
      const v177 = v175 ? true : v176;
      stdlib.assert(v177, {
        at: './pair.rsh:104:69:dot',
        fs: ['at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:76:19:function exp)'],
        msg: 'sender correct',
        who: 'FirBuyer'
        });
      const cv84 = v84;
      const cv85 = v85;
      const cv183 = v178;
      const cv184 = v183;
      
      v84 = cv84;
      v85 = cv85;
      v183 = cv183;
      v184 = cv184;
      
      continue;
      }
    else {
      const [v130] = txn3.data;
      const v141 = txn3.time;
      const v142 = txn3.secs;
      const v129 = txn3.from;
      let v131;
      switch (v130[0]) {
        case 'FirBuyer': {
          const v132 = v130[1];
          v131 = stdlib.checkedBigNumberify('./pair.rsh:79:12:decimal', stdlib.UInt_max, 0);
          
          break;
          }
        case 'SecBuyer': {
          const v134 = v130[1];
          v131 = stdlib.checkedBigNumberify('./pair.rsh:91:12:decimal', stdlib.UInt_max, 0);
          
          break;
          }
        }
      ;
      const v138 = stdlib.addressEq(v23, v129);
      const v139 = stdlib.addressEq(v36, v129);
      const v140 = v138 ? true : v139;
      stdlib.assert(v140, {
        at: './pair.rsh:76:19:dot',
        fs: [],
        msg: 'sender correct',
        who: 'FirBuyer'
        });
      let v143;
      switch (v130[0]) {
        case 'FirBuyer': {
          const v144 = v130[1];
          const v146 = stdlib.addressEq(v129, v23);
          v143 = v146;
          
          break;
          }
        case 'SecBuyer': {
          const v147 = v130[1];
          const v149 = stdlib.addressEq(v129, v36);
          v143 = v149;
          
          break;
          }
        }
      stdlib.assert(v143, {
        at: './pair.rsh:76:19:application',
        fs: [],
        msg: null,
        who: 'FirBuyer'
        });
      switch (v130[0]) {
        case 'FirBuyer': {
          const v150 = v130[1];
          const v154 = stdlib.Array_set(v84, v85, v150);
          const v155 = stdlib.add(v85, stdlib.checkedBigNumberify('./pair.rsh:88:49:decimal', stdlib.UInt_max, 1));
          const cv84 = v154;
          const cv85 = v155;
          const cv183 = v141;
          const cv184 = v183;
          
          v84 = cv84;
          v85 = cv85;
          v183 = cv183;
          v184 = cv184;
          
          continue;
          break;
          }
        case 'SecBuyer': {
          const v157 = v130[1];
          const v161 = stdlib.Array_set(v84, v85, v157);
          const v162 = stdlib.add(v85, stdlib.checkedBigNumberify('./pair.rsh:101:49:decimal', stdlib.UInt_max, 1));
          const cv84 = v161;
          const cv85 = v162;
          const cv183 = v141;
          const cv184 = v183;
          
          v84 = cv84;
          v85 = cv85;
          v183 = cv183;
          v184 = cv184;
          
          continue;
          break;
          }
        }}
    }
  return;
  
  
  };
export async function Oracle(ctc, interact) {
  if (typeof(ctc) !== 'object' || ctc.sendrecv === undefined) {
    return Promise.reject(new Error(`The backend for Oracle expects to receive a contract as its first argument.`));}
  if (typeof(interact) !== 'object') {
    return Promise.reject(new Error(`The backend for Oracle expects to receive an interact object as its second argument.`));}
  const stdlib = ctc.stdlib;
  const ctc0 = stdlib.T_Bytes(stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 32));
  const ctc1 = stdlib.T_Address;
  const ctc2 = stdlib.T_Data({
    FirBuyer: ctc0,
    SecBuyer: ctc0
    });
  
  
  const v15 = await ctc.creationTime();
  const v16 = await ctc.creationSecs();
  
  const txn1 = await (ctc.recv({
    evt_cnt: 3,
    funcNum: 1,
    out_tys: [ctc0, ctc1, ctc1],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v24, v25, v26] = txn1.data;
  const v28 = txn1.time;
  const v29 = txn1.secs;
  const v23 = txn1.from;
  ;
  const txn2 = await (ctc.recv({
    evt_cnt: 3,
    funcNum: 2,
    out_tys: [ctc0, ctc1, ctc1],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v37, v38, v39] = txn2.data;
  const v41 = txn2.time;
  const v42 = txn2.secs;
  const v36 = txn2.from;
  ;
  const v45 = stdlib.add(v28, stdlib.checkedBigNumberify('./pair.rsh:74:59:decimal', stdlib.UInt_max, 30));
  const v83 = ['                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                '];
  let v84 = v83;
  let v85 = stdlib.checkedBigNumberify('./pair.rsh:76:45:decimal', stdlib.UInt_max, 0);
  let v183 = v41;
  let v184 = v28;
  
  while ((() => {
    const v93 = stdlib.gt(v45, v184);
    const v94 = stdlib.lt(v85, stdlib.checkedBigNumberify('./pair.rsh:78:39:decimal', stdlib.UInt_max, 32));
    const v95 = v93 ? v94 : false;
    
    return v95;})()) {
    const v166 = stdlib.sub(v45, v184);
    const v170 = stdlib.add(v183, v166);
    const txn3 = await (ctc.recv({
      evt_cnt: 1,
      funcNum: 5,
      out_tys: [ctc2],
      timeoutAt: ['time', v170],
      waitIfNotPresent: false
      }));
    if (txn3.didTimeout) {
      const txn4 = await (ctc.recv({
        evt_cnt: 0,
        funcNum: 6,
        out_tys: [],
        timeoutAt: undefined,
        waitIfNotPresent: false
        }));
      const [] = txn4.data;
      const v178 = txn4.time;
      const v179 = txn4.secs;
      const v173 = txn4.from;
      ;
      const v175 = stdlib.addressEq(v23, v173);
      const v176 = stdlib.addressEq(v36, v173);
      const v177 = v175 ? true : v176;
      stdlib.assert(v177, {
        at: './pair.rsh:104:69:dot',
        fs: ['at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:76:19:function exp)'],
        msg: 'sender correct',
        who: 'Oracle'
        });
      const cv84 = v84;
      const cv85 = v85;
      const cv183 = v178;
      const cv184 = v183;
      
      v84 = cv84;
      v85 = cv85;
      v183 = cv183;
      v184 = cv184;
      
      continue;
      }
    else {
      const [v130] = txn3.data;
      const v141 = txn3.time;
      const v142 = txn3.secs;
      const v129 = txn3.from;
      let v131;
      switch (v130[0]) {
        case 'FirBuyer': {
          const v132 = v130[1];
          v131 = stdlib.checkedBigNumberify('./pair.rsh:79:12:decimal', stdlib.UInt_max, 0);
          
          break;
          }
        case 'SecBuyer': {
          const v134 = v130[1];
          v131 = stdlib.checkedBigNumberify('./pair.rsh:91:12:decimal', stdlib.UInt_max, 0);
          
          break;
          }
        }
      ;
      const v138 = stdlib.addressEq(v23, v129);
      const v139 = stdlib.addressEq(v36, v129);
      const v140 = v138 ? true : v139;
      stdlib.assert(v140, {
        at: './pair.rsh:76:19:dot',
        fs: [],
        msg: 'sender correct',
        who: 'Oracle'
        });
      let v143;
      switch (v130[0]) {
        case 'FirBuyer': {
          const v144 = v130[1];
          const v146 = stdlib.addressEq(v129, v23);
          v143 = v146;
          
          break;
          }
        case 'SecBuyer': {
          const v147 = v130[1];
          const v149 = stdlib.addressEq(v129, v36);
          v143 = v149;
          
          break;
          }
        }
      stdlib.assert(v143, {
        at: './pair.rsh:76:19:application',
        fs: [],
        msg: null,
        who: 'Oracle'
        });
      switch (v130[0]) {
        case 'FirBuyer': {
          const v150 = v130[1];
          const v154 = stdlib.Array_set(v84, v85, v150);
          const v155 = stdlib.add(v85, stdlib.checkedBigNumberify('./pair.rsh:88:49:decimal', stdlib.UInt_max, 1));
          const cv84 = v154;
          const cv85 = v155;
          const cv183 = v141;
          const cv184 = v183;
          
          v84 = cv84;
          v85 = cv85;
          v183 = cv183;
          v184 = cv184;
          
          continue;
          break;
          }
        case 'SecBuyer': {
          const v157 = v130[1];
          const v161 = stdlib.Array_set(v84, v85, v157);
          const v162 = stdlib.add(v85, stdlib.checkedBigNumberify('./pair.rsh:101:49:decimal', stdlib.UInt_max, 1));
          const cv84 = v161;
          const cv85 = v162;
          const cv183 = v141;
          const cv184 = v183;
          
          v84 = cv84;
          v85 = cv85;
          v183 = cv183;
          v184 = cv184;
          
          continue;
          break;
          }
        }}
    }
  return;
  
  
  };
export async function SecBuyer(ctc, interact) {
  if (typeof(ctc) !== 'object' || ctc.sendrecv === undefined) {
    return Promise.reject(new Error(`The backend for SecBuyer expects to receive a contract as its first argument.`));}
  if (typeof(interact) !== 'object') {
    return Promise.reject(new Error(`The backend for SecBuyer expects to receive an interact object as its second argument.`));}
  const stdlib = ctc.stdlib;
  const ctc0 = stdlib.T_Bytes(stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 32));
  const ctc1 = stdlib.T_Address;
  const ctc2 = stdlib.T_Null;
  const ctc3 = stdlib.T_Data({
    FirBuyer: ctc0,
    SecBuyer: ctc0
    });
  const ctc4 = stdlib.T_UInt;
  const ctc5 = stdlib.T_Array(ctc0, stdlib.checkedBigNumberify('<builtin>', stdlib.UInt_max, 32));
  
  
  const v15 = await ctc.creationTime();
  const v16 = await ctc.creationSecs();
  
  const txn1 = await (ctc.recv({
    evt_cnt: 3,
    funcNum: 1,
    out_tys: [ctc0, ctc1, ctc1],
    timeoutAt: undefined,
    waitIfNotPresent: false
    }));
  const [v24, v25, v26] = txn1.data;
  const v28 = txn1.time;
  const v29 = txn1.secs;
  const v23 = txn1.from;
  ;
  const v33 = stdlib.protect(ctc1, await interact.getAcct(), {
    at: './pair.rsh:66:53:application',
    fs: ['at ./pair.rsh:65:16:application call to [unknown function] (defined at: ./pair.rsh:65:20:function exp)'],
    msg: 'getAcct',
    who: 'SecBuyer'
    });
  const v34 = stdlib.protect(ctc0, await interact.getPersonalInfo(), {
    at: './pair.rsh:67:66:application',
    fs: ['at ./pair.rsh:65:16:application call to [unknown function] (defined at: ./pair.rsh:65:20:function exp)'],
    msg: 'getPersonalInfo',
    who: 'SecBuyer'
    });
  const v35 = stdlib.protect(ctc1, await interact.getInfo(), {
    at: './pair.rsh:68:49:application',
    fs: ['at ./pair.rsh:65:16:application call to [unknown function] (defined at: ./pair.rsh:65:20:function exp)'],
    msg: 'getInfo',
    who: 'SecBuyer'
    });
  
  const txn2 = await (ctc.sendrecv({
    args: [v23, v28, v34, v35, v33],
    evt_cnt: 3,
    funcNum: 2,
    onlyIf: true,
    out_tys: [ctc0, ctc1, ctc1],
    pay: [stdlib.checkedBigNumberify('./pair.rsh:decimal', stdlib.UInt_max, 0), []],
    sim_p: (async (txn2) => {
      const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
      
      const [v37, v38, v39] = txn2.data;
      const v41 = txn2.time;
      const v42 = txn2.secs;
      const v36 = txn2.from;
      
      sim_r.txns.push({
        amt: stdlib.checkedBigNumberify('./pair.rsh:decimal', stdlib.UInt_max, 0),
        kind: 'to',
        tok: undefined
        });
      const v45 = stdlib.add(v28, stdlib.checkedBigNumberify('./pair.rsh:74:59:decimal', stdlib.UInt_max, 30));
      const v83 = ['                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                '];
      const v84 = v83;
      const v85 = stdlib.checkedBigNumberify('./pair.rsh:76:45:decimal', stdlib.UInt_max, 0);
      const v183 = v41;
      const v184 = v28;
      
      if ((() => {
        const v93 = stdlib.gt(v45, v184);
        const v94 = stdlib.lt(v85, stdlib.checkedBigNumberify('./pair.rsh:78:39:decimal', stdlib.UInt_max, 32));
        const v95 = v93 ? v94 : false;
        
        return v95;})()) {
        const v166 = stdlib.sub(v45, v184);
        const v170 = stdlib.add(v183, v166);
        sim_r.isHalt = false;
        }
      else {
        sim_r.txns.push({
          kind: 'halt',
          tok: undefined
          })
        sim_r.isHalt = true;
        }
      return sim_r;
      }),
    soloSend: true,
    timeoutAt: undefined,
    tys: [ctc1, ctc4, ctc0, ctc1, ctc1],
    waitIfNotPresent: false
    }));
  const [v37, v38, v39] = txn2.data;
  const v41 = txn2.time;
  const v42 = txn2.secs;
  const v36 = txn2.from;
  ;
  const v45 = stdlib.add(v28, stdlib.checkedBigNumberify('./pair.rsh:74:59:decimal', stdlib.UInt_max, 30));
  const v83 = ['                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                ', '                                '];
  let v84 = v83;
  let v85 = stdlib.checkedBigNumberify('./pair.rsh:76:45:decimal', stdlib.UInt_max, 0);
  let v183 = v41;
  let v184 = v28;
  
  while ((() => {
    const v93 = stdlib.gt(v45, v184);
    const v94 = stdlib.lt(v85, stdlib.checkedBigNumberify('./pair.rsh:78:39:decimal', stdlib.UInt_max, 32));
    const v95 = v93 ? v94 : false;
    
    return v95;})()) {
    const v166 = stdlib.sub(v45, v184);
    const v170 = stdlib.add(v183, v166);
    stdlib.protect(ctc2, await interact.showDialog(v84), {
      at: './pair.rsh:93:30:application',
      fs: ['at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:92:13:function exp)', 'at ./pair.rsh:76:19:application call to "runSecBuyer0" (defined at: ./pair.rsh:76:19:function exp)', 'at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:76:19:function exp)'],
      msg: 'showDialog',
      who: 'SecBuyer'
      });
    const v120 = stdlib.protect(ctc0, await interact.getWords(), {
      at: './pair.rsh:94:53:application',
      fs: ['at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:92:13:function exp)', 'at ./pair.rsh:76:19:application call to "runSecBuyer0" (defined at: ./pair.rsh:76:19:function exp)', 'at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:76:19:function exp)'],
      msg: 'getWords',
      who: 'SecBuyer'
      });
    
    const v126 = ['SecBuyer', v120];
    
    const txn3 = await (ctc.sendrecv({
      args: [v23, v36, v45, v84, v85, v170, v183, v126],
      evt_cnt: 1,
      funcNum: 5,
      onlyIf: true,
      out_tys: [ctc3],
      pay: [stdlib.checkedBigNumberify('./pair.rsh:91:12:decimal', stdlib.UInt_max, 0), []],
      sim_p: (async (txn3) => {
        const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
        
        const [v130] = txn3.data;
        const v141 = txn3.time;
        const v142 = txn3.secs;
        const v129 = txn3.from;
        
        let v131;
        switch (v130[0]) {
          case 'FirBuyer': {
            const v132 = v130[1];
            v131 = stdlib.checkedBigNumberify('./pair.rsh:79:12:decimal', stdlib.UInt_max, 0);
            
            break;
            }
          case 'SecBuyer': {
            const v134 = v130[1];
            v131 = stdlib.checkedBigNumberify('./pair.rsh:91:12:decimal', stdlib.UInt_max, 0);
            
            break;
            }
          }
        sim_r.txns.push({
          amt: v131,
          kind: 'to',
          tok: undefined
          });
        const v138 = stdlib.addressEq(v23, v129);
        const v139 = stdlib.addressEq(v36, v129);
        const v140 = v138 ? true : v139;
        stdlib.assert(v140, {
          at: './pair.rsh:76:19:dot',
          fs: [],
          msg: 'sender correct',
          who: 'SecBuyer'
          });
        let v143;
        switch (v130[0]) {
          case 'FirBuyer': {
            const v144 = v130[1];
            const v146 = stdlib.addressEq(v129, v23);
            v143 = v146;
            
            break;
            }
          case 'SecBuyer': {
            const v147 = v130[1];
            const v149 = stdlib.addressEq(v129, v36);
            v143 = v149;
            
            break;
            }
          }
        stdlib.assert(v143, {
          at: './pair.rsh:76:19:application',
          fs: [],
          msg: null,
          who: 'SecBuyer'
          });
        switch (v130[0]) {
          case 'FirBuyer': {
            const v150 = v130[1];
            const v154 = stdlib.Array_set(v84, v85, v150);
            const v155 = stdlib.add(v85, stdlib.checkedBigNumberify('./pair.rsh:88:49:decimal', stdlib.UInt_max, 1));
            const cv84 = v154;
            const cv85 = v155;
            const cv183 = v141;
            const cv184 = v183;
            
            (() => {
              const v84 = cv84;
              const v85 = cv85;
              const v183 = cv183;
              const v184 = cv184;
              
              if ((() => {
                const v93 = stdlib.gt(v45, v184);
                const v94 = stdlib.lt(v85, stdlib.checkedBigNumberify('./pair.rsh:78:39:decimal', stdlib.UInt_max, 32));
                const v95 = v93 ? v94 : false;
                
                return v95;})()) {
                const v166 = stdlib.sub(v45, v184);
                const v170 = stdlib.add(v183, v166);
                sim_r.isHalt = false;
                }
              else {
                sim_r.txns.push({
                  kind: 'halt',
                  tok: undefined
                  })
                sim_r.isHalt = true;
                }})();
            break;
            }
          case 'SecBuyer': {
            const v157 = v130[1];
            const v161 = stdlib.Array_set(v84, v85, v157);
            const v162 = stdlib.add(v85, stdlib.checkedBigNumberify('./pair.rsh:101:49:decimal', stdlib.UInt_max, 1));
            const cv84 = v161;
            const cv85 = v162;
            const cv183 = v141;
            const cv184 = v183;
            
            (() => {
              const v84 = cv84;
              const v85 = cv85;
              const v183 = cv183;
              const v184 = cv184;
              
              if ((() => {
                const v93 = stdlib.gt(v45, v184);
                const v94 = stdlib.lt(v85, stdlib.checkedBigNumberify('./pair.rsh:78:39:decimal', stdlib.UInt_max, 32));
                const v95 = v93 ? v94 : false;
                
                return v95;})()) {
                const v166 = stdlib.sub(v45, v184);
                const v170 = stdlib.add(v183, v166);
                sim_r.isHalt = false;
                }
              else {
                sim_r.txns.push({
                  kind: 'halt',
                  tok: undefined
                  })
                sim_r.isHalt = true;
                }})();
            break;
            }
          }
        return sim_r;
        }),
      soloSend: false,
      timeoutAt: ['time', v170],
      tys: [ctc1, ctc1, ctc4, ctc5, ctc4, ctc4, ctc4, ctc3],
      waitIfNotPresent: false
      }));
    if (txn3.didTimeout) {
      const txn4 = await (ctc.sendrecv({
        args: [v23, v36, v45, v84, v85, v170, v183],
        evt_cnt: 0,
        funcNum: 6,
        onlyIf: true,
        out_tys: [],
        pay: [stdlib.checkedBigNumberify('./pair.rsh:decimal', stdlib.UInt_max, 0), []],
        sim_p: (async (txn4) => {
          const sim_r = { txns: [], mapRefs: [], mapsPrev: [], mapsNext: [] };
          
          const [] = txn4.data;
          const v178 = txn4.time;
          const v179 = txn4.secs;
          const v173 = txn4.from;
          
          sim_r.txns.push({
            amt: stdlib.checkedBigNumberify('./pair.rsh:decimal', stdlib.UInt_max, 0),
            kind: 'to',
            tok: undefined
            });
          const v175 = stdlib.addressEq(v23, v173);
          const v176 = stdlib.addressEq(v36, v173);
          const v177 = v175 ? true : v176;
          stdlib.assert(v177, {
            at: './pair.rsh:104:69:dot',
            fs: ['at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:76:19:function exp)'],
            msg: 'sender correct',
            who: 'SecBuyer'
            });
          const cv84 = v84;
          const cv85 = v85;
          const cv183 = v178;
          const cv184 = v183;
          
          (() => {
            const v84 = cv84;
            const v85 = cv85;
            const v183 = cv183;
            const v184 = cv184;
            
            if ((() => {
              const v93 = stdlib.gt(v45, v184);
              const v94 = stdlib.lt(v85, stdlib.checkedBigNumberify('./pair.rsh:78:39:decimal', stdlib.UInt_max, 32));
              const v95 = v93 ? v94 : false;
              
              return v95;})()) {
              const v166 = stdlib.sub(v45, v184);
              const v170 = stdlib.add(v183, v166);
              sim_r.isHalt = false;
              }
            else {
              sim_r.txns.push({
                kind: 'halt',
                tok: undefined
                })
              sim_r.isHalt = true;
              }})();
          return sim_r;
          }),
        soloSend: false,
        timeoutAt: undefined,
        tys: [ctc1, ctc1, ctc4, ctc5, ctc4, ctc4, ctc4],
        waitIfNotPresent: false
        }));
      const [] = txn4.data;
      const v178 = txn4.time;
      const v179 = txn4.secs;
      const v173 = txn4.from;
      ;
      const v175 = stdlib.addressEq(v23, v173);
      const v176 = stdlib.addressEq(v36, v173);
      const v177 = v175 ? true : v176;
      stdlib.assert(v177, {
        at: './pair.rsh:104:69:dot',
        fs: ['at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:76:19:function exp)'],
        msg: 'sender correct',
        who: 'SecBuyer'
        });
      const cv84 = v84;
      const cv85 = v85;
      const cv183 = v178;
      const cv184 = v183;
      
      v84 = cv84;
      v85 = cv85;
      v183 = cv183;
      v184 = cv184;
      
      continue;
      }
    else {
      const [v130] = txn3.data;
      const v141 = txn3.time;
      const v142 = txn3.secs;
      const v129 = txn3.from;
      let v131;
      switch (v130[0]) {
        case 'FirBuyer': {
          const v132 = v130[1];
          v131 = stdlib.checkedBigNumberify('./pair.rsh:79:12:decimal', stdlib.UInt_max, 0);
          
          break;
          }
        case 'SecBuyer': {
          const v134 = v130[1];
          v131 = stdlib.checkedBigNumberify('./pair.rsh:91:12:decimal', stdlib.UInt_max, 0);
          
          break;
          }
        }
      ;
      const v138 = stdlib.addressEq(v23, v129);
      const v139 = stdlib.addressEq(v36, v129);
      const v140 = v138 ? true : v139;
      stdlib.assert(v140, {
        at: './pair.rsh:76:19:dot',
        fs: [],
        msg: 'sender correct',
        who: 'SecBuyer'
        });
      let v143;
      switch (v130[0]) {
        case 'FirBuyer': {
          const v144 = v130[1];
          const v146 = stdlib.addressEq(v129, v23);
          v143 = v146;
          
          break;
          }
        case 'SecBuyer': {
          const v147 = v130[1];
          const v149 = stdlib.addressEq(v129, v36);
          v143 = v149;
          
          break;
          }
        }
      stdlib.assert(v143, {
        at: './pair.rsh:76:19:application',
        fs: [],
        msg: null,
        who: 'SecBuyer'
        });
      switch (v130[0]) {
        case 'FirBuyer': {
          const v150 = v130[1];
          const v154 = stdlib.Array_set(v84, v85, v150);
          const v155 = stdlib.add(v85, stdlib.checkedBigNumberify('./pair.rsh:88:49:decimal', stdlib.UInt_max, 1));
          const cv84 = v154;
          const cv85 = v155;
          const cv183 = v141;
          const cv184 = v183;
          
          v84 = cv84;
          v85 = cv85;
          v183 = cv183;
          v184 = cv184;
          
          continue;
          break;
          }
        case 'SecBuyer': {
          const v157 = v130[1];
          const v161 = stdlib.Array_set(v84, v85, v157);
          const v162 = stdlib.add(v85, stdlib.checkedBigNumberify('./pair.rsh:101:49:decimal', stdlib.UInt_max, 1));
          const cv84 = v161;
          const cv85 = v162;
          const cv183 = v141;
          const cv184 = v183;
          
          v84 = cv84;
          v85 = cv85;
          v183 = cv183;
          v184 = cv184;
          
          continue;
          break;
          }
        }}
    }
  return;
  
  
  };

const _ALGO = {
  appApproval: `#pragma version 4
txn RekeyTo
global ZeroAddress
==
assert
txn Lease
global ZeroAddress
==
assert
int 0
store 0
txn ApplicationID
bz alloc
byte base64()
app_global_get
dup
substring 0 32
store 1
substring 32 64
store 2
txn NumAppArgs
int 3
==
assert
txna ApplicationArgs 0
btoi
dup
bz ctor
// Handler 1
dup
int 1
==
bz l0
pop
txna ApplicationArgs 1
dup
len
int 0
==
assert
pop
txna ApplicationArgs 2
dup
len
int 96
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 96
store 253
pop
// compute state in HM_Check 0
int 8
bzero
sha256
load 1
==
assert
// "CheckPay"
// "./pair.rsh:60:12:dot"
// "[]"
byte base64(AAAAAAAAAAI=)
int 1
bzero
dig 1
substring 0 8
app_global_put
pop
// compute state in HM_Set 1
byte base64(AAAAAAAAAAE=)
txn Sender
concat
global Round
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l0:
// Handler 2
dup
int 2
==
bz l1
pop
txna ApplicationArgs 1
dup
len
int 40
==
assert
dup
substring 0 32
store 255
dup
substring 32 40
btoi
store 254
pop
txna ApplicationArgs 2
dup
len
int 96
==
assert
dup
substring 0 32
store 253
dup
substring 32 64
store 252
dup
substring 64 96
store 251
pop
// compute state in HM_Check 1
byte base64(AAAAAAAAAAE=)
load 255
concat
load 254
itob
concat
sha256
load 1
==
assert
// "CheckPay"
// "./pair.rsh:70:12:dot"
// "[]"
load 255
txn Sender
concat
load 254
int 30
+
itob
concat
byte base64(ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAAAAAAAAAAA)
global Round
itob
concat
load 254
itob
concat
b loop3
l1:
l2:
l3:
// Handler 5
dup
int 5
==
bz l4
pop
txna ApplicationArgs 1
dup
len
int 1120
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 72
btoi
store 253
dup
int 72
int 1096
substring3
store 252
dup
int 1096
int 1104
substring3
btoi
store 251
dup
int 1104
int 1112
substring3
btoi
store 250
dup
int 1112
int 1120
substring3
btoi
store 249
pop
txna ApplicationArgs 2
dup
len
int 33
==
assert
dup
store 248
pop
// compute state in HM_Check 5
byte base64(AAAAAAAAAAU=)
load 255
concat
load 254
concat
load 253
itob
concat
load 252
concat
load 251
itob
concat
load 250
itob
concat
load 249
itob
concat
sha256
load 1
==
assert
global Round
load 250
<
assert
load 248
int 0
getbyte
int 0
==
bz l6
load 248
substring 1 33
store 246
int 0
store 247
l6:
load 248
int 0
getbyte
int 1
==
bz l7
load 248
substring 1 33
store 246
int 0
store 247
l7:
l5:
// "CheckPay"
// "./pair.rsh:76:19:dot"
// "[]"
load 247
dup
bz l8
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Receiver
==
assert
l8:
pop
// Just "sender correct"
// "./pair.rsh:76:19:dot"
// "[]"
load 255
txn Sender
==
load 254
txn Sender
==
||
assert
load 248
int 0
getbyte
int 0
==
bz l10
load 248
substring 1 33
store 245
txn Sender
load 255
==
store 246
l10:
load 248
int 0
getbyte
int 1
==
bz l11
load 248
substring 1 33
store 245
txn Sender
load 254
==
store 246
l11:
l9:
// Nothing
// "./pair.rsh:76:19:application"
// "[]"
load 246
assert
load 248
int 0
getbyte
int 0
==
bz l13
load 248
substring 1 33
store 245
load 255
load 254
concat
load 253
itob
concat
load 252
int 0
int 32
load 251
*
substring3
load 245
concat
load 252
int 32
dup
load 251
*
+
int 1024
substring3
concat
load 251
int 1
+
itob
concat
global Round
itob
concat
load 249
itob
concat
b loop3
l13:
load 248
int 0
getbyte
int 1
==
bz l14
load 248
substring 1 33
store 245
load 255
load 254
concat
load 253
itob
concat
load 252
int 0
int 32
load 251
*
substring3
load 245
concat
load 252
int 32
dup
load 251
*
+
int 1024
substring3
concat
load 251
int 1
+
itob
concat
global Round
itob
concat
load 249
itob
concat
b loop3
l14:
l12:
l4:
// Handler 6
dup
int 6
==
bz l15
pop
txna ApplicationArgs 1
dup
len
int 1120
==
assert
dup
substring 0 32
store 255
dup
substring 32 64
store 254
dup
substring 64 72
btoi
store 253
dup
int 72
int 1096
substring3
store 252
dup
int 1096
int 1104
substring3
btoi
store 251
dup
int 1104
int 1112
substring3
btoi
store 250
dup
int 1112
int 1120
substring3
btoi
store 249
pop
txna ApplicationArgs 2
dup
len
int 0
==
assert
pop
// compute state in HM_Check 5
byte base64(AAAAAAAAAAU=)
load 255
concat
load 254
concat
load 253
itob
concat
load 252
concat
load 251
itob
concat
load 250
itob
concat
load 249
itob
concat
sha256
load 1
==
assert
global Round
load 250
>=
assert
// "CheckPay"
// "./pair.rsh:104:69:dot"
// "[at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:76:19:function exp)]"
// Just "sender correct"
// "./pair.rsh:104:69:dot"
// "[at ./pair.rsh:76:19:application call to [unknown function] (defined at: ./pair.rsh:76:19:function exp)]"
load 255
txn Sender
==
load 254
txn Sender
==
||
assert
load 255
load 254
concat
load 253
itob
concat
load 252
load 251
itob
concat
global Round
itob
concat
load 249
itob
concat
b loop3
l15:
int 0
assert
loop3:
dup
int 0
int 1024
substring3
store 255
dup
int 1024
int 1032
substring3
btoi
store 254
dup
int 1032
int 1040
substring3
btoi
store 253
dup
int 1040
int 1048
substring3
btoi
store 252
pop
dup
substring 0 32
store 251
dup
substring 32 64
store 250
dup
substring 64 72
btoi
store 249
pop
load 249
load 252
>
load 254
int 32
<
&&
bz l16
load 253
load 249
load 252
-
+
store 248
byte base64(AAAAAAAAAAE=)
int 1
bzero
dig 1
substring 0 8
app_global_put
pop
// compute state in HM_Set 5
byte base64(AAAAAAAAAAU=)
load 251
concat
load 250
concat
load 249
itob
concat
load 255
concat
load 254
itob
concat
load 248
itob
concat
load 253
itob
concat
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
l16:
byte base64()
byte base64()
loop4:
pop
pop
int 0
load 0
dup
int 1
+
store 0
swap
dig 1
gtxns Amount
==
assert
int pay
dig 1
gtxns TypeEnum
==
assert
int 0
dig 1
gtxns Fee
==
assert
global ZeroAddress
dig 1
gtxns Lease
==
assert
global ZeroAddress
dig 1
gtxns RekeyTo
==
assert
load 2
dig 1
gtxns Sender
==
assert
global CreatorAddress
dig 1
gtxns CloseRemainderTo
==
assert
l17:
pop
global ZeroAddress
store 1
txn OnCompletion
int DeleteApplication
==
assert
updateState:
byte base64()
load 1
load 2
concat
app_global_put
checkSize:
load 0
dup
dup
int 1
+
global GroupSize
==
assert
txn GroupIndex
==
assert
int 1000
*
txn Fee
<=
assert
done:
int 1
return
alloc:
txn OnCompletion
int NoOp
==
assert
byte base64()
int 64
bzero
app_global_put
b checkSize
ctor:
txn Sender
global CreatorAddress
==
assert
txna ApplicationArgs 1
store 2
int 8
bzero
int 1
bzero
dig 1
substring 0 8
app_global_put
pop
// compute state in HM_Set 0
int 8
bzero
sha256
store 1
txn OnCompletion
int NoOp
==
assert
b updateState
`,
  appClear: `#pragma version 4
int 0
`,
  escrow: `#pragma version 4
global GroupSize
int 1
-
dup
gtxns TypeEnum
int appl
==
assert
gtxns ApplicationID
int {{ApplicationID}}
==
assert
done:
int 1
`,
  mapDataKeys: 0,
  mapDataSize: 0,
  unsupported: [],
  version: 2,
  viewKeys: 1,
  viewSize: 8
  };
const _ETH = {
  ABI: `[
  {
    "inputs": [],
    "stateMutability": "payable",
    "type": "constructor"
  },
  {
    "inputs": [
      {
        "internalType": "uint256",
        "name": "msg",
        "type": "uint256"
      }
    ],
    "name": "ReachError",
    "type": "error"
  },
  {
    "anonymous": false,
    "inputs": [],
    "name": "e0",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "internalType": "bool",
            "name": "svs",
            "type": "bool"
          },
          {
            "components": [
              {
                "internalType": "uint8[32]",
                "name": "v24",
                "type": "uint8[32]"
              },
              {
                "internalType": "address payable",
                "name": "v25",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v26",
                "type": "address"
              }
            ],
            "internalType": "struct T2",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T3",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e1",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v23",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v28",
                "type": "uint256"
              }
            ],
            "internalType": "struct T1",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint8[32]",
                "name": "v37",
                "type": "uint8[32]"
              },
              {
                "internalType": "address payable",
                "name": "v38",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v39",
                "type": "address"
              }
            ],
            "internalType": "struct T8",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T9",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e2",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v23",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v36",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v45",
                "type": "uint256"
              },
              {
                "internalType": "uint8[32][32]",
                "name": "v84",
                "type": "uint8[32][32]"
              },
              {
                "internalType": "uint256",
                "name": "v85",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v170",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v183",
                "type": "uint256"
              }
            ],
            "internalType": "struct T10",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "components": [
                  {
                    "internalType": "enum _enum_T12",
                    "name": "which",
                    "type": "uint8"
                  },
                  {
                    "internalType": "uint8[32]",
                    "name": "_FirBuyer",
                    "type": "uint8[32]"
                  },
                  {
                    "internalType": "uint8[32]",
                    "name": "_SecBuyer",
                    "type": "uint8[32]"
                  }
                ],
                "internalType": "struct T12",
                "name": "v130",
                "type": "tuple"
              }
            ],
            "internalType": "struct T13",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "indexed": false,
        "internalType": "struct T14",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e5",
    "type": "event"
  },
  {
    "anonymous": false,
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v23",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v36",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v45",
                "type": "uint256"
              },
              {
                "internalType": "uint8[32][32]",
                "name": "v84",
                "type": "uint8[32][32]"
              },
              {
                "internalType": "uint256",
                "name": "v85",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v170",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v183",
                "type": "uint256"
              }
            ],
            "internalType": "struct T10",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "indexed": false,
        "internalType": "struct T15",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "e6",
    "type": "event"
  },
  {
    "inputs": [],
    "name": "NFT_owner1",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "NFT_owner2",
    "outputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "internalType": "bool",
            "name": "svs",
            "type": "bool"
          },
          {
            "components": [
              {
                "internalType": "uint8[32]",
                "name": "v24",
                "type": "uint8[32]"
              },
              {
                "internalType": "address payable",
                "name": "v25",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v26",
                "type": "address"
              }
            ],
            "internalType": "struct T2",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T3",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m1",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v23",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v28",
                "type": "uint256"
              }
            ],
            "internalType": "struct T1",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "internalType": "uint8[32]",
                "name": "v37",
                "type": "uint8[32]"
              },
              {
                "internalType": "address payable",
                "name": "v38",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v39",
                "type": "address"
              }
            ],
            "internalType": "struct T8",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T9",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m2",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v23",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v36",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v45",
                "type": "uint256"
              },
              {
                "internalType": "uint8[32][32]",
                "name": "v84",
                "type": "uint8[32][32]"
              },
              {
                "internalType": "uint256",
                "name": "v85",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v170",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v183",
                "type": "uint256"
              }
            ],
            "internalType": "struct T10",
            "name": "svs",
            "type": "tuple"
          },
          {
            "components": [
              {
                "components": [
                  {
                    "internalType": "enum _enum_T12",
                    "name": "which",
                    "type": "uint8"
                  },
                  {
                    "internalType": "uint8[32]",
                    "name": "_FirBuyer",
                    "type": "uint8[32]"
                  },
                  {
                    "internalType": "uint8[32]",
                    "name": "_SecBuyer",
                    "type": "uint8[32]"
                  }
                ],
                "internalType": "struct T12",
                "name": "v130",
                "type": "tuple"
              }
            ],
            "internalType": "struct T13",
            "name": "msg",
            "type": "tuple"
          }
        ],
        "internalType": "struct T14",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m5",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "inputs": [
      {
        "components": [
          {
            "components": [
              {
                "internalType": "address payable",
                "name": "v23",
                "type": "address"
              },
              {
                "internalType": "address payable",
                "name": "v36",
                "type": "address"
              },
              {
                "internalType": "uint256",
                "name": "v45",
                "type": "uint256"
              },
              {
                "internalType": "uint8[32][32]",
                "name": "v84",
                "type": "uint8[32][32]"
              },
              {
                "internalType": "uint256",
                "name": "v85",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v170",
                "type": "uint256"
              },
              {
                "internalType": "uint256",
                "name": "v183",
                "type": "uint256"
              }
            ],
            "internalType": "struct T10",
            "name": "svs",
            "type": "tuple"
          },
          {
            "internalType": "bool",
            "name": "msg",
            "type": "bool"
          }
        ],
        "internalType": "struct T15",
        "name": "_a",
        "type": "tuple"
      }
    ],
    "name": "m6",
    "outputs": [],
    "stateMutability": "payable",
    "type": "function"
  },
  {
    "stateMutability": "payable",
    "type": "receive"
  }
]`,
  Bytecode: `0x608060408190527f49ff028a829527a47ec6839c7147b484eccf5a2a94853eddac09cef44d9d4e9e90600090a160408051808201825243815242602080830191909152600060018190558351918201819052919201604051602081830303815290604052600290805190602001906200007a929190620000b6565b506040805160006020820181905291810182905260600160408051601f1981840301815291905280516020909101206000555062000199915050565b828054620000c4906200015c565b90600052602060002090601f016020900481019282620000e8576000855562000133565b82601f106200010357805160ff191683800117855562000133565b8280016001018555821562000133579182015b828111156200013357825182559160200191906001019062000116565b506200014192915062000145565b5090565b5b8082111562000141576000815560010162000146565b600181811c908216806200017157607f821691505b602082108114156200019357634e487b7160e01b600052602260045260246000fd5b50919050565b61380680620001a96000396000f3fe6080604052600436106100595760003560e01c8063293e37221461006557806346f8ed2a1461007a57806355f40150146100ab5780638314f053146100c0578063a2038846146100d3578063d9f1bac9146100e657600080fd5b3661006057005b600080fd5b6100786100733660046133f4565b6100f9565b005b34801561008657600080fd5b5061008f610221565b6040516001600160a01b03909116815260200160405180910390f35b3480156100b757600080fd5b5061008f6103a7565b6100786100ce3660046133e1565b61052a565b6100786100e13660046133c8565b6106f2565b6100786100f4366004613407565b610c16565b61014b600061010b6020840184613373565b6040516020016101279291909182521515602082015260400190565b6040516020818303038152906040528051906020012060001c60005414600a612ef4565b600080556040517fcbc2ee2ae1c4b934f4fe74586d12596843808b299657e3e2515918c95205cb469061017f9083906135df565b60405180910390a161019334156009612ef4565b6002600155604080516000602082018190529101604051602081830303815290604052600290805190602001906101cb9291906130f0565b5050604080518082018252338152436020808301918252835160018183015292516001600160a01b0316838501529051606080840191909152835180840390910181526080909201909252805191012060005550565b60006001805414156102dd5760006002805461023c90613730565b80601f016020809104026020016040519081016040528092919081815260200182805461026890613730565b80156102b55780601f1061028a576101008083540402835291602001916102b5565b820191906000526020600020905b81548152906001019060200180831161029857829003601f168201915b50505050508060200190518101906102cd9190613390565b90506102db60006007612ef4565b505b60026001541415610398576000600280546102f790613730565b80601f016020809104026020016040519081016040528092919081815260200182805461032390613730565b80156103705780601f1061034557610100808354040283529160200191610370565b820191906000526020600020905b81548152906001019060200180831161035357829003601f168201915b50505050508060200190518101906103889190613390565b905061039660006007612ef4565b505b6103a460006007612ef4565b90565b6000600180541415610463576000600280546103c290613730565b80601f01602080910402602001604051908101604052809291908181526020018280546103ee90613730565b801561043b5780601f106104105761010080835404028352916020019161043b565b820191906000526020600020905b81548152906001019060200180831161041e57829003601f168201915b50505050508060200190518101906104539190613390565b905061046160006008612ef4565b505b6002600154141561051e5760006002805461047d90613730565b80601f01602080910402602001604051908101604052809291908181526020018280546104a990613730565b80156104f65780601f106104cb576101008083540402835291602001916104f6565b820191906000526020600020905b8154815290600101906020018083116104d957829003601f168201915b505050505080602001905181019061050e9190613390565b905061051c60006008612ef4565b505b6103a460006008612ef4565b60405161056690610542906005908490602001613628565b6040516020818303038152906040528051906020012060001c600054146014612ef4565b6000805561057d6180808201354310156015612ef4565b7fcaa0ab4b868c2968cea8b62763d9eb1f2fbc3296468b314b5460714b26ced7d9816040516105ac91906135b3565b60405180910390a16105c034156012612ef4565b610609336105d16020840184613351565b6001600160a01b0316146105ff57336105f06040840160208501613351565b6001600160a01b031614610602565b60015b6013612ef4565b610611613174565b61061e6020830183613351565b81516001600160a01b03909116905261063d6040830160208401613351565b81516001600160a01b03909116602091820152815160408085013591810191909152805161040081019091529060608401906000835b828210156106b5576040805161040081810190925290808402860190602090839083908082843760009201919091525050508152600190910190602001610673565b5050506020808401805193909352825161806086013591015250805143604090910152516180a08301356060909101526106ee81612f19565b5050565b60405161072e9061070a906005908490602001613628565b6040516020818303038152906040528051906020012060001c600054146010612ef4565b6000805561073a6131a9565b61074c61808083013543106011612ef4565b7fa9253927450973826eaf4b804abbeab434b880c3502a713625030e8e577241898260405161077b919061354a565b60405180910390a160006107976180e084016180c085016133ad565b60018111156107a8576107a8613796565b14156107e65760408051610400818101909252906180e084019060209083908390808284376000920182905250602085019390935250508152610845565b60016107fa6180e084016180c085016133ad565b600181111561080b5761080b613796565b14156108455760408051610400818101909252906184e0840190602090839083908082843760009201829052506040850193909352505081525b8051610854903414600d612ef4565b61089d336108656020850185613351565b6001600160a01b03161461089357336108846040850160208601613351565b6001600160a01b031614610896565b60015b600e612ef4565b60006108b16180e084016180c085016133ad565b60018111156108c2576108c2613796565b14156109195760408051610400818101909252906180e08401906020908390839080828437600092019190915250505060808201526109046020830183613351565b6001600160a01b031633146060820152610983565b600161092d6180e084016180c085016133ad565b600181111561093e5761093e613796565b14156109835760408051610400818101909252906184e08401906020908390839080828437600092019190915250505060a08201526109046040830160208401613351565b6109928160600151600f612ef4565b60006109a66180e084016180c085016133ad565b60018111156109b7576109b7613796565b1415610af85760408051610400818101909252906180e08401906020908390839080828437600092019190915250505060c08201526109f4613174565b610a016020840184613351565b81516001600160a01b039091169052610a206040840160208501613351565b81516001600160a01b0390911660209182015281516040808601359181019190915280516104008101909152610ab09160608601906000835b82821015610a9b576040805161040081810190925290808402860190602090839083908082843760009201919091525050508152600190910190602001610a59565b50505060c08501516180608701359150613063565b602082015152610ac66001618060850135613701565b6020808301805190910191909152805143604090910152516180a0840135606090910152610af381612f19565b505050565b6001610b0c6180e084016180c085016133ad565b6001811115610b1d57610b1d613796565b14156106ee5760408051610400818101909252906184e08401906020908390839080828437600092019190915250505060e0820152610b5a613174565b610b676020840184613351565b81516001600160a01b039091169052610b866040840160208501613351565b81516001600160a01b0390911660209182015281516040808601359181019190915280516104008101909152610ab09160608601906000835b82821015610c01576040805161040081810190925290808402860190602090839083908082843760009201919091525050508152600190910190602001610bbf565b50505060e08501516180608701359150613063565b604051610c5290610c2e9060019084906020016136ed565b6040516020818303038152906040528051906020012060001c60005414600c612ef4565b60008055610c5e61320c565b7fd1a32c308d2c0313a14b9477e3a2c0e3f9176e9a446f6f68410e892f8918c65d82604051610c8d9190613609565b60405180910390a1610ca13415600b612ef4565b60408051610400810182526020808252808201819052918101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516000602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516001602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516002602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516003602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516004602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516005602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516006602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516007602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516008602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516009602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e08101919091528151600a602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e08101919091528151600b602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e08101919091528151600c602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e08101919091528151600d602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e08101919091528151600e602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e08101919091528151600f602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516010602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516011602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516012602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516013602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516014602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516015602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516016602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516017602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516018602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e081019190915281516019602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e08101919091528151601a602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e08101919091528151601b602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e08101919091528151601c602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e08101919091528151601d602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e08101919091528151601e602090810291909101919091526040805161040081018252828152808301839052908101829052606081018290526080810182905260a0810182905260c0810182905260e08101829052610100810182905261012081018290526101408101829052610160810182905261018081018290526101a081018290526101c081018290526101e08101829052610200810182905261022081018290526102408101829052610260810182905261028081018290526102a081018290526102c081018290526102e08101829052610300810182905261032081018290526103408101829052610360810182905261038081018290526103a081018290526103c081018290526103e08101919091528151601f6020020152612e83613174565b612e906020840184613351565b81516001600160a01b039091169052805133602091820152612eb790601e90850135613701565b81516040908101919091528251602080840180519290925281516000908201528151439301929092525190840135606090910152610af381612f19565b816106ee5760405163100960cb60e01b81526004810182905260240160405180910390fd5b60408051602081019091526000815260208201516060015182516040015111612f43576000612f50565b6020826020015160200151105b1561304657602082015160600151825160400151612f6e9190613719565b826020015160400151612f819190613701565b81526001805560408051600060208201819052910160405160208183030381529060405260029080519060200190612fba9291906130f0565b50612fc361321f565b8351516001600160a01b039081168252845160209081015190911681830152845160409081015181840152818601805151606085015280518301516080850152855160a08501525181015160c0840152516130239160059184910161363d565b60408051601f198184030181529190528051602090910120600055506106ee9050565b6040805180820190915260008082526020820152610af3816130d7565b61306b613274565b60005b60208110156130b757848160208110613089576130896137ac565b60200201518282602081106130a0576130a06137ac565b6020020152806130af81613765565b91505061306e565b50818184602081106130cb576130cb6137ac565b60200201529392505050565b600080805560018190556130ed906002906132a2565b33ff5b8280546130fc90613730565b90600052602060002090601f01602090048101928261311e5760008555613164565b82601f1061313757805160ff1916838001178555613164565b82800160010185558215613164579182015b82811115613164578251825591602001919060010190613149565b506131709291506132df565b5090565b6040805160a0810182526000918101828152606082018390526080820192909252908152602081016131a46132f4565b905290565b604051806101000160405280600081526020016131c4613307565b81526020016131d1613307565b8152600060208201526040016131e5613307565b81526020016131f2613307565b81526020016131ff613307565b81526020016131a4613307565b60405180602001604052806131a4613274565b6040518060e0016040528060006001600160a01b0316815260200160006001600160a01b0316815260200160008152602001613259613274565b81526020016000815260200160008152602001600081525090565b6040518061040001604052806020905b61328c613307565b8152602001906001900390816132845790505090565b5080546132ae90613730565b6000825580601f106132be575050565b601f0160209004906000526020600020908101906132dc91906132df565b50565b5b8082111561317057600081556001016132e0565b6040518060800160405280613259613274565b6040518061040001604052806020906020820280368337509192915050565b80356001600160a01b038116811461333d57600080fd5b919050565b80356002811061333d57600080fd5b60006020828403121561336357600080fd5b61336c82613326565b9392505050565b60006020828403121561338557600080fd5b813561336c816137c2565b6000602082840312156133a257600080fd5b815161336c816137c2565b6000602082840312156133bf57600080fd5b61336c82613342565b60006188e082840312156133db57600080fd5b50919050565b60006180e082840312156133db57600080fd5b600061046082840312156133db57600080fd5b600061048082840312156133db57600080fd5b806000805b602080821061342e5750613453565b833560ff811680821461343f578485fd5b87525094850194929092019160010161341f565b5050505050565b6001600160a01b038061346c83613326565b16835260208161347d828501613326565b1681850152604083013560408501526060840191506060830160005b828110156134bf576134ab848361341a565b610400938401939190910190600101613499565b50505050618060818101359083015261808080820135908301526180a090810135910152565b6001600160a01b036134f682613326565b168252602090810135910152565b61350e828261341a565b61040061351c818301613326565b6001600160a01b0381811692850192909252610420918061353e858501613326565b16838601525050505050565b6188e08101613559828461345a565b6180c0613567818501613342565b6002811061358557634e487b7160e01b600052602160045260246000fd5b908301526180e061359a81840185830161341a565b506184e06135ac81840182860161341a565b5092915050565b6180e081016135c2828461345a565b6180c0808401356135d2816137c2565b1515920191909152919050565b610460810182356135ef816137c2565b151582526136036020808401908501613504565b92915050565b610480810161361882846134e5565b6136036040830160408501613504565b8281526180e0810161336c602083018461345a565b60006180e082019050838252602060018060a01b038085511682850152808286015116604085015250604084015160608401526060840151608084016000805b848110156136c057835183835b878110156136a957825160ff168252918701919087019060010161368a565b50505092840192610400929092019160010161367d565b5050505050608083015161808083015260a08301516180a083015260c08301516180c08301529392505050565b8281526060810161336c60208301846134e5565b6000821982111561371457613714613780565b500190565b60008282101561372b5761372b613780565b500390565b600181811c9082168061374457607f821691505b602082108114156133db57634e487b7160e01b600052602260045260246000fd5b600060001982141561377957613779613780565b5060010190565b634e487b7160e01b600052601160045260246000fd5b634e487b7160e01b600052602160045260246000fd5b634e487b7160e01b600052603260045260246000fd5b80151581146132dc57600080fdfea26469706673582212203afd0f6885c94eb71121e54d96c83410137b0b2cff9f8acf91668c9692339e8064736f6c63430008050033`,
  BytecodeLen: 14767,
  Which: `oD`,
  deployMode: `DM_constructor`,
  version: 1,
  views: {
    NFT: {
      owner1: `NFT_owner1`,
      owner2: `NFT_owner2`
      }
    }
  };

export const _Connectors = {
  ALGO: _ALGO,
  ETH: _ETH
  };

